﻿const CACHE_NAME = "YelePay-clean-source-v1";
const APP_SHELL = [
  "/index.html",
  "/dashboard.html",
  "/profile.html",
  "/team.html",
  "/purchase.html",
  "/withdrawal.html",
  "/transaction-history.html",
  "/admin-panel.html",
  "/signup.html",
  "/register.html",
  "/style.css",
  "/firebase.js",
  "/login.js",
  "/register.js",
  "/dashboard.js",
  "/purchase.js",
  "/withdrawal.js",
  "/team.js",
  "/profile.js",
  "/transaction-history.js",
  "/manifest.json",
  "/YelePay-icon-192.png",
  "/YelePay-icon-512.png",
  "/slice.png",
  "/mobikwik.png",
  "/paytm.png",
  "/admin.js",
  "/admindashboard.html",
  "/adminuser.html",
  "/adminorder.html",
  "/adminpayment.html",
  "/adminsellingrequest.html",
  "/admingiftcode.html",
  "/adminpopup.html",
  "/adminbanner.html",
  "/admintutorial.html",
  "/adminsetting.html",
  "/images/avatars/avatar-01.jpg",
  "/images/avatars/avatar-02.jpg",
  "/images/avatars/avatar-03.jpg",
  "/images/avatars/avatar-04.jpg",
  "/images/avatars/avatar-05.jpg",
  "/images/avatars/avatar-06.jpg",
  "/images/avatars/avatar-07.jpg",
  "/images/avatars/avatar-08.jpg",
  "/images/avatars/avatar-09.jpg",
  "/images/avatars/avatar-10.jpg",
  "/images/avatars/avatar-11.jpg",
  "/images/avatars/avatar-12.jpg",
  "/images/avatars/avatar-13.jpg",
  "/images/avatars/avatar-14.jpg",
  "/images/avatars/avatar-15.jpg",
  "/images/avatars/avatar-16.jpg",
  "/images/avatars/avatar-17.jpg",
  "/images/avatars/avatar-18.jpg"
];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET" || new URL(event.request.url).origin !== self.location.origin) return;
  event.respondWith(
    fetch(event.request)
      .then((response) => {
        if (response.ok) {
          const copy = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
        }
        return response;
      })
      .catch(() => caches.match(event.request).then((cached) => cached || caches.match("/index.html")))
  );
});



