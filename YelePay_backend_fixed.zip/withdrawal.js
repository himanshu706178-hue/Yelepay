﻿// Withdrawal and withdrawal-history page entry.
import "./firebase.js";



