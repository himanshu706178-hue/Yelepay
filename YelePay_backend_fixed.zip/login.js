// Login page entry. Shared auth and UI logic lives in firebase.js.
import "./firebase.js";

const form = document.querySelector("#loginForm");

function setButtonLoading(button) {
  const label = button.querySelector("span");
  if (!label) return;
  button.dataset.defaultText = label.textContent.trim();
  button.classList.add("is-loading");
  label.textContent = button.dataset.loadingText || "Please wait...";

  const reset = () => {
    if (button.disabled) return;
    button.classList.remove("is-loading");
    label.textContent = button.dataset.defaultText || "Login";
  };
  const observer = new MutationObserver(reset);
  observer.observe(button, { attributes: true, attributeFilter: ["disabled"] });
  window.setTimeout(() => {
    observer.disconnect();
    reset();
  }, 8000);
}

document.querySelectorAll("[data-toggle-password]").forEach((button) => {
  button.addEventListener("click", () => {
    const input = button.parentElement?.querySelector("input");
    if (!input) return;
    const isPassword = input.type === "password";
    input.type = isPassword ? "text" : "password";
    button.setAttribute("aria-label", isPassword ? "Hide password" : "Show password");
    button.classList.toggle("is-visible", isPassword);
  });
});

form?.addEventListener("submit", () => {
  const button = form.querySelector(".auth-submit");
  if (!button || !form.checkValidity()) return;
  setButtonLoading(button);
});
