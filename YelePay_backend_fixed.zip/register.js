// Registration page entry.
import "./firebase.js";
// Signup bonus amount is handled by the shared Firebase registration flow.

const form = document.querySelector("#registerForm");
const password = form?.querySelector("input[name='password']");
const confirmPassword = form?.querySelector("input[name='confirmPassword']");
const passwordNote = form?.querySelector("[data-password-note]");

function setButtonLoading(button) {
  const label = button.querySelector("span");
  if (!label) return;
  button.dataset.defaultText = label.textContent.trim();
  button.classList.add("is-loading");
  label.textContent = button.dataset.loadingText || "Please wait...";

  const reset = () => {
    if (button.disabled) return;
    button.classList.remove("is-loading");
    label.textContent = button.dataset.defaultText || "Sign Up";
  };
  const observer = new MutationObserver(reset);
  observer.observe(button, { attributes: true, attributeFilter: ["disabled"] });
  window.setTimeout(() => {
    observer.disconnect();
    reset();
  }, 8000);
}

function updatePasswordMatch() {
  if (!password || !confirmPassword) return true;
  const hasConfirmValue = confirmPassword.value.length > 0;
  const matches = password.value === confirmPassword.value;
  confirmPassword.setCustomValidity(hasConfirmValue && !matches ? "Password and confirm password must match." : "");
  if (passwordNote) {
    passwordNote.textContent = hasConfirmValue ? (matches ? "Password matched" : "Password does not match") : "";
    passwordNote.classList.toggle("is-success", hasConfirmValue && matches);
    passwordNote.classList.toggle("is-error", hasConfirmValue && !matches);
  }
  return matches;
}

document.querySelectorAll("[data-toggle-password]").forEach((button) => {
  button.addEventListener("click", () => {
    const input = button.parentElement?.querySelector("input");
    if (!input) return;
    const isPassword = input.type === "password";
    input.type = isPassword ? "text" : "password";
    button.setAttribute("aria-label", isPassword ? "Hide password" : "Show password");
    button.classList.toggle("is-visible", isPassword);
  });
});

password?.addEventListener("input", updatePasswordMatch);
confirmPassword?.addEventListener("input", updatePasswordMatch);

form?.addEventListener("submit", () => {
  updatePasswordMatch();
  const button = form.querySelector(".auth-submit");
  if (!button || !form.checkValidity()) return;
  setButtonLoading(button);
});
