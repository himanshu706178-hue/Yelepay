import { db, isConfigured } from "./firebase.js";
import { collection, doc, getDoc, getDocs, setDoc, addDoc, updateDoc, deleteDoc, deleteField, query, where, orderBy, limit, startAfter, documentId, serverTimestamp, increment, runTransaction, getAggregateFromServer, sum, count } from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";
const DEFAULT_HASH = "19224af73e55bf1caa3eaf8a46c363a41f43f96b11f8a7406a446d159932d38c";
const LEGACY_HASHES = new Set([
  "e5bf4ea9d3ca8e7b01358689ef7fa132071ecb0adc8fddf8d4b268c868354707",
  "7eea094d9b8e92a7c8bc7d7503bb11af941c8d2a9a594db728f26f86af82a31f"
]);
const SESSION_KEY = "YelePayAdminAccessHash";
const page = document.body.dataset.adminPage || "dashboard";
const root = document.querySelector("#adminRoot");
const ADMIN_PAGE_SIZE = 20;
const adminPages = new Map();

const pages = [
  ["dashboard", "Dashboard", "admindashboard.html"], ["users", "Users", "adminuser.html"],
  ["orders", "Orders", "adminorder.html"], ["payments", "Payment / UPI", "adminpayment.html"],
  ["withdrawals", "Withdrawals", "adminsellingrequest.html"], ["gifts", "Gift Codes", "admingiftcode.html"],
  ["popups", "Popups", "adminpopup.html"], ["banners", "Banners", "adminbanner.html"],
  ["tutorials", "Tutorials", "admintutorial.html"], ["settings", "Settings", "adminsetting.html"]
];

const escapeHtml = (value) => String(value ?? "").replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[char]));
const money = (value) => `Rs ${Number(value || 0).toLocaleString("en-IN", { maximumFractionDigits: 2 })}`;
const dateText = (value) => {
  const date = value?.toDate ? value.toDate() : new Date(value || Date.now());
  return Number.isNaN(date.getTime()) ? "-" : date.toLocaleString("en-IN");
};
function toast(message, type = "success") {
  document.querySelector(".admin-toast")?.remove();
  const node = document.createElement("div");
  node.className = `admin-toast ${type}`;
  node.textContent = message;
  document.body.appendChild(node);
  setTimeout(() => node.remove(), 2600);
}
function serverBusy(error) {
  console.warn(error);
}
function refreshButton(loader) {
  return `<button type="button" data-admin-refresh="${loader}">Refresh</button>`;
}
function pager(name, pageNumber, hasNext) {
  return `<div class="admin-actions admin-pager"><button type="button" data-page-prev="${name}" ${pageNumber <= 1 ? "disabled" : ""}>Previous</button><span>Page ${pageNumber}</span><button type="button" data-page-next="${name}" ${hasNext ? "" : "disabled"}>Next</button></div>`;
}
async function readAdminPage(name, collectionName, reset = false, direction = "current") {
  let state = adminPages.get(name) || { pages: [], index: 0 };
  if (reset) state = { pages: [], index: 0 };
  if (direction === "prev" && state.index > 0) state.index -= 1;
  let needsPage = !state.pages[state.index];
  if (direction === "next") {
    if (state.pages[state.index + 1]) state.index += 1;
    else needsPage = true;
  }
  if (needsPage) {
    const previous = state.pages[state.pages.length - 1];
    const pageOrder = collectionName === "users" ? orderBy(documentId()) : orderBy("createdAt", "desc");
    const parts = [collection(db, collectionName), pageOrder, limit(ADMIN_PAGE_SIZE)];
    if (previous?.cursor) parts.splice(2, 0, startAfter(previous.cursor));
    const snapshot = await getDocs(query(...parts));
    const nextPage = { docs: snapshot.docs, cursor: snapshot.docs.at(-1) || null, hasNext: snapshot.size === ADMIN_PAGE_SIZE };
    if (!state.pages.length) state.pages.push(nextPage);
    else if (direction === "next") { state.pages.push(nextPage); state.index += 1; }
    else state.pages[state.index] = nextPage;
  }
  adminPages.set(name, state);
  return { ...state.pages[state.index], pageNumber: state.index + 1 };
}
async function sha256(value) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(String(value)));
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
async function expectedHash() {
  const activeSessionHash = String(sessionStorage.getItem(SESSION_KEY) || "").toLowerCase();
  if (/^[a-f0-9]{64}$/.test(activeSessionHash)) return activeSessionHash;
  const ref = doc(db, "settings", "main");
  const snap = await getDoc(ref);
  let hash = String(snap.data()?.adminPasswordHash || DEFAULT_HASH).toLowerCase();
  if (!/^[a-f0-9]{64}$/.test(hash) || LEGACY_HASHES.has(hash)) hash = DEFAULT_HASH;
  if (!snap.exists() || snap.data()?.adminPasswordHash !== hash) await setDoc(ref, { adminPasswordHash: hash }, { merge: true });
  return hash;
}
function gateTemplate() {
  return `<main class="admin-login"><form id="adminLogin" class="admin-login-card"><img class="admin-gate-logo" src="YelePay-logo.png" alt="YelePay" width="86" height="86"><p>Restricted access</p><h1>YelePay Admin</h1><label>Admin Password<input name="password" type="password" autocomplete="current-password" required></label><button type="submit">Unlock Admin Panel</button><a href="dashboard.html">Back to YelePay</a></form></main>`;
}
function shellTemplate() {
  const current = pages.find(([key]) => key === page)?.[1] || "Dashboard";
  return `<div class="admin-app">
    <div class="admin-drawer-backdrop" id="adminDrawerBackdrop" aria-hidden="true"></div>
    <aside class="admin-sidebar" aria-label="Admin navigation">
      <div class="admin-sidebar-brand">
        <span class="admin-logo-tile">Y</span>
        <strong>YelePay Admin</strong>
      </div>
      <nav>${pages.map(([key, label, href]) => `<a class="${key === page ? "active" : ""}" href="${href}">${label}</a>`).join("")}</nav>
      <button id="adminLock" type="button">Lock Admin</button>
      <a class="admin-exit" href="dashboard.html">Exit Admin</a>
    </aside>
    <main class="admin-main">
      <header class="admin-page-header">
        <div><p>Control center</p><h1>${current}</h1></div>
        <button id="adminMenu" type="button" aria-label="Open admin menu">Menu</button>
      </header>
      <section id="adminView"><div class="admin-loading">Loading...</div></section>
    </main>
  </div>`;
}
function requireAccess(hash) {
  if (sessionStorage.getItem(SESSION_KEY) === hash) return true;
  location.reload();
  return false;
}
async function boot() {
  const hash = await expectedHash();
  if (sessionStorage.getItem(SESSION_KEY) !== hash) {
    root.innerHTML = gateTemplate();
    document.querySelector("#adminLogin").addEventListener("submit", async (event) => {
      event.preventDefault();
      const input = event.currentTarget.elements.password;
      if (await sha256(input.value) !== hash) { input.value = ""; return toast("Wrong Admin Password", "error"); }
      sessionStorage.setItem(SESSION_KEY, hash);
      toast("Admin Access Granted");
      await showAdmin(hash);
    });
    return;
  }
  await showAdmin(hash);
}
async function showAdmin(hash) {
  root.innerHTML = shellTemplate();

  const sidebar = document.querySelector(".admin-sidebar");
  const backdrop = document.querySelector("#adminDrawerBackdrop");
  const menu = document.querySelector("#adminMenu");

  const setDrawer = (open) => {
    sidebar?.classList.toggle("open", open);
    backdrop?.classList.toggle("open", open);
    backdrop?.setAttribute("aria-hidden", open ? "false" : "true");
    document.body.classList.toggle("admin-drawer-open", open);
  };

  document.querySelector("#adminLock").addEventListener("click", () => {
    sessionStorage.removeItem(SESSION_KEY);
    location.reload();
  });

  menu?.addEventListener("click", () => setDrawer(!sidebar?.classList.contains("open")));
  backdrop?.addEventListener("click", () => setDrawer(false));
  sidebar?.querySelectorAll("nav a, .admin-exit").forEach((link) => {
    link.addEventListener("click", () => setDrawer(false));
  });
  window.addEventListener("keydown", (event) => {
    if (event.key === "Escape") setDrawer(false);
  });

  if (!requireAccess(hash)) return;
  const loaders = { dashboard: loadDashboard, users: loadUsers, orders: loadOrders, payments: loadPayments, withdrawals: loadWithdrawals, gifts: loadGifts, popups: loadPopup, banners: loadBanner, tutorials: loadTutorials, settings: loadSettings };
  await (loaders[page] || loadDashboard)();
}
const view = () => document.querySelector("#adminView");

async function loadDashboard() {
  const todayStart = new Date();
  todayStart.setHours(0, 0, 0, 0);
  const tomorrowStart = new Date(todayStart);
  tomorrowStart.setDate(tomorrowStart.getDate() + 1);

  try {
    const [userSnapshot, paymentSnapshot, withdrawalSnapshot] = await Promise.all([
      getDocs(collection(db, "users")),
      getDocs(collection(db, "payments")),
      getDocs(collection(db, "withdrawals"))
    ]);

    const users = userSnapshot.docs.map((item) => ({ id: item.id, ...item.data() }));
    const payments = paymentSnapshot.docs.map((item) => ({ id: item.id, ...item.data() }));
    const withdrawals = withdrawalSnapshot.docs.map((item) => ({ id: item.id, ...item.data() }));

    const valueDate = (value) => {
      if (!value) return null;
      if (typeof value.toDate === "function") return value.toDate();
      if (Number.isFinite(value.seconds)) return new Date(value.seconds * 1000);
      const parsed = new Date(value);
      return Number.isNaN(parsed.getTime()) ? null : parsed;
    };
    const eventDate = (item) => valueDate(item.approvedAt || item.completedAt || item.updatedAt || item.createdAt);
    const isToday = (item) => {
      const date = eventDate(item);
      return Boolean(date && date >= todayStart && date < tomorrowStart);
    };
    const isCompleted = (item) => String(item.status || "").toLowerCase() === "completed";
    const isPending = (item) => ["processing", "pending"].includes(String(item.status || "").toLowerCase());

    const completedPayments = payments.filter(isCompleted);
    const completedWithdrawals = withdrawals.filter(isCompleted);
    const totalDeposit = completedPayments.reduce((sumValue, item) => sumValue + Number(item.amount || 0), 0);
    const todayDeposit = completedPayments.filter(isToday).reduce((sumValue, item) => sumValue + Number(item.amount || 0), 0);
    const totalWithdraw = completedWithdrawals.reduce((sumValue, item) => sumValue + Number(item.amount || 0), 0);
    const todayWithdraw = completedWithdrawals.filter(isToday).reduce((sumValue, item) => sumValue + Number(item.amount || 0), 0);
    const pendingDeposits = payments.filter(isPending).length;
    const pendingWithdrawals = withdrawals.filter(isPending).length;

    const sortedUsers = [...users].sort((a, b) => {
      const aDate = valueDate(a.createdAt || a.authCreationTime)?.getTime() || 0;
      const bDate = valueDate(b.createdAt || b.authCreationTime)?.getTime() || 0;
      return bDate - aDate;
    });

    const dashboardUserRow = (user) => {
      const registered = userRegistration(user);
      return `<article class="admin-row admin-dashboard-user">
        <div class="admin-user-meta">
          <strong>${escapeHtml(user.name || "User")}</strong>
          <span>Mobile: ${escapeHtml(user.mobile || user.email || "-")}</span>
          <span>Player ID: ${escapeHtml(user.playerId || "Not assigned")}</span>
          <small>Registered: ${registered.date} ${registered.time}</small>
        </div>
        <span class="${user.blocked ? "blocked" : "active"}">${user.blocked ? "Blocked" : "Active"}</span>
      </article>`;
    };

    view().innerHTML = `
      <div class="admin-panel admin-dashboard-statistics">
        <h2>Dashboard Statistics</h2>
        ${refreshButton("dashboard")}
        <div class="admin-metrics">
          <article><span>Total Users</span><strong>${users.length}</strong></article>
          <article><span>Total Deposit</span><strong>${money(totalDeposit)}</strong></article>
          <article><span>Today Deposit</span><strong>${money(todayDeposit)}</strong></article>
          <article><span>Total Withdraw</span><strong>${money(totalWithdraw)}</strong></article>
          <article><span>Today Withdraw</span><strong>${money(todayWithdraw)}</strong></article>
          <article><span>Pending Deposits</span><strong>${pendingDeposits}</strong></article>
          <article><span>Pending Withdrawals</span><strong>${pendingWithdrawals}</strong></article>
        </div>
      </div>
      <div class="admin-panel admin-dashboard-users">
        <div class="admin-section-head">
          <div><h2>Registered Users</h2><p>${users.length} total registered</p></div>
          <input id="dashboardUserSearch" placeholder="Search name, mobile or Player ID">
        </div>
        <div id="dashboardUserRows" class="admin-list">
          ${sortedUsers.map(dashboardUserRow).join("") || "<p>No registered users found.</p>"}
        </div>
      </div>`;

    const refresh = view().querySelector('[data-admin-refresh="dashboard"]');
    if (refresh) refresh.addEventListener("click", () => loadDashboard());

    const search = view().querySelector("#dashboardUserSearch");
    const rows = [...view().querySelectorAll(".admin-dashboard-user")];
    if (search) {
      search.addEventListener("input", () => {
        const term = search.value.trim().toLowerCase();
        rows.forEach((row) => {
          row.hidden = Boolean(term) && !row.textContent.toLowerCase().includes(term);
        });
      });
    }
  } catch (error) {
    serverBusy(error);
    view().innerHTML = `<div class="admin-panel"><h2>Dashboard Statistics</h2><p>Live Firebase data could not be loaded. Sign in to YelePay on this domain and refresh the admin dashboard.</p></div>`;
  }
}
async function loadUsers(reset = false, direction = "current") {
  try {
    const result = await readAdminPage("users", "users", reset, direction);
    const users = result.docs.map((item) => ({ id: item.id, user: item.data() }));
    renderUsersPanel(users, result);
  } catch (error) {
    serverBusy(error);
  }
}
function renderUsersPanel(users, result = { pageNumber: 1, hasNext: false }) {
  view().innerHTML = `<div class="admin-panel"><div class="admin-section-head"><h2>Users</h2><div class="admin-user-search"><input id="userSearch" autocomplete="off" placeholder="Paste UID, mobile, name or Player ID"><button id="userSearchButton" type="button">Search</button>${refreshButton("users")}</div></div><p id="userSearchResult" class="admin-search-result">${users.length} users on this page</p><div id="userRows" class="admin-list">${users.map(userRow).join("") || "<p>No users found.</p>"}</div>${pager("users", result.pageNumber, result.hasNext)}</div>`;
  const search = () => searchUsers(document.querySelector("#userSearch").value);
  document.querySelector("#userSearchButton").addEventListener("click", search);
  document.querySelector("#userSearch").addEventListener("keydown", (event) => { if (event.key === "Enter") { event.preventDefault(); search(); } });
  view().onclick = async (event) => {
    if (event.target.closest('[data-admin-refresh="users"]')) return loadUsers(true);
    if (event.target.closest('[data-page-next="users"]')) return loadUsers(false, "next");
    if (event.target.closest('[data-page-prev="users"]')) return loadUsers(false, "prev");
    return handleUserAction(event);
  };
}
async function searchUsers(rawValue) {
  const value = String(rawValue || "").trim();
  if (!value) return loadUsers(true);
  try {
    const found = new Map();
    const direct = await getDoc(doc(db, "users", value));
    if (direct.exists()) found.set(direct.id, { id: direct.id, user: direct.data() });
    if (!direct.exists()) {
      const field = /^\d{10}$/.test(value) ? "mobile" : (/^\d{6}$/.test(value) ? "playerId" : "name");
      const matches = await getDocs(query(collection(db, "users"), where(field, "==", value), limit(10)));
      matches.docs.forEach((item) => found.set(item.id, { id: item.id, user: item.data() }));
    }
    renderUsersPanel([...found.values()], { pageNumber: 1, hasNext: false });
    document.querySelector("#userSearch").value = value;
    document.querySelector("#userSearchResult").textContent = `${found.size} user${found.size === 1 ? "" : "s"} found`;
  } catch (error) { serverBusy(error); }
}
async function ensureAdminPlayerId(uid, user) {
  const preferred = /^\d{6}$/.test(String(user.playerId || "")) ? String(user.playerId) : null;
  if (preferred) {
    const reservation = await getDoc(doc(db, "playerIds", preferred));
    if (reservation.exists() && reservation.data().uid === uid) return user;
  }
  for (let attempt = 0; attempt < 12; attempt += 1) {
    const candidate = attempt === 0 && preferred ? preferred : String(Math.floor(100000 + Math.random() * 900000));
    try {
      await runTransaction(db, async (tx) => {
        const reservationRef = doc(db, "playerIds", candidate);
        const reservation = await tx.get(reservationRef);
        if (reservation.exists() && reservation.data().uid !== uid) throw new Error("PLAYER_ID_COLLISION");
        tx.set(reservationRef, { uid, createdAt: serverTimestamp() }, { merge: true });
        tx.update(doc(db, "users", uid), { playerId: candidate });
      });
      return { ...user, playerId: candidate };
    } catch (error) {
      if (error.message !== "PLAYER_ID_COLLISION") throw error;
    }
  }
  throw new Error("Unable to allocate unique Player ID");
}
function userCreatedDate(user) {
  const value = user.createdAt || user.registrationDate || user.authCreationTime || user.creationTime || user.metadata?.creationTime;
  if (!value) return null;
  if (typeof value.toDate === "function") return value.toDate();
  if (Number.isFinite(value.seconds)) return new Date(value.seconds * 1000);
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}
function userRegistration(user) {
  const date = userCreatedDate(user);
  return date ? {
    date: date.toLocaleDateString("en-GB", { day: "2-digit", month: "2-digit", year: "numeric" }),
    time: date.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", hour12: true })
  } : { date: "Not recorded", time: "Not recorded" };
}
function firstPersonalLimit(user, fields) {
  for (const field of fields) {
    const value = Number(user?.[field]);
    if (Number.isFinite(value) && value > 0) return value;
  }
  return "";
}
function personalLimitWrite(value) {
  const parsed = Number(String(value ?? "").trim());
  return Number.isFinite(parsed) && parsed > 0 ? parsed : deleteField();
}
function userRow(item) {
  const user = item.user;
  const registered = userRegistration(user);
  const search = `${user.name || ""} ${user.mobile || ""} ${user.playerId || ""} ${item.id}`.toLowerCase();
  return `<article class="admin-row admin-user-row" data-user-row data-id="${item.id}" data-blocked="${Boolean(user.blocked)}" data-balance-value="${Number(user.walletBalance || 0)}" data-search="${escapeHtml(search)}"><div class="admin-user-meta"><strong>${escapeHtml(user.name || "User")}</strong><span>Mobile: ${escapeHtml(user.mobile || user.email || "-")}</span><span>Player ID: ${escapeHtml(user.playerId || "Not assigned")}</span><span>Referral: ${escapeHtml(user.referralCode || "-")}</span><small>Created Date: ${registered.date}</small><small>Created Time: ${registered.time}</small><small class="${user.blocked ? "blocked" : "active"}">Status: ${user.blocked ? "Blocked" : "Active"}</small></div><label>Balance<input data-balance type="number" value="${Number(user.walletBalance || 0)}"></label><div class="admin-actions"><button data-user-action="view">View Details</button><button data-user-action="balance">Save Balance</button><button data-user-action="block">${user.blocked ? "Unblock" : "Block"}</button><button class="danger" data-user-action="delete">Delete</button></div></article>`;
}
async function handleUserAction(event) {
  const button = event.target.closest("[data-user-action]"); if (!button) return;
  const row = button.closest("[data-user-row]"); const ref = doc(db, "users", row.dataset.id); const action = button.dataset.userAction;
  if (action === "view") { await showUserDetails(row.dataset.id); return; }
  if (action === "balance") {
    const nextBalance = Number(row.querySelector("[data-balance]").value || 0);
    if (nextBalance === Number(row.dataset.balanceValue)) return toast("Balance is already up to date");
    await updateDoc(ref, { walletBalance: nextBalance, updatedAt: serverTimestamp() });
  }
  if (action === "block") await updateDoc(ref, { blocked: row.dataset.blocked !== "true", updatedAt: serverTimestamp() });
  if (action === "delete") { if (!confirm("Delete this user record permanently?")) return; await deleteDoc(ref); }
  toast("User updated successfully"); await loadUsers(true);
}
async function showUserDetails(uid) {
  const snap = await getDoc(doc(db, "users", uid));
  if (!snap.exists()) return toast("User not found", "error");
  const user = snap.data();
  const registered = userRegistration(user);
  const lastLogin = user.lastLoginAt || user.lastLoginTime;
  const lastLoginText = lastLogin ? dateText(lastLogin) : "Not recorded";
  document.querySelector(".admin-user-modal")?.remove();
  const modal = document.createElement("div");
  modal.className = "admin-user-modal";
  const minBuyAmount = firstPersonalLimit(user, ["minBuyAmount", "minimumBuyAmount", "minDepositAmount", "minimumBuy", "minDeposit", "minimumDeposit"]);
  const minWithdrawAmount = firstPersonalLimit(user, ["minWithdrawAmount", "minimumWithdraw", "withdrawLimit", "minimumWithdrawalAmount"]);
  modal.innerHTML = `<section class="admin-user-modal-card"><div class="admin-section-head"><h2>User Details</h2><button type="button" data-close-user-modal>Close</button></div><form id="userSettingsForm" class="admin-user-settings"><label>Name<input name="name" value="${escapeHtml(user.name || "")}" required></label><label>Mobile<input name="mobile" value="${escapeHtml(user.mobile || "")}" required></label><label>Player ID<input value="${escapeHtml(user.playerId || "Not assigned")}" readonly></label><label>Balance<input name="walletBalance" type="number" value="${Number(user.walletBalance || 0)}"></label><label>Today Profit<input value="${Number(user.todayProfit || 0)}" readonly></label><label>Total Profit<input value="${Number(user.totalProfit || 0)}" readonly></label><label>Minimum Deposit Amount<input name="minDepositAmount" type="number" min="1" step="0.01" placeholder="Use global minimum" value="${minBuyAmount}"></label><label>Minimum Withdrawal Amount<input name="minWithdrawAmount" type="number" min="1" step="0.01" placeholder="Use global minimum" value="${minWithdrawAmount}"></label><div class="admin-user-static"><span>Status: <b>${user.blocked ? "Blocked" : "Active"}</b></span><span>Registered: ${registered.date} ${registered.time}</span><span>Last Login: ${lastLoginText}</span></div><button type="submit">Save User Settings</button></form></section>`;
  document.body.appendChild(modal);
  modal.addEventListener("click", (event) => { if (event.target === modal || event.target.closest("[data-close-user-modal]")) modal.remove(); });
  modal.querySelector("#userSettingsForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const updates = {
      name: form.get("name").trim(),
      mobile: form.get("mobile").trim(),
      walletBalance: Number(form.get("walletBalance") || 0),
      minDepositAmount: personalLimitWrite(form.get("minDepositAmount")),
      minBuyAmount: personalLimitWrite(form.get("minDepositAmount")),
      minWithdrawAmount: personalLimitWrite(form.get("minWithdrawAmount")),
      minimumBuyAmount: deleteField(),
      minimumBuy: deleteField(),
      minDeposit: deleteField(),
      minimumDeposit: deleteField(),
      minimumWithdraw: deleteField(),
      withdrawLimit: deleteField(),
      minimumWithdrawalAmount: deleteField(),
      limitsUpdatedAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    };
    await updateDoc(doc(db, "users", uid), updates);
    localStorage.removeItem(`YelePayUserCache:${uid}`);
    toast("User settings updated successfully");
    modal.remove();
    await loadUsers(true);
  });
}
async function loadOrders(reset = false, direction = "current") {
  try {
    const result = await readAdminPage("orders", "payments", reset, direction);
    view().innerHTML = `<div class="admin-panel"><div class="admin-section-head"><h2>UTR Orders</h2>${refreshButton("orders")}</div><div class="admin-list">${result.docs.map((item) => requestRow(item, "order")).join("") || "<p>No orders found.</p>"}</div>${pager("orders", result.pageNumber, result.hasNext)}</div>`;
    view().onclick = async (event) => {
      if (event.target.closest('[data-admin-refresh="orders"]')) return loadOrders(true);
      if (event.target.closest('[data-page-next="orders"]')) return loadOrders(false, "next");
      if (event.target.closest('[data-page-prev="orders"]')) return loadOrders(false, "prev");
      return handleOrderAction(event);
    };
  } catch (error) { serverBusy(error); }
}
function requestRow(item, type) {
  const data = item.data();
  if (type === "order") {
    const paymentUpiId = data.paymentUpiId || data.paymentUpi || data.upiId || data.selectedUpiId || "Not recorded";
    return `<article class="admin-row admin-order-row"><div class="admin-order-details"><span><b>Order ID:</b> ${escapeHtml(data.orderId || item.id)}</span><span><b>User Name:</b> ${escapeHtml(data.userName || "User")}</span><span><b>User Mobile:</b> ${escapeHtml(data.userMobile || "-")}</span><span><b>Amount:</b> ${money(data.amount)}</span><span><b>Commission:</b> ${money(data.commissionAmount)}</span><span><b>UTR Number:</b> ${escapeHtml(data.utrNumber || data.utr || "-")}</span><span><b>Payment UPI ID:</b> ${escapeHtml(paymentUpiId)}</span><span><b>Status:</b> ${escapeHtml(data.status || "processing")}</span><span><b>Created:</b> ${dateText(data.createdAt)}</span></div><div class="admin-actions">${String(data.status).toLowerCase() === "processing" ? `<button data-order-action="completed" data-id="${item.id}">Accept</button><button class="danger" data-order-action="rejected" data-id="${item.id}">Reject</button>` : ""}</div></article>`;
  }
  return `<article class="admin-row request"><div><strong>${escapeHtml(data.orderId || data.withdrawalId || item.id)}</strong><span>${escapeHtml(data.userName || data.userMobile || data.userId || "-")}</span><small>${dateText(data.createdAt)}</small></div><div><strong>${money(data.amount)}</strong><span>${escapeHtml(data.utrNumber || data.method || "-")}</span><small>${escapeHtml(data.status || "processing")}</small></div><div class="admin-actions">${String(data.status).toLowerCase() === "processing" ? `<button data-${type}-action="completed" data-id="${item.id}">Accept</button><button class="danger" data-${type}-action="rejected" data-id="${item.id}">Reject</button>` : ""}</div></article>`;
}
async function handleOrderAction(event) {
  const button = event.target.closest("[data-order-action]"); if (!button) return;
  const requestRef = doc(db, "payments", button.dataset.id); const nextStatus = button.dataset.orderAction;
  await runTransaction(db, async (tx) => {
    const requestSnap = await tx.get(requestRef); if (!requestSnap.exists()) throw new Error("Order not found");
    const data = requestSnap.data(); const commission = Number(data.commissionAmount || 0); const shouldCredit = nextStatus === "completed" && !data.credited;
    const update = { status: nextStatus, updatedAt: serverTimestamp() };
    if (nextStatus === "completed") update.approvedAt = serverTimestamp();
    if (shouldCredit) update.credited = true;
    tx.update(requestRef, update);
    if (shouldCredit) tx.update(doc(db, "users", data.userId), { walletBalance: increment(Number(data.amount || 0) + commission), todayProfit: increment(commission), totalProfit: increment(commission), totalIncome: increment(commission) });
  });
  toast(`Order ${nextStatus}`); if (page === "payments") await loadPayments(); else await loadOrders(true);
}
async function loadWithdrawals(reset = false, direction = "current") {
  try {
    const result = await readAdminPage("withdrawals", "withdrawals", reset, direction);
    view().innerHTML = `<div class="admin-panel"><div class="admin-section-head"><h2>Withdrawal Requests</h2>${refreshButton("withdrawals")}</div><div class="admin-list">${result.docs.map((item) => requestRow(item, "withdraw")).join("") || "<p>No requests found.</p>"}</div>${pager("withdrawals", result.pageNumber, result.hasNext)}</div>`;
    view().onclick = async (event) => {
      if (event.target.closest('[data-admin-refresh="withdrawals"]')) return loadWithdrawals(true);
      if (event.target.closest('[data-page-next="withdrawals"]')) return loadWithdrawals(false, "next");
      if (event.target.closest('[data-page-prev="withdrawals"]')) return loadWithdrawals(false, "prev");
      const button = event.target.closest("[data-withdraw-action]");
      if (!button) return;
      await updateDoc(doc(db, "withdrawals", button.dataset.id), { status: button.dataset.withdrawAction, updatedAt: serverTimestamp(), approvedAt: button.dataset.withdrawAction === "completed" ? serverTimestamp() : null });
      toast("Withdrawal updated");
      await loadWithdrawals(true);
    };
  } catch (error) { serverBusy(error); }
}

async function adminQrFileToDataUrl(file) {
  if (!file) return "";
  if (!/^image\/(png|jpe?g|webp)$/i.test(file.type || "")) throw new Error("Please select a PNG, JPG, or WEBP image.");
  if (file.size > 8 * 1024 * 1024) throw new Error("Scanner image is too large. Maximum source size is 8 MB.");

  const source = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("Could not read scanner image."));
    reader.readAsDataURL(file);
  });

  const image = await new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Invalid scanner image."));
    img.src = source;
  });

  const maxSide = 650;
  const scale = Math.min(1, maxSide / Math.max(image.naturalWidth || image.width, image.naturalHeight || image.height));
  const width = Math.max(1, Math.round((image.naturalWidth || image.width) * scale));
  const height = Math.max(1, Math.round((image.naturalHeight || image.height) * scale));
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  ctx.imageSmoothingEnabled = false;
  ctx.drawImage(image, 0, 0, width, height);

  let output = canvas.toDataURL("image/webp", 0.94);
  if (output.length > 500000) {
    const smaller = document.createElement("canvas");
    const ratio = Math.min(1, 440 / Math.max(width, height));
    smaller.width = Math.max(1, Math.round(width * ratio));
    smaller.height = Math.max(1, Math.round(height * ratio));
    const sctx = smaller.getContext("2d");
    sctx.imageSmoothingEnabled = false;
    sctx.drawImage(canvas, 0, 0, smaller.width, smaller.height);
    output = smaller.toDataURL("image/webp", 0.9);
  }
  if (output.length > 650000) throw new Error("Scanner image is still too large. Please upload a cropped QR image.");
  return output;
}

async function loadPayments() {
  const ref = doc(db, "settings", "main");
  const [snap, requestSnapshot] = await Promise.all([
    getDoc(ref),
    getDocs(query(collection(db, "payments"), orderBy("createdAt", "desc"), limit(20)))
  ]);
  const upis = Array.isArray(snap.data()?.adminUpis) ? [...snap.data().adminUpis] : [];

  const upiRows = upis.map((upi, index) => `
    <article class="admin-row admin-upi-row">
      <div class="admin-upi-info">
        <div class="admin-upi-scanner">
          ${upi.qrImage
            ? `<img src="${escapeHtml(upi.qrImage)}" alt="Scanner for ${escapeHtml(upi.upiId)}">`
            : `<div class="admin-upi-noqr">No QR</div>`}
        </div>
        <div>
          <strong>${escapeHtml(upi.holderName || "YelePay")}</strong>
          <span>${escapeHtml(upi.upiId || "")}</span>
          <small>${escapeHtml(upi.mobile || "")}</small>
        </div>
      </div>
      <div class="admin-actions">
        <button type="button" data-edit-upi="${index}">Edit</button>
        <button type="button" data-change-qr="${index}">Change Scanner</button>
        <input type="file" data-change-qr-file="${index}" accept="image/png,image/jpeg,image/webp" hidden>
        <button type="button" class="danger" data-remove-upi="${index}">Delete</button>
      </div>
    </article>
  `).join("");

  view().innerHTML = `
    <div class="admin-panel">
      <div class="admin-section-head">
        <div>
          <p>Control checkout payment details</p>
          <h2>Payment / UPI & Scanner</h2>
        </div>
      </div>

      <form id="upiForm" class="admin-form admin-upi-form">
        <input name="holderName" placeholder="Holder name" required>
        <input name="upiId" placeholder="UPI ID e.g. name@bank" required>
        <input name="mobile" placeholder="Mobile">
        <label class="admin-qr-picker">
          <span>Scanner / QR image</span>
          <input id="adminQrInput" name="qrImage" type="file" accept="image/png,image/jpeg,image/webp" required>
          <div class="admin-qr-preview" id="adminQrPreview"><span>Select QR image</span></div>
        </label>
        <button>Add UPI + Scanner</button>
      </form>

      <div class="admin-list">${upiRows || "<p>No admin UPI configured.</p>"}</div>
    </div>

    <div class="admin-panel admin-payment-requests">
      <h2>Payment Requests</h2>
      <div class="admin-list">${requestSnapshot.docs.map((item) => requestRow(item, "order")).join("") || "<p>No payment requests found.</p>"}</div>
    </div>
  `;

  const qrInput = document.querySelector("#adminQrInput");
  const qrPreview = document.querySelector("#adminQrPreview");
  qrInput?.addEventListener("change", () => {
    const file = qrInput.files?.[0];
    if (!file) {
      qrPreview.innerHTML = "<span>Select QR image</span>";
      return;
    }
    const url = URL.createObjectURL(file);
    qrPreview.innerHTML = `<img src="${url}" alt="Selected scanner preview">`;
  });

  document.querySelector("#upiForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    if (upis.length >= 5) return toast("Maximum 5 admin UPI accounts allowed.", "error");

    const data = new FormData(event.currentTarget);
    const holderName = String(data.get("holderName") || "").trim();
    const upiId = String(data.get("upiId") || "").trim();
    const mobile = String(data.get("mobile") || "").trim();
    const file = event.currentTarget.elements.qrImage?.files?.[0];

    if (!/^[^\s@]+@[^\s@]+$/.test(upiId)) return toast("Enter a valid UPI ID containing @.", "error");
    if (!file) return toast("Please select a scanner / QR image.", "error");

    try {
      const qrImage = await adminQrFileToDataUrl(file);
      upis.push({ holderName, upiId, mobile, qrImage });
      await setDoc(ref, { adminUpis: upis, updatedAt: serverTimestamp() }, { merge: true });
      localStorage.removeItem("YelePaySettingsCacheV1");
      toast("UPI and scanner added");
      await loadPayments();
    } catch (error) {
      toast(error?.message || "Could not save scanner.", "error");
    }
  });

  view().onchange = async (event) => {
    const input = event.target.closest("[data-change-qr-file]");
    if (!input) return;
    const index = Number(input.dataset.changeQrFile);
    const file = input.files?.[0];
    if (!file || !upis[index]) return;
    try {
      upis[index] = { ...upis[index], qrImage: await adminQrFileToDataUrl(file) };
      await setDoc(ref, { adminUpis: upis, updatedAt: serverTimestamp() }, { merge: true });
      localStorage.removeItem("YelePaySettingsCacheV1");
      toast("Scanner updated");
      await loadPayments();
    } catch (error) {
      toast(error?.message || "Could not update scanner.", "error");
    }
  };

  view().onclick = async (event) => {
    if (event.target.closest("[data-order-action]")) {
      await handleOrderAction(event);
      return;
    }

    const qrButton = event.target.closest("[data-change-qr]");
    if (qrButton) {
      document.querySelector(`[data-change-qr-file="${qrButton.dataset.changeQr}"]`)?.click();
      return;
    }

    const remove = event.target.closest("[data-remove-upi]");
    const edit = event.target.closest("[data-edit-upi]");

    if (remove) {
      upis.splice(Number(remove.dataset.removeUpi), 1);
    } else if (edit) {
      const index = Number(edit.dataset.editUpi);
      const current = upis[index];
      const holderName = prompt("Account holder name", current.holderName || "");
      if (holderName === null) return;
      const upiId = prompt("UPI ID", current.upiId || "");
      if (upiId === null || !/^[^\s@]+@[^\s@]+$/.test(upiId.trim())) return toast("Enter a valid UPI ID", "error");
      const mobile = prompt("Mobile number", current.mobile || "");
      if (mobile === null) return;

      upis[index] = {
        ...current,
        holderName: holderName.trim(),
        upiId: upiId.trim(),
        mobile: mobile.trim()
      };
    } else {
      return;
    }

    await setDoc(ref, { adminUpis: upis, updatedAt: serverTimestamp() }, { merge: true });
    localStorage.removeItem("YelePaySettingsCacheV1");
    toast("UPI settings updated");
    await loadPayments();
  };
}

async function loadGifts( {
  const snap = await getDocs(query(collection(db, "giftCodes"), limit(20)));
  view().innerHTML = `<div class="admin-panel"><h2>Gift Codes</h2><form id="giftForm" class="admin-form"><input name="code" placeholder="Gift code" required><input name="amount" type="number" min="1" placeholder="Reward amount" required><input name="limit" type="number" min="1" placeholder="Usage limit" required><input name="expiry" type="date"><button>Generate</button></form><div class="admin-list">${snap.docs.map((item) => { const data = item.data(); return `<article class="admin-row"><div><strong>${escapeHtml(data.code || item.id)}</strong><span>${money(data.rewardAmount)}</span><small>${Number(data.usedCount || 0)} / ${Number(data.usageLimit || 1)} used</small></div><button class="danger" data-delete-gift="${item.id}">Delete</button></article>`; }).join("")}</div></div>`;
  document.querySelector("#giftForm").addEventListener("submit", async (event) => { event.preventDefault(); const data = new FormData(event.currentTarget); const code = String(data.get("code")).trim().toUpperCase(); await setDoc(doc(db, "giftCodes", code), { code, rewardAmount: Number(data.get("amount")), usageLimit: Number(data.get("limit")), usedCount: 0, active: true, expiryDate: data.get("expiry") || "", createdAt: serverTimestamp() }); toast("Gift code generated"); await loadGifts(); });
  view().onclick = async (event) => { const button = event.target.closest("[data-delete-gift]"); if (!button) return; await deleteDoc(doc(db, "giftCodes", button.dataset.deleteGift)); await loadGifts(); };
}
async function loadBanner() { await loadSingleContent("banner", "Home Banner", ["image", "link"]); }
async function loadPopup() { await loadSingleContent("popup", "App Popup", ["title", "message", "image", "enabled"]); }
async function loadSingleContent(id, title, fields) {
  const ref = doc(db, "settings", id); const snap = await getDoc(ref); const data = snap.data() || {};
  view().innerHTML = `<div class="admin-panel"><h2>${title}</h2><form id="contentForm" class="admin-form vertical">${fields.map((field) => field === "enabled" ? `<label class="admin-check"><input name="enabled" type="checkbox" ${data.enabled ? "checked" : ""}> Enabled</label>` : field === "message" ? `<textarea name="message" placeholder="Message">${escapeHtml(data.message || "")}</textarea>` : `<input name="${field}" value="${escapeHtml(data[field] || "")}" placeholder="${field}">`).join("")}<button>Save ${title}</button></form></div>`;
  document.querySelector("#contentForm").addEventListener("submit", async (event) => { event.preventDefault(); const form = new FormData(event.currentTarget); const payload = {}; fields.forEach((field) => payload[field] = field === "enabled" ? event.currentTarget.elements.enabled.checked : String(form.get(field) || "").trim()); payload.updatedAt = serverTimestamp(); await setDoc(ref, payload, { merge: true }); localStorage.removeItem("YelePayHomeContentCacheV1"); toast(`${title} updated`); });
}
async function loadTutorials() {
  const snap = await getDocs(query(collection(db, "tutorials"), orderBy("createdAt", "desc"), limit(20)));
  view().innerHTML = `<div class="admin-panel"><h2>Tutorials</h2><form id="tutorialForm" class="admin-form"><input name="title" placeholder="Title" required><input name="url" placeholder="Video / page URL" required><input name="thumbnail" placeholder="Thumbnail URL"><button>Add Tutorial</button></form><div class="admin-list">${snap.docs.map((item) => { const data = item.data(); return `<article class="admin-row"><div><strong>${escapeHtml(data.title)}</strong><span>${escapeHtml(data.url)}</span></div><button class="danger" data-delete-tutorial="${item.id}">Delete</button></article>`; }).join("")}</div></div>`;
  document.querySelector("#tutorialForm").addEventListener("submit", async (event) => { event.preventDefault(); const data = new FormData(event.currentTarget); await addDoc(collection(db, "tutorials"), { title: data.get("title").trim(), url: data.get("url").trim(), thumbnail: data.get("thumbnail").trim(), createdAt: serverTimestamp() }); localStorage.removeItem("YelePayHomeContentCacheV1"); toast("Tutorial added"); await loadTutorials(); });
  view().onclick = async (event) => { const button = event.target.closest("[data-delete-tutorial]"); if (!button) return; await deleteDoc(doc(db, "tutorials", button.dataset.deleteTutorial)); localStorage.removeItem("YelePayHomeContentCacheV1"); await loadTutorials(); };
}
async function loadSettings() {
  const ref = doc(db, "settings", "main"); const snap = await getDoc(ref); const data = snap.data() || {};
  view().innerHTML = `<div class="admin-panel"><h2>App Settings</h2><form id="settingsAdminForm" class="admin-form vertical"><label>Order Profit Percentage<input name="orderProfitPercentage" type="number" step="0.1" value="${Number(data.orderProfitPercentage ?? 3.5)}"></label><label>Signup Bonus Amount<input name="signupBonusAmount" type="number" min="0" step="0.01" value="${Number(data.signupBonusAmount || 0)}"></label><label>Minimum Deposit Amount<input name="minDepositAmount" type="number" min="0" step="0.01" value="${Number(data.minDepositAmount || 1000)}"></label><label>Minimum Withdrawal<input name="minWithdraw" type="number" value="${Number(data.minWithdraw || 1500)}"></label><label>Minimum Completed Orders Before Withdrawal<input name="minCompletedOrdersForWithdrawal" type="number" min="1" step="1" value="${Number(data.minCompletedOrdersForWithdrawal || 3)}"></label><label>Telegram Group Link<input name="telegramGroupLink" value="${escapeHtml(data.telegramGroupLink || "")}"></label><label>Telegram Support Link<input name="telegramSupportLink" value="${escapeHtml(data.telegramSupportLink || "")}"></label><label>App Download Link<input name="appDownloadLink" value="${escapeHtml(data.appDownloadLink || "")}"></label><button>Save Settings</button></form></div>`;
  document.querySelector("#settingsAdminForm").addEventListener("submit", async (event) => { event.preventDefault(); const form = new FormData(event.currentTarget); await setDoc(ref, { orderProfitPercentage: Number(form.get("orderProfitPercentage") || 3.5), signupBonusAmount: Math.max(0, Number(form.get("signupBonusAmount") || 0)), minDepositAmount: Math.max(0, Number(form.get("minDepositAmount") || 1000)), minWithdraw: Number(form.get("minWithdraw") || 1500), minCompletedOrdersForWithdrawal: Math.max(1, Math.floor(Number(form.get("minCompletedOrdersForWithdrawal") || 3))), telegramGroupLink: form.get("telegramGroupLink").trim(), telegramSupportLink: form.get("telegramSupportLink").trim(), appDownloadLink: form.get("appDownloadLink").trim(), updatedAt: serverTimestamp() }, { merge: true }); localStorage.removeItem("YelePaySettingsCacheV1"); toast("Settings Updated Successfully"); });
}

if (!isConfigured) {
  root.innerHTML = `<main class="admin-login"><div class="admin-login-card"><h1>Firebase setup required</h1><p>Add your Firebase config in firebase.js.</p><a href="dashboard.html">Back to YelePay</a></div></main>`;
} else {
  boot().catch((error) => {
    serverBusy(error);
    root.innerHTML = `<main class="admin-login"><div class="admin-login-card"><h1>Admin temporarily unavailable</h1><button type="button" onclick="location.reload()">Try Again</button><a href="dashboard.html">Back to YelePay</a></div></main>`;
  });
}






// Final mobile drawer fallback
document.addEventListener("click", (event) => {
  const menuButton = event.target.closest("#adminMenu");
  const backdrop = event.target.closest("#adminDrawerBackdrop");
  const sidebar = document.querySelector(".admin-sidebar");
  const overlay = document.querySelector("#adminDrawerBackdrop");
  if (menuButton && sidebar) {
    sidebar.classList.add("open");
    overlay?.classList.add("open");
    document.body.classList.add("admin-drawer-open");
  }
  if (backdrop && sidebar) {
    sidebar.classList.remove("open");
    overlay?.classList.remove("open");
    document.body.classList.remove("admin-drawer-open");
  }
});
