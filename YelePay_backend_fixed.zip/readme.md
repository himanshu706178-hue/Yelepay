﻿# YelePay Clean Source

## Firebase setup

1. Create a Firebase web app and enable **Authentication > Email/Password**.
2. Create a Firestore database.
3. The YelePay Firebase web configuration is already applied in `firebase.js`.
4. Deploy the included rules and indexes:

   `firebase deploy --only firestore:rules,firestore:indexes`

Firestore collections are created automatically on their first write.

## Run locally

Serve this folder through any static server. ES modules do not work reliably by double-clicking HTML files.

`npx serve .`

Then open the displayed local URL. The folder can also be deployed directly to Netlify.

## Admin

The initial admin-panel password is `himashu123456`. Change the SHA-256 value stored at `settings/main.adminPasswordHash` immediately after setup.

The included rules are a functional authenticated starter policy. Before handling real money, replace client-side admin authorization with Firebase custom claims or a trusted backend and tighten collection-level rules.



