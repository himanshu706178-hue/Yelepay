import { initializeApp } from "https://www.gstatic.com/firebasejs/12.0.0/firebase-app.js";
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  sendPasswordResetEmail,
  onAuthStateChanged,
  signOut,
  updateProfile,
  updatePassword
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-auth.js";
import {
  getFirestore,
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  getCountFromServer,
  serverTimestamp,
  increment,
  runTransaction,
  writeBatch
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyBUNV7UsQF33ol6drWXNK-Kx433hCt-kj4",
  authDomain: "zivapay.firebaseapp.com",
  projectId: "zivapay",
  storageBucket: "zivapay.firebasestorage.app",
  messagingSenderId: "683262170372",
  appId: "1:683262170372:web:afb69f8d8675becc34ec51",
  measurementId: "G-57B4MXJR0Y"
};

const isConfigured = Boolean(firebaseConfig?.apiKey && firebaseConfig?.projectId);
const app = isConfigured ? initializeApp(firebaseConfig) : null;
const auth = isConfigured ? getAuth(app) : null;
const db = isConfigured ? getFirestore(app) : null;
const REQUIRED_COLLECTIONS = [
  "users",
  "orders",
  "payments",
  "withdrawals",
  "giftCodes",
  "settings",
  "tutorials",
  "popups",
  "sellingRequests",
  "notifications",
  "transactions",
  "support",
  "adminLogs"
];
const COLLECTION_SCHEMA_CACHE_KEY = "YelePayCollectionSchemaV1";

const defaults = {
  profitPercent: 4,
  orderProfitPercentage: 3.5,
  coinPrice: 72.5,
  platformPrice: 86.2,
  minPurchase: 100,
  minDepositAmount: 1000,
  maxPurchase: 5000,
  minWithdraw: 120,
  maxWithdraw: 25000,
  minCompletedOrdersForWithdrawal: 3,
  welcomeBonus: 50,
  signupBonusAmount: 0,
  adminUpis: [
    { holderName: "YelePay India", upiId: "YelePayindia@upi", mobile: "9999999999", qrImage: "" }
  ],
  orderDuration: 2,
  dailyOrderLimit: 7,
  telegramGroup: "",
  telegramId: "",
  telegramGroupLink: "",
  telegramSupportLink: "",
  appDownloadLink: "",
  registrationEnabled: true,
  purchaseEnabled: true,
  withdrawEnabled: true,
  requiredCollections: REQUIRED_COLLECTIONS
};

const DEFAULT_ADMIN_PASSWORD_HASH = "19224af73e55bf1caa3eaf8a46c363a41f43f96b11f8a7406a446d159932d38c";
const LEGACY_ADMIN_PASSWORD_HASHES = new Set([
  "e5bf4ea9d3ca8e7b01358689ef7fa132071ecb0adc8fddf8d4b268c868354707",
  "7eea094d9b8e92a7c8bc7d7503bb11af941c8d2a9a594db728f26f86af82a31f"
]);
const ADMIN_SESSION_KEY = "YelePayAdminAccessHash";
const AVATAR_OPTIONS = Array.from({ length: 18 }, (_, index) => ({
  id: `avatar-${String(index + 1).padStart(2, "0")}`,
  url: `images/avatars/avatar-${String(index + 1).padStart(2, "0")}.jpg`
}));
const SETTINGS_CACHE_KEY = "YelePaySettingsCacheV1";
const SETTINGS_CACHE_TTL = 10 * 60 * 1000;
const USER_CACHE_TTL = 5 * 60 * 1000;
const BALANCE_CACHE_TTL = 60 * 1000;
const LOGIN_WRITE_TTL = 12 * 60 * 60 * 1000;
const HOME_CONTENT_CACHE_KEY = "YelePayHomeContentCacheV1";

function getOrderProfitPercentage() {
  const percentage = Number(settings.orderProfitPercentage);
  return Number.isFinite(percentage) && percentage >= 0 ? percentage : 3.5;
}

const demoUser = {
  uid: "ZP240819",
  name: "Demo User",
  mobile: "9876543210",
  email: "demo@zivapay.app",
  photoURL: "",
  referralCode: "YelePay819",
  referredBy: "",
  teamCount: 12,
  walletBalance: 14520,
  todayOrders: 3,
  todayProfit: 418,
  totalProfit: 12780,
  totalIncome: 19340,
  teamIncome: 3250,
  teamProfit: 1870,
  createdAt: new Date().toISOString()
};

const proofNames = ["Aarav", "Riya", "Kabir", "Nisha", "Imran", "Meera", "Dev", "Sana", "Yash", "Anika"];
const proofTypes = ["Live Purchase Success", "Live Withdraw Success"];
const orderSeeds = [294, 341, 399, 448, 527, 683, 875, 1249, 1687, 2389, 3647, 4891];

const translations = {
  English: {
    safe: "Safe",
    availableBalance: "Available Balance",
    detail: "Detail",
    todayEarnings: "Today's earnings",
    availableBonus: "Available Bonus",
    claim: "Claim",
    bills: "Bills",
    buyHistory: "Buy history",
    sellHistory: "Sell history",
    service: "Service",
    otherFunctions: "Other functions",
    bonus: "Bonus",
    redeemGift: "Redeem Gift",
    inbox: "Inbox",
    password: "Password",
    pin: "Pin",
    language: "Language",
    settings: "Settings",
    appDownload: "Install YelePay App",
    logout: "Log out",
    profileSettings: "Profile Settings",
    changePassword: "Change Password",
    YelePayService: "YelePay Service",
    recentActivity: "Recent Activity",
    securityPinTitle: "Security PIN",
    selectLanguage: "Select Language",
    name: "Name",
    mobile: "Mobile",
    photoUrl: "Profile Photo URL",
    saveProfile: "Save Profile",
    newPassword: "New Password",
    giftCode: "Gift Code",
    enterGiftCode: "Enter gift code",
    applyGiftCode: "Apply Gift Code",
    noRecentActivity: "No Recent Activity",
    securityPin: "6 Digit Security PIN",
    enterPin: "Enter 6 digit PIN",
    savePin: "Save PIN",
    joinTelegram: "Join Telegram Group",
    communityUpdates: "Community updates and announcements",
    contactSupport: "Contact Telegram Support",
    supportDescription: "Chat with the YelePay support team",
    loginSuccess: "Account Login Successfully"
  },
  Hindi: {
    safe: "à¤¸à¥à¤°à¤•à¥à¤·à¤¿à¤¤",
    availableBalance: "à¤‰à¤ªà¤²à¤¬à¥à¤§ à¤¬à¥ˆà¤²à¥‡à¤‚à¤¸",
    detail: "à¤µà¤¿à¤µà¤°à¤£",
    todayEarnings: "à¤†à¤œ à¤•à¥€ à¤•à¤®à¤¾à¤ˆ",
    availableBonus: "à¤‰à¤ªà¤²à¤¬à¥à¤§ à¤¬à¥‹à¤¨à¤¸",
    claim: "à¤•à¥à¤²à¥‡à¤®",
    bills: "à¤¬à¤¿à¤²à¥à¤¸",
    buyHistory: "à¤–à¤°à¥€à¤¦ à¤‡à¤¤à¤¿à¤¹à¤¾à¤¸",
    sellHistory: "à¤¬à¤¿à¤•à¥à¤°à¥€ à¤‡à¤¤à¤¿à¤¹à¤¾à¤¸",
    service: "à¤¸à¥‡à¤µà¤¾",
    otherFunctions: "à¤…à¤¨à¥à¤¯ à¤¸à¥à¤µà¤¿à¤§à¤¾à¤à¤‚",
    bonus: "à¤¬à¥‹à¤¨à¤¸",
    redeemGift: "à¤—à¤¿à¤«à¥à¤Ÿ à¤°à¤¿à¤¡à¥€à¤® à¤•à¤°à¥‡à¤‚",
    inbox: "à¤‡à¤¨à¤¬à¥‰à¤•à¥à¤¸",
    password: "à¤ªà¤¾à¤¸à¤µà¤°à¥à¤¡",
    pin: "à¤ªà¤¿à¤¨",
    language: "à¤­à¤¾à¤·à¤¾",
    settings: "à¤¸à¥‡à¤Ÿà¤¿à¤‚à¤—à¥à¤¸",
    appDownload: "YelePay à¤à¤ª à¤‡à¤‚à¤¸à¥à¤Ÿà¥‰à¤² à¤•à¤°à¥‡à¤‚",
    logout: "à¤²à¥‰à¤— à¤†à¤‰à¤Ÿ",
    profileSettings: "à¤ªà¥à¤°à¥‹à¤«à¤¾à¤‡à¤² à¤¸à¥‡à¤Ÿà¤¿à¤‚à¤—à¥à¤¸",
    changePassword: "à¤ªà¤¾à¤¸à¤µà¤°à¥à¤¡ à¤¬à¤¦à¤²à¥‡à¤‚",
    YelePayService: "YelePay à¤¸à¥‡à¤µà¤¾",
    recentActivity: "à¤¹à¤¾à¤² à¤•à¥€ à¤—à¤¤à¤¿à¤µà¤¿à¤§à¤¿",
    securityPinTitle: "à¤¸à¥à¤°à¤•à¥à¤·à¤¾ à¤ªà¤¿à¤¨",
    selectLanguage: "à¤­à¤¾à¤·à¤¾ à¤šà¥à¤¨à¥‡à¤‚",
    name: "à¤¨à¤¾à¤®",
    mobile: "à¤®à¥‹à¤¬à¤¾à¤‡à¤²",
    photoUrl: "à¤ªà¥à¤°à¥‹à¤«à¤¾à¤‡à¤² à¤«à¥‹à¤Ÿà¥‹ URL",
    saveProfile: "à¤ªà¥à¤°à¥‹à¤«à¤¾à¤‡à¤² à¤¸à¥‡à¤µ à¤•à¤°à¥‡à¤‚",
    newPassword: "à¤¨à¤¯à¤¾ à¤ªà¤¾à¤¸à¤µà¤°à¥à¤¡",
    giftCode: "à¤—à¤¿à¤«à¥à¤Ÿ à¤•à¥‹à¤¡",
    enterGiftCode: "à¤—à¤¿à¤«à¥à¤Ÿ à¤•à¥‹à¤¡ à¤¦à¤°à¥à¤œ à¤•à¤°à¥‡à¤‚",
    applyGiftCode: "à¤—à¤¿à¤«à¥à¤Ÿ à¤•à¥‹à¤¡ à¤²à¤¾à¤—à¥‚ à¤•à¤°à¥‡à¤‚",
    noRecentActivity: "à¤•à¥‹à¤ˆ à¤¹à¤¾à¤² à¤•à¥€ à¤—à¤¤à¤¿à¤µà¤¿à¤§à¤¿ à¤¨à¤¹à¥€à¤‚",
    securityPin: "6 à¤…à¤‚à¤•à¥‹à¤‚ à¤•à¤¾ à¤¸à¥à¤°à¤•à¥à¤·à¤¾ à¤ªà¤¿à¤¨",
    enterPin: "6 à¤…à¤‚à¤•à¥‹à¤‚ à¤•à¤¾ à¤ªà¤¿à¤¨ à¤¦à¤°à¥à¤œ à¤•à¤°à¥‡à¤‚",
    savePin: "à¤ªà¤¿à¤¨ à¤¸à¥‡à¤µ à¤•à¤°à¥‡à¤‚",
    joinTelegram: "Telegram à¤—à¥à¤°à¥à¤ª à¤¸à¥‡ à¤œà¥à¤¡à¤¼à¥‡à¤‚",
    communityUpdates: "à¤¸à¤®à¥à¤¦à¤¾à¤¯ à¤…à¤ªà¤¡à¥‡à¤Ÿ à¤”à¤° à¤˜à¥‹à¤·à¤£à¤¾à¤à¤‚",
    contactSupport: "Telegram à¤¸à¤ªà¥‹à¤°à¥à¤Ÿ à¤¸à¥‡ à¤¸à¤‚à¤ªà¤°à¥à¤• à¤•à¤°à¥‡à¤‚",
    supportDescription: "YelePay à¤¸à¤ªà¥‹à¤°à¥à¤Ÿ à¤Ÿà¥€à¤® à¤¸à¥‡ à¤šà¥ˆà¤Ÿ à¤•à¤°à¥‡à¤‚",
    loginSuccess: "à¤…à¤•à¤¾à¤‰à¤‚à¤Ÿ à¤²à¥‰à¤—à¤¿à¤¨ à¤¸à¤«à¤²"
  }
};

const pageTextTranslations = {
  ...Object.fromEntries(Object.keys(translations.English).map((key) => [translations.English[key], translations.Hindi[key]])),
  Home: "à¤¹à¥‹à¤®",
  Buy: "à¤–à¤°à¥€à¤¦à¥‡à¤‚",
  buy: "à¤–à¤°à¥€à¤¦à¥‡à¤‚",
  Withdrawal: "à¤¨à¤¿à¤•à¤¾à¤¸à¥€",
  Withdraw: "à¤¨à¤¿à¤•à¤¾à¤¸à¥€ à¤•à¤°à¥‡à¤‚",
  Team: "à¤Ÿà¥€à¤®",
  Profile: "à¤ªà¥à¤°à¥‹à¤«à¤¾à¤‡à¤²",
  Purchase: "à¤–à¤°à¥€à¤¦",
  Sell: "à¤¬à¥‡à¤šà¥‡à¤‚",
  sell: "à¤¬à¥‡à¤šà¥‡à¤‚",
  Earn: "à¤•à¤®à¤¾à¤à¤‚",
  Learn: "à¤¸à¥€à¤–à¥‡à¤‚",
  More: "à¤…à¤§à¤¿à¤•",
  Corporate: "à¤•à¥‰à¤°à¥à¤ªà¥‹à¤°à¥‡à¤Ÿ",
  Policy: "à¤¨à¥€à¤¤à¤¿",
  "Download App": "à¤à¤ª à¤¡à¤¾à¤‰à¤¨à¤²à¥‹à¤¡",
  "Download YelePay App": "YelePay à¤à¤ª à¤¡à¤¾à¤‰à¤¨à¤²à¥‹à¤¡ à¤•à¤°à¥‡à¤‚",
  "Get the latest YelePay application": "à¤¨à¤µà¥€à¤¨à¤¤à¤® YelePay à¤à¤ª à¤ªà¥à¤°à¤¾à¤ªà¥à¤¤ à¤•à¤°à¥‡à¤‚",
  "Download Now": "à¤…à¤­à¥€ à¤¡à¤¾à¤‰à¤¨à¤²à¥‹à¤¡ à¤•à¤°à¥‡à¤‚",
  "App Download Link": "à¤à¤ª à¤¡à¤¾à¤‰à¤¨à¤²à¥‹à¤¡ à¤²à¤¿à¤‚à¤•",
  "YeleCoin Balance": "YeleCoin à¤¬à¥ˆà¤²à¥‡à¤‚à¤¸",
  "Today orders": "à¤†à¤œ à¤•à¥‡ à¤‘à¤°à¥à¤¡à¤°",
  "Today profit": "à¤†à¤œ à¤•à¤¾ à¤²à¤¾à¤­",
  "Total Profit": "à¤•à¥à¤² à¤²à¤¾à¤­",
  "Profit Summary": "à¤²à¤¾à¤­ à¤¸à¤¾à¤°à¤¾à¤‚à¤¶",
  "Earnings Details": "à¤•à¤®à¤¾à¤ˆ à¤•à¤¾ à¤µà¤¿à¤µà¤°à¤£",
  "Auto Refresh": "à¤‘à¤Ÿà¥‹ à¤°à¤¿à¤«à¥à¤°à¥‡à¤¶",
  "Live complete proofs": "à¤²à¤¾à¤‡à¤µ à¤ªà¥‚à¤°à¥à¤£ à¤­à¥à¤—à¤¤à¤¾à¤¨",
  "Click learn how to buy": "à¤–à¤°à¥€à¤¦à¤¨à¥‡ à¤•à¤¾ à¤¤à¤°à¥€à¤•à¤¾ à¤œà¤¾à¤¨à¥‡à¤‚",
  "New rules": "à¤¨à¤ à¤¨à¤¿à¤¯à¤®",
  "New tutorials": "à¤¨à¤ à¤Ÿà¥à¤¯à¥‚à¤Ÿà¥‹à¤°à¤¿à¤¯à¤²",
  "click for more": "à¤…à¤§à¤¿à¤• à¤œà¤¾à¤¨à¤•à¤¾à¤°à¥€ à¤•à¥‡ à¤²à¤¿à¤ à¤•à¥à¤²à¤¿à¤• à¤•à¤°à¥‡à¤‚",
  "Platform Price(Rs)": "à¤ªà¥à¤²à¥‡à¤Ÿà¤«à¥‰à¤°à¥à¤® à¤•à¥€à¤®à¤¤ (à¤°à¥)",
  "Binance Price(Rs)": "Binance à¤•à¥€à¤®à¤¤ (à¤°à¥)",
  "Buy YelePay coin use rupee": "à¤°à¥à¤ªà¤¯à¥‡ à¤¸à¥‡ YelePay à¤•à¥‰à¤‡à¤¨ à¤–à¤°à¥€à¤¦à¥‡à¤‚",
  "Buy YelePay Coin use rupees": "à¤°à¥à¤ªà¤¯à¥‡ à¤¸à¥‡ YelePay à¤•à¥‰à¤‡à¤¨ à¤–à¤°à¥€à¤¦à¥‡à¤‚",
  "Buy YelePay coin use usdt": "USDT à¤¸à¥‡ YelePay à¤•à¥‰à¤‡à¤¨ à¤–à¤°à¥€à¤¦à¥‡à¤‚",
  "Upload Corporate Card": "à¤•à¥‰à¤°à¥à¤ªà¥‹à¤°à¥‡à¤Ÿ à¤•à¤¾à¤°à¥à¤¡ à¤…à¤ªà¤²à¥‹à¤¡ à¤•à¤°à¥‡à¤‚",
  "Purchase History": "à¤–à¤°à¥€à¤¦ à¤‡à¤¤à¤¿à¤¹à¤¾à¤¸",
  Small: "à¤›à¥‹à¤Ÿà¤¾",
  Medium: "à¤®à¤§à¥à¤¯à¤®",
  Large: "à¤¬à¤¡à¤¼à¤¾",
  "Generate Orders": "à¤‘à¤°à¥à¤¡à¤° à¤¬à¤¨à¤¾à¤à¤‚",
  "Refresh Orders": "à¤‘à¤°à¥à¤¡à¤° à¤°à¤¿à¤«à¥à¤°à¥‡à¤¶ à¤•à¤°à¥‡à¤‚",
  "Admin limits": "à¤à¤¡à¤®à¤¿à¤¨ à¤¸à¥€à¤®à¤¾",
  Amount: "à¤°à¤¾à¤¶à¤¿",
  "Account holder": "à¤–à¤¾à¤¤à¤¾à¤§à¤¾à¤°à¤•",
  Copy: "à¤•à¥‰à¤ªà¥€",
  "Pay With App": "à¤à¤ª à¤¸à¥‡ à¤­à¥à¤—à¤¤à¤¾à¤¨ à¤•à¤°à¥‡à¤‚",
  "Pay With UPI": "UPI à¤¸à¥‡ à¤­à¥à¤—à¤¤à¤¾à¤¨ à¤•à¤°à¥‡à¤‚",
  "Share UPI": "UPI à¤¶à¥‡à¤¯à¤° à¤•à¤°à¥‡à¤‚",
  "Submit UTR": "UTR à¤¸à¤¬à¤®à¤¿à¤Ÿ à¤•à¤°à¥‡à¤‚",
  "Payment Processing": "à¤­à¥à¤—à¤¤à¤¾à¤¨ à¤ªà¥à¤°à¥‹à¤¸à¥‡à¤¸à¤¿à¤‚à¤—",
  "Matching Order...": "à¤‘à¤°à¥à¤¡à¤° à¤®à¤¿à¤²à¤¾à¤¯à¤¾ à¤œà¤¾ à¤°à¤¹à¤¾ à¤¹à¥ˆ...",
  "Finding matching merchant...": "à¤‰à¤ªà¤¯à¥à¤•à¥à¤¤ à¤®à¤°à¥à¤šà¥‡à¤‚à¤Ÿ à¤–à¥‹à¤œà¤¾ à¤œà¤¾ à¤°à¤¹à¤¾ à¤¹à¥ˆ...",
  "ORDER VALUE": "à¤‘à¤°à¥à¤¡à¤° à¤°à¤¾à¤¶à¤¿",
  COMMISSION: "à¤•à¤®à¥€à¤¶à¤¨",
  "Add UPI Account": "UPI à¤…à¤•à¤¾à¤‰à¤‚à¤Ÿ à¤œà¥‹à¤¡à¤¼à¥‡à¤‚",
  "+ Add UPI Account": "+ UPI à¤…à¤•à¤¾à¤‰à¤‚à¤Ÿ à¤œà¥‹à¤¡à¤¼à¥‡à¤‚",
  "Withdraw Amount": "à¤¨à¤¿à¤•à¤¾à¤¸à¥€ à¤°à¤¾à¤¶à¤¿",
  "Withdraw History": "à¤¨à¤¿à¤•à¤¾à¤¸à¥€ à¤‡à¤¤à¤¿à¤¹à¤¾à¤¸",
  "Withdraw Limit": "à¤¨à¤¿à¤•à¤¾à¤¸à¥€ à¤¸à¥€à¤®à¤¾",
  "Minimum single withdrawal amount:": "à¤¨à¥à¤¯à¥‚à¤¨à¤¤à¤® à¤à¤•à¤² à¤¨à¤¿à¤•à¤¾à¤¸à¥€ à¤°à¤¾à¤¶à¤¿:",
  "Processing Withdrawal...": "à¤¨à¤¿à¤•à¤¾à¤¸à¥€ à¤ªà¥à¤°à¥‹à¤¸à¥‡à¤¸ à¤¹à¥‹ à¤°à¤¹à¥€ à¤¹à¥ˆ...",
  "Submitting Request...": "à¤…à¤¨à¥à¤°à¥‹à¤§ à¤¸à¤¬à¤®à¤¿à¤Ÿ à¤¹à¥‹ à¤°à¤¹à¤¾ à¤¹à¥ˆ...",
  "Start Selling": "à¤¬à¥‡à¤šà¤¨à¤¾ à¤¶à¥à¤°à¥‚ à¤•à¤°à¥‡à¤‚",
  "Go To Purchase": "à¤–à¤°à¥€à¤¦ à¤ªà¥‡à¤œ à¤ªà¤° à¤œà¤¾à¤à¤‚",
  "Please purchase more.": "à¤•à¥ƒà¤ªà¤¯à¤¾ à¤”à¤° à¤–à¤°à¥€à¤¦à¥‡à¤‚à¥¤",
  "Tool wallet": "à¤Ÿà¥‚à¤² à¤µà¥‰à¤²à¥‡à¤Ÿ",
  "Authorize Tool": "à¤Ÿà¥‚à¤² à¤…à¤§à¤¿à¤•à¥ƒà¤¤ à¤•à¤°à¥‡à¤‚",
  "Your tool authorised": "à¤†à¤ªà¤•à¤¾ à¤Ÿà¥‚à¤² à¤…à¤§à¤¿à¤•à¥ƒà¤¤ à¤¹à¥ˆ",
  "Let us join the work": "à¤†à¤‡à¤ à¤•à¤¾à¤® à¤¶à¥à¤°à¥‚ à¤•à¤°à¥‡à¤‚",
  Phone: "à¤«à¥‹à¤¨",
  "Pin Code": "à¤ªà¤¿à¤¨ à¤•à¥‹à¤¡",
  Finish: "à¤ªà¥‚à¤°à¤¾ à¤•à¤°à¥‡à¤‚",
  Close: "à¤¬à¤‚à¤¦ à¤•à¤°à¥‡à¤‚",
  All: "à¤¸à¤­à¥€",
  "Direct Team": "à¤¡à¤¾à¤¯à¤°à¥‡à¤•à¥à¤Ÿ à¤Ÿà¥€à¤®",
  "Indirect Team": "à¤‡à¤¨à¤¡à¤¾à¤¯à¤°à¥‡à¤•à¥à¤Ÿ à¤Ÿà¥€à¤®",
  "Team Income": "à¤Ÿà¥€à¤® à¤†à¤¯",
  "Team Profit": "à¤Ÿà¥€à¤® à¤²à¤¾à¤­",
  "Referral Code": "à¤°à¥‡à¤«à¤°à¤² à¤•à¥‹à¤¡",
  "Referral link": "à¤°à¥‡à¤«à¤°à¤² à¤²à¤¿à¤‚à¤•",
  "Referral network": "à¤°à¥‡à¤«à¤°à¤² à¤¨à¥‡à¤Ÿà¤µà¤°à¥à¤•",
  "Transaction History": "à¤²à¥‡à¤¨à¤¦à¥‡à¤¨ à¤‡à¤¤à¤¿à¤¹à¤¾à¤¸",
  "Bills and records": "à¤¬à¤¿à¤² à¤”à¤° à¤°à¤¿à¤•à¥‰à¤°à¥à¤¡",
  Profit: "à¤²à¤¾à¤­",
  Register: "à¤°à¤œà¤¿à¤¸à¥à¤Ÿà¤°",
  Login: "à¤²à¥‰à¤—à¤¿à¤¨",
  "Welcome Back": "à¤µà¤¾à¤ªà¤¸à¥€ à¤ªà¤° à¤¸à¥à¤µà¤¾à¤—à¤¤ à¤¹à¥ˆ",
  "Mobile Number": "à¤®à¥‹à¤¬à¤¾à¤‡à¤² à¤¨à¤‚à¤¬à¤°",
  "New user?": "à¤¨à¤ à¤¯à¥‚à¤œà¤¼à¤° à¤¹à¥ˆà¤‚?",
  "Create Account": "à¤…à¤•à¤¾à¤‰à¤‚à¤Ÿ à¤¬à¤¨à¤¾à¤à¤‚",
  "Confirm Password": "à¤ªà¤¾à¤¸à¤µà¤°à¥à¤¡ à¤•à¥€ à¤ªà¥à¤·à¥à¤Ÿà¤¿ à¤•à¤°à¥‡à¤‚",
  "Already registered?": "à¤ªà¤¹à¤²à¥‡ à¤¸à¥‡ à¤°à¤œà¤¿à¤¸à¥à¤Ÿà¤°à¥à¤¡ à¤¹à¥ˆà¤‚?",
  "Referral Code": "à¤°à¥‡à¤«à¤°à¤² à¤•à¥‹à¤¡",
  "Admin Panel": "à¤à¤¡à¤®à¤¿à¤¨ à¤ªà¥ˆà¤¨à¤²",
  "Control center": "à¤•à¤‚à¤Ÿà¥à¤°à¥‹à¤² à¤¸à¥‡à¤‚à¤Ÿà¤°",
  "Total Users": "à¤•à¥à¤² à¤¯à¥‚à¤œà¤¼à¤°",
  "Active Users": "à¤¸à¤•à¥à¤°à¤¿à¤¯ à¤¯à¥‚à¤œà¤¼à¤°",
  "Total Deposits": "à¤•à¥à¤² à¤œà¤®à¤¾",
  "Total Withdrawals": "à¤•à¥à¤² à¤¨à¤¿à¤•à¤¾à¤¸à¥€",
  "Gift Code Generator": "à¤—à¤¿à¤«à¥à¤Ÿ à¤•à¥‹à¤¡ à¤œà¥‡à¤¨à¤°à¥‡à¤Ÿà¤°",
  Rewards: "à¤°à¤¿à¤µà¥‰à¤°à¥à¤¡",
  "Reward Amount": "à¤°à¤¿à¤µà¥‰à¤°à¥à¤¡ à¤°à¤¾à¤¶à¤¿",
  "Usage Limit": "à¤‰à¤ªà¤¯à¥‹à¤— à¤¸à¥€à¤®à¤¾",
  "Expiry Date (Optional)": "à¤¸à¤®à¤¾à¤ªà¥à¤¤à¤¿ à¤¤à¤¾à¤°à¥€à¤– (à¤µà¥ˆà¤•à¤²à¥à¤ªà¤¿à¤•)",
  "Generate Gift Code": "à¤—à¤¿à¤«à¥à¤Ÿ à¤•à¥‹à¤¡ à¤¬à¤¨à¤¾à¤à¤‚",
  "No gift codes generated.": "à¤•à¥‹à¤ˆ à¤—à¤¿à¤«à¥à¤Ÿ à¤•à¥‹à¤¡ à¤¨à¤¹à¥€à¤‚ à¤¬à¤¨à¤¾à¤¯à¤¾ à¤—à¤¯à¤¾à¥¤",
  "Profit %": "à¤²à¤¾à¤­ %",
  "Min Purchase": "à¤¨à¥à¤¯à¥‚à¤¨à¤¤à¤® à¤–à¤°à¥€à¤¦",
  "Max Purchase": "à¤…à¤§à¤¿à¤•à¤¤à¤® à¤–à¤°à¥€à¤¦",
  "Minimum Withdraw Limit": "à¤¨à¥à¤¯à¥‚à¤¨à¤¤à¤® à¤¨à¤¿à¤•à¤¾à¤¸à¥€ à¤¸à¥€à¤®à¤¾",
  "Maximum Withdraw Limit": "à¤…à¤§à¤¿à¤•à¤¤à¤® à¤¨à¤¿à¤•à¤¾à¤¸à¥€ à¤¸à¥€à¤®à¤¾",
  "Sign Up / Welcome Bonus": "à¤¸à¤¾à¤‡à¤¨ à¤…à¤ª / à¤µà¥‡à¤²à¤•à¤® à¤¬à¥‹à¤¨à¤¸",
  "Daily Order Limit": "à¤¦à¥ˆà¤¨à¤¿à¤• à¤‘à¤°à¥à¤¡à¤° à¤¸à¥€à¤®à¤¾",
  "Order Duration Hours": "à¤‘à¤°à¥à¤¡à¤° à¤…à¤µà¤§à¤¿ à¤˜à¤‚à¤Ÿà¥‡",
  "Coin Price": "à¤•à¥‰à¤‡à¤¨ à¤•à¥€à¤®à¤¤",
  "Platform Price": "à¤ªà¥à¤²à¥‡à¤Ÿà¤«à¥‰à¤°à¥à¤® à¤•à¥€à¤®à¤¤",
  "Telegram Group Link": "Telegram à¤—à¥à¤°à¥à¤ª à¤²à¤¿à¤‚à¤•",
  "Telegram Support Link": "Telegram à¤¸à¤ªà¥‹à¤°à¥à¤Ÿ à¤²à¤¿à¤‚à¤•",
  Registration: "à¤°à¤œà¤¿à¤¸à¥à¤Ÿà¥à¤°à¥‡à¤¶à¤¨",
  "Save Settings": "à¤¸à¥‡à¤Ÿà¤¿à¤‚à¤—à¥à¤¸ à¤¸à¥‡à¤µ à¤•à¤°à¥‡à¤‚",
  "Admin UPI": "à¤à¤¡à¤®à¤¿à¤¨ UPI",
  "Add Admin UPI": "à¤à¤¡à¤®à¤¿à¤¨ UPI à¤œà¥‹à¤¡à¤¼à¥‡à¤‚",
  "UTR Requests": "UTR à¤…à¤¨à¥à¤°à¥‹à¤§",
  "Withdrawal Requests": "à¤¨à¤¿à¤•à¤¾à¤¸à¥€ à¤…à¤¨à¥à¤°à¥‹à¤§",
  Approval: "à¤…à¤¨à¥à¤®à¥‹à¤¦à¤¨",
  "Bank Management": "à¤¬à¥ˆà¤‚à¤• à¤ªà¥à¤°à¤¬à¤‚à¤§à¤¨",
  "Bank payout": "à¤¬à¥ˆà¤‚à¤• à¤­à¥à¤—à¤¤à¤¾à¤¨",
  "Account Holder Name": "à¤–à¤¾à¤¤à¤¾à¤§à¤¾à¤°à¤• à¤•à¤¾ à¤¨à¤¾à¤®",
  "Account Number": "à¤…à¤•à¤¾à¤‰à¤‚à¤Ÿ à¤¨à¤‚à¤¬à¤°",
  "Bank Name": "à¤¬à¥ˆà¤‚à¤• à¤•à¤¾ à¤¨à¤¾à¤®",
  "Branch Name": "à¤¬à¥à¤°à¤¾à¤‚à¤š à¤•à¤¾ à¤¨à¤¾à¤®",
  "IFSC Code": "IFSC à¤•à¥‹à¤¡",
  "Verify Bank": "à¤¬à¥ˆà¤‚à¤• à¤¸à¤¤à¥à¤¯à¤¾à¤ªà¤¿à¤¤ à¤•à¤°à¥‡à¤‚",
  "Saved Banks": "à¤¸à¥‡à¤µ à¤•à¤¿à¤ à¤—à¤ à¤¬à¥ˆà¤‚à¤•",
  "UPI Management": "UPI à¤ªà¥à¤°à¤¬à¤‚à¤§à¤¨",
  "UPI payout": "UPI à¤­à¥à¤—à¤¤à¤¾à¤¨",
  "UPI ID": "UPI ID",
  "6 Digit Transaction Pin": "6 à¤…à¤‚à¤•à¥‹à¤‚ à¤•à¤¾ à¤Ÿà¥à¤°à¤¾à¤‚à¤œà¥ˆà¤•à¥à¤¶à¤¨ à¤ªà¤¿à¤¨",
  "Saved UPI": "à¤¸à¥‡à¤µ à¤•à¤¿à¤ à¤—à¤ UPI",
  Processing: "à¤ªà¥à¤°à¥‹à¤¸à¥‡à¤¸à¤¿à¤‚à¤—",
  Completed: "à¤ªà¥‚à¤°à¥à¤£",
  Rejected: "à¤…à¤¸à¥à¤µà¥€à¤•à¥ƒà¤¤",
  Active: "à¤¸à¤•à¥à¤°à¤¿à¤¯",
  Inactive: "à¤¨à¤¿à¤·à¥à¤•à¥à¤°à¤¿à¤¯",
  Success: "à¤¸à¤«à¤²",
  Pending: "à¤²à¤‚à¤¬à¤¿à¤¤",
  Accept: "à¤¸à¥à¤µà¥€à¤•à¤¾à¤° à¤•à¤°à¥‡à¤‚",
  Reject: "à¤…à¤¸à¥à¤µà¥€à¤•à¤¾à¤° à¤•à¤°à¥‡à¤‚",
  Delete: "à¤¹à¤Ÿà¤¾à¤à¤‚",
  Date: "à¤¤à¤¾à¤°à¥€à¤–",
  Commission: "à¤•à¤®à¥€à¤¶à¤¨",
  Method: "à¤¤à¤°à¥€à¤•à¤¾",
  Details: "à¤µà¤¿à¤µà¤°à¤£",
  "Order ID": "à¤‘à¤°à¥à¤¡à¤° ID",
  UTR: "UTR",
  "No Purchase History Found": "à¤•à¥‹à¤ˆ à¤–à¤°à¥€à¤¦ à¤‡à¤¤à¤¿à¤¹à¤¾à¤¸ à¤¨à¤¹à¥€à¤‚ à¤®à¤¿à¤²à¤¾",
  "No withdrawal requests found.": "à¤•à¥‹à¤ˆ à¤¨à¤¿à¤•à¤¾à¤¸à¥€ à¤…à¤¨à¥à¤°à¥‹à¤§ à¤¨à¤¹à¥€à¤‚ à¤®à¤¿à¤²à¤¾à¥¤",
  "No UTR requests found.": "à¤•à¥‹à¤ˆ UTR à¤…à¤¨à¥à¤°à¥‹à¤§ à¤¨à¤¹à¥€à¤‚ à¤®à¤¿à¤²à¤¾à¥¤",
  "No admin UPI added.": "à¤•à¥‹à¤ˆ à¤à¤¡à¤®à¤¿à¤¨ UPI à¤¨à¤¹à¥€à¤‚ à¤œà¥‹à¤¡à¤¼à¤¾ à¤—à¤¯à¤¾à¥¤",
  "Save Profile": "à¤ªà¥à¤°à¥‹à¤«à¤¾à¤‡à¤² à¤¸à¥‡à¤µ à¤•à¤°à¥‡à¤‚",
  "Change Password": "à¤ªà¤¾à¤¸à¤µà¤°à¥à¤¡ à¤¬à¤¦à¤²à¥‡à¤‚",
  "Save PIN": "à¤ªà¤¿à¤¨ à¤¸à¥‡à¤µ à¤•à¤°à¥‡à¤‚",
  "My Team": "à¤®à¥‡à¤°à¥€ à¤Ÿà¥€à¤®",
  "Total Earnings [YeleCoin]": "à¤•à¥à¤² à¤•à¤®à¤¾à¤ˆ [YeleCoin]",
  "View My Earnings": "à¤®à¥‡à¤°à¥€ à¤•à¤®à¤¾à¤ˆ à¤¦à¥‡à¤–à¥‡à¤‚",
  "Sublines(": "à¤¸à¤¬à¤²à¤¾à¤‡à¤¨à¥à¤¸(",
  "2nd-Level Sublines(": "à¤¦à¥‚à¤¸à¤°à¥‡ à¤¸à¥à¤¤à¤° à¤•à¥€ à¤¸à¤¬à¤²à¤¾à¤‡à¤¨à¥à¤¸(",
  "Today Deposit Count": "à¤†à¤œ à¤•à¥€ à¤œà¤®à¤¾ à¤¸à¤‚à¤–à¥à¤¯à¤¾",
  "Today Earnings (Rs )": "à¤†à¤œ à¤•à¥€ à¤•à¤®à¤¾à¤ˆ (Rs )",
  "Yesterday Deposit": "à¤•à¤² à¤•à¥€ à¤œà¤®à¤¾ à¤¸à¤‚à¤–à¥à¤¯à¤¾",
  "Yesterday Earnings": "à¤•à¤² à¤•à¥€ à¤•à¤®à¤¾à¤ˆ",
  "Total Deposit Count": "à¤•à¥à¤² à¤œà¤®à¤¾ à¤¸à¤‚à¤–à¥à¤¯à¤¾",
  "Total Subline Count": "à¤•à¥à¤² à¤¸à¤¬à¤²à¤¾à¤‡à¤¨ à¤¸à¤‚à¤–à¥à¤¯à¤¾",
  "Invite Reward": "à¤‡à¤¨à¤µà¤¾à¤‡à¤Ÿ à¤°à¤¿à¤µà¥‰à¤°à¥à¤¡",
  "Activated": "à¤¸à¤•à¥à¤°à¤¿à¤¯ à¤•à¤¿à¤ à¤—à¤",
  "/ next goal 15 -> Rs 1500": "/ à¤…à¤—à¤²à¤¾ à¤²à¤•à¥à¤·à¥à¤¯ 15 -> Rs 1500",
  "Earned:": "à¤•à¤®à¤¾à¤¯à¤¾:",
  "Ends in": "à¤¸à¤®à¤¾à¤ªà¥à¤¤à¤¿ à¤®à¥‡à¤‚",
  "Build your network": "à¤…à¤ªà¤¨à¤¾ à¤¨à¥‡à¤Ÿà¤µà¤°à¥à¤• à¤¬à¤¨à¤¾à¤à¤‚",
  "Invite Subline": "à¤¸à¤¬à¤²à¤¾à¤‡à¤¨ à¤†à¤®à¤‚à¤¤à¥à¤°à¤¿à¤¤ à¤•à¤°à¥‡à¤‚",
  "Invite Code": "à¤‡à¤¨à¤µà¤¾à¤‡à¤Ÿ à¤•à¥‹à¤¡",
  "Copy Code": "à¤•à¥‹à¤¡ à¤•à¥‰à¤ªà¥€ à¤•à¤°à¥‡à¤‚",
  "Referral Link": "à¤°à¥‡à¤«à¤°à¤² à¤²à¤¿à¤‚à¤•",
  "Copy Link": "à¤²à¤¿à¤‚à¤• à¤•à¥‰à¤ªà¥€ à¤•à¤°à¥‡à¤‚",
  "QR Code": "QR à¤•à¥‹à¤¡",
  "Subline Rewards": "à¤¸à¤¬à¤²à¤¾à¤‡à¤¨ à¤°à¤¿à¤µà¥‰à¤°à¥à¤¡",
  "INR Subline Rewards": "INR à¤¸à¤¬à¤²à¤¾à¤‡à¤¨ à¤°à¤¿à¤µà¥‰à¤°à¥à¤¡",
  "USDT Subline Rewards": "USDT à¤¸à¤¬à¤²à¤¾à¤‡à¤¨ à¤°à¤¿à¤µà¥‰à¤°à¥à¤¡",
  "Earn on every completed team order": "à¤¹à¤° à¤ªà¥‚à¤°à¥à¤£ à¤Ÿà¥€à¤® à¤‘à¤°à¥à¤¡à¤° à¤ªà¤° à¤•à¤®à¤¾à¤à¤‚",
  "Earn on first-level USDT orders": "à¤ªà¤¹à¤²à¥‡ à¤¸à¥à¤¤à¤° à¤•à¥‡ USDT à¤‘à¤°à¥à¤¡à¤° à¤ªà¤° à¤•à¤®à¤¾à¤à¤‚",
  "First-level": "à¤ªà¤¹à¤²à¤¾ à¤¸à¥à¤¤à¤°",
  "Second-level": "à¤¦à¥‚à¤¸à¤°à¤¾ à¤¸à¥à¤¤à¤°",
  "Invite QR Code": "à¤‡à¤¨à¤µà¤¾à¤‡à¤Ÿ QR à¤•à¥‹à¤¡",
  "Scan to join my YelePay team": "à¤®à¥‡à¤°à¥€ YelePay à¤Ÿà¥€à¤® à¤¸à¥‡ à¤œà¥à¤¡à¤¼à¤¨à¥‡ à¤•à¥‡ à¤²à¤¿à¤ à¤¸à¥à¤•à¥ˆà¤¨ à¤•à¤°à¥‡à¤‚"
};

const reversePageTextTranslations = {
  ...Object.fromEntries(Object.entries(pageTextTranslations).map(([english, hindi]) => [hindi, english])),
  "à¤–à¤°à¥€à¤¦à¥‡à¤‚": "Buy",
  "à¤¬à¥‡à¤šà¥‡à¤‚": "Sell",
  "à¤µà¤¿à¤µà¤°à¤£": "Detail"
};

let currentUser = null;
let userProfile = null;
let settings = { ...defaults };
let pendingBuyAmount = 0;
let pendingPayment = null;
let selectedWithdrawTool = "";
let selectedWithdrawUpi = "";
let selectedWithdrawBank = "";
let selectedWithdrawalAccountId = "";
let withdrawalAccounts = [];
let selectedPurchaseAccountId = "";
let pendingPurchaseAccountId = "";
let pendingPurchaseOrder = null;
let purchaseAccountsReady = false;
let purchaseAccountsLoadPromise = null;
let pendingDeleteWithdrawalAccountId = "";
let isDeletingWithdrawalAccount = false;
let activePurchaseCategory = "small";
let isMatchingOrder = false;
let liveTodayProfit = null;
let deferredInstallPrompt = null;
let languageObserver = null;
let currentLanguage = "English";
const generatedOrderIds = new Set();
const realtimeUnsubs = [];
let historyUnsubs = [];
const HISTORY_PAGE_SIZE = 8;
const HISTORY_CACHE_TTL = 120000;
let historyPageState = null;
let historyLoadObserver = null;
const historyRowsCache = new Map();
const pendingUserReads = new Map();
let pendingSettingsRead = null;

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const page = document.body.dataset.page;

window.addEventListener("beforeinstallprompt", (event) => {
  event.preventDefault();
  deferredInstallPrompt = event;
  document.body.classList.add("pwa-install-ready");
});

window.addEventListener("appinstalled", () => {
  deferredInstallPrompt = null;
  document.body.classList.remove("pwa-install-ready");
});

function money(value) {
  return `Rs ${Number(value || 0).toLocaleString("en-IN", { maximumFractionDigits: 2 })}`;
}

function formatDateTime(value) {
  if (!value) return "Just now";
  const date = value.toDate ? value.toDate() : new Date(value);
  if (Number.isNaN(date.getTime())) return "Just now";
  return date.toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  });
}

function labelStatus(status) {
  const value = String(status || "processing").toLowerCase();
  if (value === "success" || value === "active") return "Completed";
  return value.charAt(0).toUpperCase() + value.slice(1);
}

function shortId(value) {
  if (!value) return "ZP000000";
  return String(value).slice(0, 8).toUpperCase();
}

function numericProfileId(value) {
  const source = String(value || "YelePay");
  let hash = 0;
  for (const character of source) hash = (hash * 31 + character.charCodeAt(0)) % 900000;
  return String(hash + 100000).slice(-6);
}

function playerIdFor(profile = userProfile) {
  return /^\d{6}$/.test(String(profile?.playerId || "")) ? String(profile.playerId) : numericProfileId(profile?.uid);
}

function firstPositiveValue(source, fields) {
  for (const field of fields) {
    const value = Number(source?.[field]);
    if (Number.isFinite(value) && value > 0) return value;
  }
  return null;
}

function normalizeUserLimits(profile) {
  if (!profile) return profile;
  const minBuyAmount = firstPositiveValue(profile, ["minBuyAmount", "minimumBuyAmount", "minDepositAmount", "minimumBuy", "minDeposit", "minimumDeposit"]);
  const minWithdrawAmount = firstPositiveValue(profile, ["minWithdrawAmount", "minimumWithdraw", "withdrawLimit", "minimumWithdrawalAmount"]);
  return {
    ...profile,
    ...(minBuyAmount ? { minBuyAmount } : {}),
    ...(minWithdrawAmount ? { minWithdrawAmount } : {})
  };
}

async function ensureUserPlayerId() {
  if (!userProfile) return;
  if (/^\d{6}$/.test(String(userProfile.playerId || ""))) return;
  if (!isConfigured || !currentUser) {
    userProfile.playerId = playerIdFor(userProfile);
    return;
  }
  const preferred = /^\d{6}$/.test(String(userProfile.playerId || "")) ? String(userProfile.playerId) : numericProfileId(currentUser.uid);
  for (let attempt = 0; attempt < 12; attempt += 1) {
    const candidate = attempt === 0 ? preferred : String(Math.floor(100000 + Math.random() * 900000));
    try {
      await runTransaction(db, async (tx) => {
        const reservationRef = doc(db, "playerIds", candidate);
        const reservation = await tx.get(reservationRef);
        if (reservation.exists() && reservation.data().uid !== currentUser.uid) throw new Error("PLAYER_ID_COLLISION");
        if (!reservation.exists()) tx.set(reservationRef, { uid: currentUser.uid, createdAt: serverTimestamp() });
        tx.update(doc(db, "users", currentUser.uid), { playerId: candidate });
      });
      userProfile = { ...userProfile, playerId: candidate };
      cacheUser(userProfile);
      return;
    } catch (error) {
      if (error.message !== "PLAYER_ID_COLLISION") throw error;
    }
  }
  throw new Error("Unable to allocate unique Player ID");
}

function effectiveMinBuyAmount() {
  const personal = firstPositiveValue(userProfile, ["minDepositAmount", "minBuyAmount", "minimumBuyAmount", "minimumBuy", "minDeposit", "minimumDeposit"]);
  return personal || Number(settings.minDepositAmount || settings.minPurchase || 0);
}

function effectiveMinWithdrawAmount() {
  const personal = firstPositiveValue(userProfile, ["minWithdrawAmount"]);
  return personal || Number(settings.minWithdraw || 0);
}

function maskMobile(value) {
  const mobile = String(value || "").replace(/\D/g, "");
  if (mobile.length < 4) return mobile || "00******00";
  return `${mobile.slice(0, 2)}${"*".repeat(Math.max(4, mobile.length - 4))}${mobile.slice(-2)}`;
}

function escapeMarkup(value) {
  return String(value ?? "").replace(/[&<>"']/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "\"": "&quot;",
    "'": "&#39;"
  })[character]);
}

async function copyToClipboard(value) {
  const text = String(value || "");
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch (error) {
    console.warn("Clipboard API unavailable, using fallback.", error);
  }

  const field = document.createElement("textarea");
  field.value = text;
  field.setAttribute("readonly", "");
  field.style.position = "fixed";
  field.style.opacity = "0";
  document.body.appendChild(field);
  field.select();
  let copied = false;
  try {
    copied = document.execCommand("copy");
  } catch (error) {
    console.warn("Clipboard fallback failed.", error);
  }
  field.remove();
  return copied;
}

function toast(message, type = "") {
  let box = $(".toast");
  if (!box) {
    box = document.createElement("div");
    box.className = "toast";
    document.body.appendChild(box);
  }
  box.classList.remove("success", "error", "show");
  if (type) box.classList.add(type);
  box.textContent = message;
  window.clearTimeout(box.hideTimer);
  requestAnimationFrame(() => box.classList.add("show"));
  box.hideTimer = window.setTimeout(() => box.classList.remove("show"), 2500);
}

function safePopup(message, type = "error") {
  try {
    toast(message, type);
  } catch (error) {
    console.warn("Toast UI unavailable.", error);
    if (typeof window.alert === "function") window.alert(message);
  }
}

function showServerBusy(error, cachedDataAvailable = false) {
  console.warn("Firebase request failed", error);
  return cachedDataAvailable;
}

function friendlyError(error, fallback) {
  const code = String(error?.code || "").toLowerCase();
  if (["resource-exhausted", "unavailable", "deadline-exceeded", "network-request-failed", "internal"].some((part) => code.includes(part))) {
    return fallback;
  }
  return error?.message || fallback;
}

function redirectAfterToast(url) {
  window.setTimeout(() => {
    location.href = url;
  }, 1200);
}

function initials(name) {
  return String(name || "YelePay").trim().slice(0, 1).toUpperCase();
}

function referralCode(uid) {
  return `YelePay${String(uid || Date.now()).replace(/\D/g, "").slice(-6)}`;
}

function getCachedData(key, ttl, allowStale = false) {
  try {
    const cached = JSON.parse(localStorage.getItem(key) || "null");
    if (!cached?.data || !cached.savedAt) return null;
    const isFresh = Date.now() - Number(cached.savedAt) < ttl;
    return allowStale ? { ...cached, isFresh } : (isFresh ? cached.data : null);
  } catch (error) {
    localStorage.removeItem(key);
    return null;
  }
}

function setCachedData(key, data) {
  try {
    localStorage.setItem(key, JSON.stringify({ savedAt: Date.now(), data }));
    return true;
  } catch (error) {
    console.warn(`Cache unavailable for ${key}.`, error);
    return false;
  }
}

async function readSettings() {
  if (!isConfigured) return { ...defaults };
  const cached = getCachedData(SETTINGS_CACHE_KEY, SETTINGS_CACHE_TTL, true);
  const cachedSettings = cached?.data ? { ...defaults, ...cached.data } : null;
  const isFresh = Boolean(cached?.isFresh);
  if (page !== "admin" && cachedSettings) {
    if (!isFresh) refreshSettingsInBackground();
    return cachedSettings;
  }
  try {
    return await fetchSettingsFromServer();
  } catch (error) {
    showServerBusy(error, Boolean(cachedSettings));
    return cachedSettings || { ...defaults };
  }
}

async function fetchSettingsFromServer() {
  const ref = doc(db, "settings", "main");
  const snap = await getDoc(ref);
  const nextSettings = snap.exists() ? { ...defaults, ...snap.data() } : { ...defaults };
  if (!snap.exists()) await setDoc(ref, defaults, { merge: true });
  else if (!Array.isArray(snap.data()?.requiredCollections)) {
    await setDoc(ref, { requiredCollections: REQUIRED_COLLECTIONS }, { merge: true });
  }
  ensureRequiredCollections().catch((error) => showServerBusy(error, true));
  cacheSettings(nextSettings);
  settings = nextSettings;
  window.YelePayRuntimeSettings = settings;
  return nextSettings;
}

async function ensureRequiredCollections() {
  if (!isConfigured || localStorage.getItem(COLLECTION_SCHEMA_CACHE_KEY) === "ready") return;
  const batch = writeBatch(db);
  const now = serverTimestamp();
  for (const name of ["popups", "sellingRequests", "notifications", "support", "adminLogs"]) {
    batch.set(doc(db, name, "_YelePaySchema"), {
      system: true,
      collection: name,
      app: "YelePay",
      updatedAt: now
    }, { merge: true });
  }
  batch.set(doc(db, "settings", "collections"), {
    requiredCollections: REQUIRED_COLLECTIONS,
    updatedAt: now
  }, { merge: true });
  await batch.commit();
  localStorage.setItem(COLLECTION_SCHEMA_CACHE_KEY, "ready");
}

function refreshSettingsInBackground() {
  if (pendingSettingsRead) return pendingSettingsRead;
  pendingSettingsRead = fetchSettingsFromServer()
    .catch((error) => showServerBusy(error, true))
    .finally(() => { pendingSettingsRead = null; });
  return pendingSettingsRead;
}

function cacheSettings(value = settings) {
  setCachedData(SETTINGS_CACHE_KEY, value);
}

function userCacheKey(uid) {
  return `YelePayUserCache:${uid}`;
}

function readUserCacheEntry(uid) {
  return getCachedData(userCacheKey(uid), USER_CACHE_TTL, true);
}

function readCachedUser(uid) {
  return readUserCacheEntry(uid)?.data || null;
}

function cacheUser(profile) {
  if (!profile?.uid) return;
  setCachedData(userCacheKey(profile.uid), profile);
}

async function readUser(uid, { forceFresh = false } = {}) {
  if (!isConfigured) return { ...demoUser };
  const cached = readUserCacheEntry(uid);
  if (forceFresh) {
    try {
      return await fetchUserFromServer(uid);
    } catch (error) {
      showServerBusy(error, Boolean(cached?.data));
      return cached?.data ? normalizeUserLimits({ uid, ...cached.data }) : null;
    }
  }
  const ttl = ["dashboard", "purchase", "withdrawal"].includes(page) ? BALANCE_CACHE_TTL : USER_CACHE_TTL;
  if (cached?.data) {
    if (Date.now() - Number(cached.savedAt || 0) >= ttl) refreshUserInBackground(uid);
    return normalizeUserLimits({ uid, ...cached.data });
  }
  try {
    return await fetchUserFromServer(uid);
  } catch (error) {
    showServerBusy(error, false);
    return null;
  }
}

async function fetchUserFromServer(uid) {
  const snap = await getDoc(doc(db, "users", uid));
  const profile = snap.exists() ? normalizeUserLimits({ uid, ...snap.data() }) : null;
  cacheUser(profile);
  return profile;
}

function applyFreshUser(profile) {
  if (!profile || profile.uid !== currentUser?.uid) return;
  userProfile = profile;
  if (profile.blocked) {
    signOut(auth).finally(() => location.replace("login.html"));
    return;
  }
  if (page === "dashboard") renderDashboardProfile(profile);
  if (page === "profile") renderProfileData(profile);
  if (page === "team") renderTeamSummary(profile, Number(profile.teamCount || 0), Number(profile.secondLevelCount || 0));
  if (page === "withdrawal" && $("#withdrawBalance")) $("#withdrawBalance").textContent = money(profile.walletBalance);
}

function refreshUserInBackground(uid) {
  if (pendingUserReads.has(uid)) return pendingUserReads.get(uid);
  const request = fetchUserFromServer(uid)
    .then((profile) => { applyFreshUser(profile); return profile; })
    .catch((error) => { showServerBusy(error, Boolean(readCachedUser(uid))); return readCachedUser(uid); })
    .finally(() => pendingUserReads.delete(uid));
  pendingUserReads.set(uid, request);
  return request;
}

async function ensureDemoData() {
  settings = { ...defaults };
  window.YelePayRuntimeSettings = settings;
  currentUser = { uid: demoUser.uid, email: demoUser.email };
  userProfile = { ...demoUser };
}

async function boot() {
  showPageSkeleton();
  registerPwa();
  wireCommon();
  ensureLucideIcons();
  applyLanguage(localStorage.getItem("YelePayLanguage") || "English", false);
  startLanguageObserver();
  settings = await readSettings();
  window.YelePayRuntimeSettings = settings;

  if (!isConfigured) {
    await ensureDemoData();
    await routePage();
    hidePageSkeleton();
    toast("Demo mode: add Firebase config in firebase.js to connect Firestore.");
    return;
  }

  onAuthStateChanged(auth, async (user) => {
    currentUser = user;
    if (user) {
      userProfile = await readUser(user.uid, { forceFresh: page === "purchase" });
      if (userProfile?.blocked) {
        await signOut(auth);
        localStorage.removeItem(userCacheKey(user.uid));
        toast("Your account is blocked. Contact support.", "error");
        location.replace("login.html");
        return;
      }
    }
    await routePage();
    hidePageSkeleton();
  });
}

function showPageSkeleton() {
  if (["login", "register", "admin"].includes(page) || $("#pageSkeleton")) return;
  const shell = $(".app-shell");
  if (!shell) return;
  shell.insertAdjacentHTML("afterbegin", `<div id="pageSkeleton" class="page-skeleton" aria-label="Loading"><div class="skeleton-line wide"></div><div class="skeleton-card"></div><div class="skeleton-grid"><span></span><span></span></div><div class="skeleton-card short"></div></div>`);
}

function hidePageSkeleton() {
  $("#pageSkeleton")?.classList.add("is-hidden");
  window.setTimeout(() => $("#pageSkeleton")?.remove(), 220);
}

function registerPwa() {
  const localHost = ["localhost", "127.0.0.1"].includes(location.hostname);
  if (!("serviceWorker" in navigator) || (location.protocol !== "https:" && !localHost)) return;
  navigator.serviceWorker.register("/service-worker.js", { scope: "/" }).catch((error) => console.warn("PWA registration failed.", error));
}

async function routePage() {
  setActiveNav();
  injectYelePayLogo();
  ensureLucideIcons();
  applyLanguage(localStorage.getItem("YelePayLanguage") || userProfile?.language || "English", false);
  startLanguageObserver();
  if (page === "dashboard") await initDashboard();
  if (page === "purchase") await initPurchase();
  if (page === "withdrawal") await initWithdrawal();
  if (page === "team") await initTeam();
  if (page === "profile") await initProfile();
  if (page === "history") await initHistory();
  if (page === "bank") initBank();
  if (page === "upi") initUpi();
  if (page === "admin") initAdmin();
  if (page === "login" || page === "register") initStandaloneAuth();
}

function injectYelePayLogo() {
  if (document.querySelector('img[src*="YelePay-logo"], img[src*="YelePay-icon"]')) return;
  const host = document.querySelector(".topbar, .tool-head, .team-hero, .history-header, .app-shell main, main, body");
  if (!host) return;
  host.insertAdjacentHTML("afterbegin", `<a class="YelePay-page-mark" href="dashboard.html" aria-label="YelePay home"><img src="YelePay-icon-192.png" alt="YelePay" width="34" height="34"><span>YelePay</span></a>`);
}

function ensureLucideIcons() {
  const render = () => window.lucide?.createIcons();
  if (window.lucide) {
    render();
    return;
  }
  let script = document.querySelector('script[data-YelePay-lucide], script[src*="lucide"]');
  if (!script) {
    script = document.createElement("script");
    script.src = "https://unpkg.com/lucide@0.468.0/dist/umd/lucide.min.js";
    script.defer = true;
    script.dataset.YelePayLucide = "true";
    document.head.appendChild(script);
  }
  script.addEventListener("load", render, { once: true });
}

function setActiveNav() {
  $$(".nav-link").forEach((link) => {
    const target = link.dataset.nav;
    link.classList.toggle("active", target === page);
  });
}

function wireCommon() {
  wireAdminLogoUnlock();

  document.addEventListener("click", async (event) => {
    const copy = event.target.closest("[data-copy]");
    if (copy) {
      await navigator.clipboard?.writeText(copy.dataset.copy);
      toast("Copied");
    }

    const logout = event.target.closest("[data-logout]");
    if (logout) {
      if (isConfigured) await signOut(auth);
      localStorage.removeItem("YelePayDemoSession");
      location.href = "dashboard.html";
    }
  });
}

function wireAdminLogoUnlock() {
  const logo = $(".brand-logo") || $(".app-logo");
  if (!logo) return;

  let taps = 0;
  let resetTimer = 0;
  logo.style.cursor = "pointer";
  logo.addEventListener("click", () => {
    taps += 1;
    window.clearTimeout(resetTimer);
    resetTimer = window.setTimeout(() => {
      taps = 0;
    }, 2500);

    if (taps === 5) toast("Admin unlock: 2 taps more.");
    if (taps >= 7) {
      taps = 0;
      location.href = "admindashboard.html";
    }
  });
}

function requireProfile() {
  if (!userProfile && page !== "dashboard") {
    location.href = "dashboard.html";
    return false;
  }
  return true;
}

function renderAvatar(target, profile = userProfile) {
  if (!target || !profile) return;
  const avatarUrl = profile.avatarUrl || AVATAR_OPTIONS.find((avatar) => avatar.id === profile.avatarId)?.url || profile.photoURL;
  if (avatarUrl) {
    target.innerHTML = `<img class="avatar" src="${escapeMarkup(avatarUrl)}" alt="${escapeMarkup(profile.name || "User")}" loading="lazy" decoding="async">`;
    target.querySelector("img")?.addEventListener("error", () => { target.textContent = initials(profile.name); }, { once: true });
  } else {
    target.textContent = initials(profile.name);
  }
}

function defaultAvatarFor(uid, random = false) {
  const index = random ? Math.floor(Math.random() * AVATAR_OPTIONS.length) : [...String(uid || "YelePay")].reduce((sum, char) => sum + char.charCodeAt(0), 0) % AVATAR_OPTIONS.length;
  return AVATAR_OPTIONS[index];
}

async function ensureUserAvatar(random = false) {
  if (!userProfile || userProfile.avatarUrl || userProfile.avatarId) return;
  const avatar = defaultAvatarFor(userProfile.uid, random);
  userProfile = { ...userProfile, avatarId: avatar.id, avatarUrl: avatar.url };
  cacheUser(userProfile);
  if (isConfigured && currentUser) await updateDoc(doc(db, "users", currentUser.uid), { avatarId: avatar.id, avatarUrl: avatar.url, updatedAt: serverTimestamp() });
}

function initAuth() {
  const authPanel = $("#authPanel");
  const appPanel = $("#appPanel");
  if (!authPanel || !appPanel) return;

  if (userProfile) {
    authPanel.classList.add("hidden");
    appPanel.classList.remove("hidden");
    return;
  }

  authPanel.classList.remove("hidden");
  appPanel.classList.add("hidden");

  const modes = $$(".auth-mode", authPanel);
  const forms = $$(".auth-form", authPanel);

  modes.forEach((button) => {
    button.addEventListener("click", () => {
      modes.forEach((item) => item.classList.remove("active"));
      forms.forEach((item) => item.classList.add("hidden"));
      button.classList.add("active");
      $(`#${button.dataset.target}`).classList.remove("hidden");
    });
  });

  $("#registerForm")?.addEventListener("submit", registerUser);
  $("#loginForm")?.addEventListener("submit", loginUser);
  $("#forgotForm")?.addEventListener("submit", forgotPassword);
  const ref = new URLSearchParams(location.search).get("ref");
  const referralInput = $("#registerForm input[name='referral']");
  if (ref && referralInput) referralInput.value = ref.toUpperCase();
}

function initStandaloneAuth() {
  const loginForm = $("#loginForm");
  const registerForm = $("#registerForm");
  const forgotForm = $("#forgotForm");
  const mobileInput = $("#registerForm input[name='mobile']");
  const loginMobileInput = $("#loginForm input[name='mobile']");
  const passwordInput = $("#registerForm input[name='password']");

  mobileInput?.addEventListener("input", () => {
    mobileInput.value = mobileInput.value.replace(/\D/g, "").slice(0, 10);
  });

  loginMobileInput?.addEventListener("input", () => {
    loginMobileInput.value = loginMobileInput.value.replace(/\D/g, "").slice(0, 10);
  });

  passwordInput?.addEventListener("input", () => {
    passwordInput.value = passwordInput.value.slice(0, 20);
  });

  loginForm?.addEventListener("submit", loginUser);
  registerForm?.addEventListener("submit", registerUser);
  forgotForm?.addEventListener("submit", forgotPassword);
  const ref = new URLSearchParams(location.search).get("ref");
  const referralInput = $("#registerForm input[name='referral']");
  if (ref && referralInput) referralInput.value = ref.toUpperCase();
}

async function registerUser(event) {
  event.preventDefault();
  if (!settings.registrationEnabled) return toast("Registration is disabled by admin.", "error");
  const submitButton = event.currentTarget.querySelector("button[type='submit'], .btn");
  const form = new FormData(event.currentTarget);
  const password = form.get("password");
  const confirmPassword = form.get("confirmPassword");
  const name = form.get("name").trim();
  const mobile = form.get("mobile").trim().replace(/\D/g, "");
  const referredBy = form.get("referral").trim().toUpperCase();
  const email = `${mobile}@zivapay.app`;
  const signupBonusAmount = Math.max(0, Number(settings.signupBonusAmount || 0));

  if (!/^\d{10}$/.test(mobile)) return toast("Mobile number must be 10 digits.", "error");
  if (password.length < 7 || password.length > 20) return toast("Password must be 7 to 20 characters.", "error");
  if (password !== confirmPassword) return toast("Password and confirm password must match.", "error");

  try {
    if (submitButton) submitButton.disabled = true;

    if (!isConfigured) {
      if (mobile === demoUser.mobile) return toast("Mobile number already registered", "error");
      userProfile = {
        ...demoUser,
        name,
        email,
        mobile,
        referredBy,
        balance: signupBonusAmount,
        walletBalance: signupBonusAmount,
        totalIncome: signupBonusAmount,
        signupBonus: signupBonusAmount,
        signupBonusAmount,
        signupBonusClaimed: true
      };
      currentUser = { uid: userProfile.uid, email };
      localStorage.setItem("YelePayDemoSession", "1");
      toast("Register Successfully", "success");
      if (page === "register") redirectAfterToast("dashboard.html");
      else routePage();
      return;
    }

    const cred = await createUserWithEmailAndPassword(auth, email, password);
    try {
      await updateProfile(cred.user, { displayName: name });
    } catch (profileError) {
      showServerBusy(profileError, true);
    }
    const profile = {
      name,
      mobile,
      email,
      photoURL: "",
      uid: cred.user.uid,
      referralCode: referralCode(cred.user.uid),
      referredBy,
      teamCount: 0,
      balance: signupBonusAmount,
      walletBalance: signupBonusAmount,
      signupBonus: signupBonusAmount,
      signupBonusAmount,
      signupBonusClaimed: true,
      todayOrders: 0,
      todayProfit: 0,
      totalProfit: 0,
      totalIncome: signupBonusAmount,
      teamIncome: 0,
      teamProfit: 0,
      avatarId: defaultAvatarFor(cred.user.uid, true).id,
      avatarUrl: "",
      authCreationTime: cred.user.metadata?.creationTime || new Date().toISOString(),
      createdAt: serverTimestamp()
    };
    profile.avatarUrl = AVATAR_OPTIONS.find((avatar) => avatar.id === profile.avatarId)?.url || AVATAR_OPTIONS[0].url;
    await setDoc(doc(db, "users", cred.user.uid), profile);
    await addDoc(collection(db, "transactions"), {
      userId: cred.user.uid,
      type: "signup_bonus",
      amount: signupBonusAmount,
      status: "completed",
      title: "Signup bonus",
      createdAt: serverTimestamp()
    });
    if (referredBy) {
      await addDoc(collection(db, "team"), {
        userId: cred.user.uid,
        referralCode: referredBy,
        level: "direct",
        createdAt: serverTimestamp()
      });
    }
    toast("Register Successfully", "success");
    if (page === "register") redirectAfterToast("dashboard.html");
  } catch (error) {
    console.warn(error);
    if (error.code === "auth/email-already-in-use") return toast("Mobile number already registered", "error");
    toast(friendlyError(error, "Registration failed"), "error");
  } finally {
    if (submitButton) submitButton.disabled = false;
  }
}

async function loginUser(event) {
  event.preventDefault();
  const submitButton = event.currentTarget.querySelector("button[type='submit'], .btn");
  const form = new FormData(event.currentTarget);
  const mobile = String(form.get("mobile") || "").trim().replace(/\D/g, "");
  const password = form.get("password");
  if (!/^\d{10}$/.test(mobile)) return toast("Mobile number must be 10 digits.", "error");
  if (password.length < 7 || password.length > 20) return toast("Password must be 7 to 20 characters.", "error");
  const email = `${mobile}@zivapay.app`;

  try {
    if (submitButton) submitButton.disabled = true;

    if (!isConfigured) {
      if (mobile !== demoUser.mobile) return toast("User not found", "error");
      currentUser = { uid: demoUser.uid, email };
      userProfile = { ...demoUser, email };
      localStorage.setItem("YelePayDemoSession", "1");
      toast("Login Successfully", "success");
      if (page === "login") redirectAfterToast("dashboard.html");
      else routePage();
      return;
    }

    const credential = await signInWithEmailAndPassword(auth, email, password);
    const profileSnapshot = await getDoc(doc(db, "users", credential.user.uid));
    if (profileSnapshot.data()?.blocked) {
      await signOut(auth);
      return toast("Your account is blocked. Contact support.", "error");
    }
    const loginWriteKey = `YelePayLastLoginWrite:${credential.user.uid}`;
    const lastLoginWrite = Number(localStorage.getItem(loginWriteKey) || 0);
    if (Date.now() - lastLoginWrite >= LOGIN_WRITE_TTL) {
      await updateDoc(doc(db, "users", credential.user.uid), { lastLoginAt: serverTimestamp() });
      localStorage.setItem(loginWriteKey, String(Date.now()));
    }
    await recordUserActivity(credential.user.uid, "Account Login Successfully");
    cacheUser({ uid: credential.user.uid, ...profileSnapshot.data() });
    toast("Login Successfully", "success");
    if (page === "login") redirectAfterToast("dashboard.html");
  } catch (error) {
    console.warn(error);
    if (["auth/user-not-found", "auth/invalid-email"].includes(error.code)) return toast("User not found", "error");
    if (["auth/wrong-password", "auth/invalid-credential"].includes(error.code)) return toast("Wrong Password", "error");
    toast(friendlyError(error, "Login failed"), "error");
  } finally {
    if (submitButton) submitButton.disabled = false;
  }
}

async function recordUserActivity(userId, title, extra = {}) {
  if (!isConfigured || !db || !userId) return;
  try {
    await addDoc(collection(db, "activities"), {
      userId,
      title,
      ...extra,
      createdAt: serverTimestamp()
    });
  } catch (error) {
    console.warn("Activity could not be saved.", error);
  }
}

async function forgotPassword(event) {
  event.preventDefault();
  const email = new FormData(event.currentTarget).get("email").trim();
  if (!isConfigured) return toast("Demo mode: password reset is available after Firebase setup.");
  await sendPasswordResetEmail(auth, email);
  toast("Password reset link sent.");
}

async function initDashboard() {
  if (!userProfile) {
    location.replace("login.html");
    return;
  }

  await Promise.all([ensureUserAvatar(), ensureUserPlayerId()]);
  renderDashboardProfile(userProfile);
  $("#dailyProfit").textContent = `${settings.profitPercent}%`;
  if ($("#rupeeOrderProfit")) $("#rupeeOrderProfit").textContent = `${getOrderProfitPercentage()}%`;
  $("#coinPrice").textContent = money(settings.coinPrice);
  $("#platformPrice").textContent = money(settings.platformPrice);
  renderAvatar($("#avatar"));
  $("#homeDownloadApp")?.addEventListener("click", installYelePayApp);
  $("#homeCustomerService")?.addEventListener("click", openHomeServiceModal);
  $$('[data-home-service-close]').forEach((button) => button.addEventListener("click", closeHomeServiceModal));
  $$('[data-home-service-link]').forEach((button) => button.addEventListener("click", () => openServiceLink(button.dataset.homeServiceLink)));
  renderProofs();
  initManagedHomeContent();
  window.setInterval(renderProofs, 5000);
}

async function initManagedHomeContent() {
  const content = $(".content-scroll");
  if (!isConfigured || !content) return;
  const cached = getCachedData(HOME_CONTENT_CACHE_KEY, SETTINGS_CACHE_TTL, true);
  if (cached?.data) {
    renderManagedHomeContent(content, cached.data);
    if (Date.now() - Number(cached.savedAt || 0) < SETTINGS_CACHE_TTL) return;
  }
  try {
    const [bannerSnap, popupSnap, tutorialSnap] = await Promise.all([
      getDoc(doc(db, "settings", "banner")),
      getDoc(doc(db, "settings", "popup")),
      getDocs(query(collection(db, "tutorials"), orderBy("createdAt", "desc"), limit(3)))
    ]);
    const data = { banner: bannerSnap.data() || null, popup: popupSnap.data() || null, tutorials: tutorialSnap.docs.map((item) => item.data()) };
    setCachedData(HOME_CONTENT_CACHE_KEY, data);
    if (!cached?.data) renderManagedHomeContent(content, data);
  } catch (error) {
    showServerBusy(error, Boolean(cached?.data));
  }
}

function renderManagedHomeContent(content, { banner, popup, tutorials = [] }) {
    if (banner?.image) {
      const node = document.createElement(banner.link ? "a" : "div");
      node.className = "managed-home-banner";
      if (banner.link) { node.href = banner.link; node.target = "_blank"; node.rel = "noopener"; }
      node.innerHTML = `<img src="${escapeMarkup(banner.image)}" alt="YelePay announcement" loading="lazy" decoding="async">`;
      content.prepend(node);
    }
    if (tutorials.length) {
      const section = document.createElement("section");
      section.className = "managed-tutorials";
      section.innerHTML = `<div class="home-section-header"><h2>Latest Tutorials</h2></div><div class="managed-tutorial-grid">${tutorials.map((data) => `<a href="${escapeMarkup(data.url || "#")}" target="_blank" rel="noopener">${data.thumbnail ? `<img src="${escapeMarkup(data.thumbnail)}" alt="" loading="lazy" decoding="async">` : ""}<strong>${escapeMarkup(data.title || "Tutorial")}</strong></a>`).join("")}</div>`;
      content.append(section);
    }
    const popupKey = `YelePayPopupSeen:${popup?.updatedAt?.seconds || popup?.title || "current"}`;
    if (popup?.enabled && !sessionStorage.getItem(popupKey)) {
      const modal = document.createElement("div");
      modal.className = "managed-popup";
      modal.innerHTML = `<div class="managed-popup-card">${popup.image ? `<img src="${escapeMarkup(popup.image)}" alt="" loading="lazy" decoding="async">` : ""}<h2>${escapeMarkup(popup.title || "YelePay Update")}</h2><p>${escapeMarkup(popup.message || "")}</p><button type="button">Close</button></div>`;
      document.body.appendChild(modal);
      modal.querySelector("button").addEventListener("click", () => { sessionStorage.setItem(popupKey, "1"); modal.remove(); });
    }
}

function renderDashboardProfile(profile) {
  renderAvatar($("#avatar"), profile);
  const displayName = String(profile.name || "").trim() || "User";
  $("#userName").textContent = `Hello, ${displayName}`;
  $("#userId").textContent = `ID: ${playerIdFor(profile)}`;
  $("#balance").textContent = Number(profile.walletBalance || 0).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  $("#todayProfit").textContent = Number(profile.todayProfit || 0).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  $("#totalProfit").textContent = money(profile.totalProfit);
}

function renderProofs() {
  const list = $("#proofList");
  if (!list) return;
  const rows = Array.from({ length: 4 }, (_, i) => {
    const name = proofNames[Math.floor(Math.random() * proofNames.length)];
    const type = proofTypes[Math.floor(Math.random() * proofTypes.length)];
    const amount = [120, 260, 480, 780, 1200, 2400, 5200][Math.floor(Math.random() * 7)];
    return `<div class="proof-item" style="animation-delay:${i * 60}ms">
      <div><strong>${type}</strong><p class="eyebrow">${name} completed just now</p></div>
      <span class="amount">${money(amount)}</span>
    </div>`;
  });
  list.innerHTML = rows.join("");
}

async function listCollection(name, fallback = []) {
  if (!isConfigured || !currentUser) return fallback;
  const q = query(collection(db, name), where("userId", "==", currentUser.uid), limit(50));
  const snap = await getDocs(q);
  return snap.docs
    .map((item) => ({ id: item.id, ...item.data() }))
    .sort((a, b) => withdrawalAccountCreatedAt(b) - withdrawalAccountCreatedAt(a));
}

function purchaseAccountStorageKey() {
  return `YelePayPurchaseAccount:${currentUser?.uid || demoUser.uid}`;
}

function purchaseAccountDomain(platformName) {
  return withdrawTools().find(([name]) => name === platformName)?.[1] || "upi.org.in";
}

function purchaseAccountLogo(platformName) {
  return withdrawalToolLogo(platformName, purchaseAccountDomain(platformName));
}

function selectedPurchaseAccount() {
  return withdrawalAccounts.find((account) => account.id === selectedPurchaseAccountId)
    || withdrawalAccounts.find((account) => String(account.status || "").toLowerCase() === "online")
    || withdrawalAccounts[0]
    || null;
}

async function selectPurchaseAccount(accountId) {
  const account = withdrawalAccounts.find((item) => item.id === accountId) || withdrawalAccounts[0] || null;
  if (!account) return null;
  if (isConfigured && account.userId !== currentUser?.uid) {
    toast("Unable to select this UPI account.", "error");
    return null;
  }
  const previousAccounts = withdrawalAccounts.map((item) => ({ ...item }));
  selectedPurchaseAccountId = account?.id || "";
  if (selectedPurchaseAccountId) localStorage.setItem(purchaseAccountStorageKey(), selectedPurchaseAccountId);
  else localStorage.removeItem(purchaseAccountStorageKey());
  withdrawalAccounts = withdrawalAccounts.map((item) => ({
    ...item,
    status: item.id === selectedPurchaseAccountId ? "online" : "offline"
  }));
  renderPurchaseAccountList();
  renderPurchaseAccountSheet();

  try {
    if (!isConfigured) {
      localStorage.setItem(localWithdrawalAccountsKey(), JSON.stringify(withdrawalAccounts));
    } else {
      const changedAccounts = withdrawalAccounts.filter((item) => {
        const previous = previousAccounts.find((candidate) => candidate.id === item.id);
        return String(previous?.status || "offline").toLowerCase() !== String(item.status || "offline").toLowerCase();
      });
      if (!changedAccounts.length) return withdrawalAccounts.find((item) => item.id === selectedPurchaseAccountId) || account;
      const batch = writeBatch(db);
      changedAccounts.forEach((item) => {
        batch.update(doc(db, "withdrawalAccounts", item.id), {
          status: item.status,
          updatedAt: serverTimestamp()
        });
      });
      await batch.commit();
    }
    return withdrawalAccounts.find((item) => item.id === selectedPurchaseAccountId) || account;
  } catch (error) {
    console.warn("Unable to update UPI account status", error);
    withdrawalAccounts = previousAccounts;
    renderPurchaseAccountList();
    renderPurchaseAccountSheet();
    toast("Unable to update UPI account status.", "error");
    return null;
  }
}

function purchaseAccountCard(account, sheet = false) {
  const selected = account.id === (sheet ? pendingPurchaseAccountId : selectedPurchaseAccountId);
  const status = String(account.status || "offline").toLowerCase();
  return `<article class="purchase-account-option${selected ? " selected" : ""}" data-purchase-account-card="${escapeMarkup(account.id)}">
    <img src="${purchaseAccountLogo(account.platformName)}" alt="${escapeMarkup(account.platformName)} logo" loading="lazy" decoding="async">
    <div><strong>${escapeMarkup(account.platformName || "UPI")}</strong><span>${escapeMarkup(account.upiId || "")}</span><small class="${escapeMarkup(status)}">${escapeMarkup(status.charAt(0).toUpperCase() + status.slice(1))}</small></div>
    <button class="btn ${selected ? "ghost" : ""}" type="button" data-${sheet ? "sheet-" : ""}purchase-account-select="${escapeMarkup(account.id)}">${selected ? "Selected" : "Select"}</button>
  </article>`;
}

function renderPurchaseAccountList() {
  const target = $("#purchaseAccountList");
  if (!target) return;
  if (!purchaseAccountsReady) {
    target.innerHTML = `<div class="purchase-account-loading">Loading UPI accounts...</div>`;
    return;
  }
  if (!withdrawalAccounts.length) {
    target.innerHTML = `<div class="purchase-no-account">
      <span class="purchase-no-account-icon"><i data-lucide="wallet-cards"></i></span>
      <strong>Please add UPI account first</strong>
      <p>No UPI accounts bound</p>
      <button class="btn block" type="button" data-purchase-add-account><i data-lucide="circle-plus"></i><span>Add UPI Account</span></button>
    </div>`;
  } else {
    target.innerHTML = withdrawalAccounts.map((account) => purchaseAccountCard(account)).join("");
  }
  window.setTimeout(() => window.lucide?.createIcons(), 0);
}

function renderPurchaseAccountSheet() {
  const target = $("#purchaseAccountSheetList");
  if (!target) return;
  target.innerHTML = withdrawalAccounts.length
    ? withdrawalAccounts.map((account) => purchaseAccountCard(account, true)).join("")
    : `<div class="purchase-no-account"><span class="purchase-no-account-icon"><i data-lucide="wallet-cards"></i></span><strong>No UPI Account Added</strong></div>`;
  const continueButton = $("#purchaseAccountContinue");
  if (continueButton) continueButton.disabled = !pendingPurchaseAccountId || !withdrawalAccounts.some((account) => account.id === pendingPurchaseAccountId);
  window.setTimeout(() => window.lucide?.createIcons(), 0);
}

function applyPurchaseAccounts(accounts) {
  withdrawalAccounts = [...accounts].sort((a, b) => withdrawalAccountCreatedAt(b) - withdrawalAccountCreatedAt(a));
  const savedAccountId = localStorage.getItem(purchaseAccountStorageKey()) || "";
  const nextId = withdrawalAccounts.some((account) => account.id === selectedPurchaseAccountId)
    ? selectedPurchaseAccountId
    : (withdrawalAccounts.some((account) => account.id === savedAccountId)
      ? savedAccountId
      : (withdrawalAccounts.find((account) => String(account.status || "").toLowerCase() === "online")?.id || withdrawalAccounts[0]?.id || ""));
  selectedPurchaseAccountId = nextId;
  purchaseAccountsReady = true;
  renderPurchaseAccountList();
  renderPurchaseAccountSheet();
}

async function initPurchaseAccounts() {
  if (purchaseAccountsReady) {
    renderPurchaseAccountList();
    renderPurchaseAccountSheet();
    return withdrawalAccounts;
  }
  if (purchaseAccountsLoadPromise) return purchaseAccountsLoadPromise;
  purchaseAccountsLoadPromise = (async () => {
    if (!isConfigured || !currentUser) {
      const saved = JSON.parse(localStorage.getItem(localWithdrawalAccountsKey()) || "[]");
      applyPurchaseAccounts(saved);
      return withdrawalAccounts;
    }
    try {
      const accountQuery = query(collection(db, "withdrawalAccounts"), where("userId", "==", currentUser.uid), limit(20));
      const snapshot = await getDocs(accountQuery);
      applyPurchaseAccounts(snapshot.docs.map((account) => ({ id: account.id, ...account.data() })));
    } catch (error) {
      showServerBusy(error, false);
      applyPurchaseAccounts([]);
    }
    return withdrawalAccounts;
  })().finally(() => { purchaseAccountsLoadPromise = null; });
  return purchaseAccountsLoadPromise;
}

function redirectToPurchaseAccountSetup() {
  const destination = new URL("withdrawal.html", location.href);
  destination.searchParams.set("addAccount", "1");
  destination.searchParams.set("return", "purchase");
  location.href = destination.href;
}

function openPurchaseAccountSheet() {
  pendingPurchaseAccountId = "";
  renderPurchaseAccountSheet();
  $("#purchaseAccountSheet")?.classList.remove("hidden");
}

function closePurchaseAccountSheet() {
  pendingPurchaseAccountId = "";
  $("#purchaseAccountSheet")?.classList.add("hidden");
}

async function continuePurchaseWithAccount(account) {
  const order = pendingPurchaseOrder;
  if (!order || !account) return;
  const selectedAccount = await selectPurchaseAccount(account.id);
  if (!selectedAccount) { renderPurchaseAccountSheet(); return; }
  closePurchaseAccountSheet();
  pendingPurchaseOrder = null;
  await playOrderMatchAnimation(order.amount, order.orderId);
  showPaymentUpi(order.amount, order.orderId, selectedAccount);
}

async function handlePurchaseBuy(amount, orderId) {
  const minimum = effectiveMinBuyAmount();
  renderBuyLimitDebug(amount);
  if (amount < minimum) return toast("Selected order is not available right now.", "error");
  if (!purchaseAccountsReady) await initPurchaseAccounts();
  pendingPurchaseOrder = { amount, orderId };
  openPurchaseAccountSheet();
}

function wirePurchaseAccountUi() {
  if (window.YelePayPurchaseAccountUiBound) return;
  window.YelePayPurchaseAccountUiBound = true;
  $("#purchaseAddAccount")?.addEventListener("click", redirectToPurchaseAccountSetup);
  $("#purchaseSheetAddAccount")?.addEventListener("click", redirectToPurchaseAccountSetup);
  $("#purchaseAccountContinue")?.addEventListener("click", async () => {
    const account = withdrawalAccounts.find((item) => item.id === pendingPurchaseAccountId);
    if (!account || !pendingPurchaseOrder) return;
    const continueButton = $("#purchaseAccountContinue");
    if (continueButton) continueButton.disabled = true;
    await continuePurchaseWithAccount(account);
  });
  $("#closePurchaseAccountSheet")?.addEventListener("click", () => {
    pendingPurchaseOrder = null;
    closePurchaseAccountSheet();
  });
  $("#purchaseAccountSheet")?.addEventListener("click", (event) => {
    if (event.target.id === "purchaseAccountSheet") {
      pendingPurchaseOrder = null;
      closePurchaseAccountSheet();
    }
  });
  $("#purchaseAccountList")?.addEventListener("click", async (event) => {
    if (event.target.closest("[data-purchase-add-account]")) return redirectToPurchaseAccountSetup();
    const selectButton = event.target.closest("[data-purchase-account-select]");
    if (selectButton) await selectPurchaseAccount(selectButton.dataset.purchaseAccountSelect);
  });
  $("#purchaseAccountSheetList")?.addEventListener("click", (event) => {
    const selectButton = event.target.closest("[data-sheet-purchase-account-select]");
    if (!selectButton) return;
    const account = withdrawalAccounts.find((item) => item.id === selectButton.dataset.sheetPurchaseAccountSelect);
    if (!account) return;
    pendingPurchaseAccountId = account.id;
    renderPurchaseAccountSheet();
  });
}

async function initPurchase() {
  if (!requireProfile()) return;
  wirePurchaseAccountUi();
  $("#availableBalance").textContent = money(userProfile.walletBalance);
  renderBuyLimitDebug();
  renderPurchaseOrders();

  const refreshButton = $("#refreshOrders");
  if (refreshButton && !refreshButton.dataset.refreshBound) {
    refreshButton.dataset.refreshBound = "true";
    refreshButton.addEventListener("click", () => {
      renderPurchaseOrders();
      toast("New orders generated.");
    });
  }

  const categoryTabs = $("#orderCategoryTabs");
  if (categoryTabs && !categoryTabs.dataset.categoryBound) {
    categoryTabs.dataset.categoryBound = "true";
    categoryTabs.addEventListener("click", (event) => {
      const button = event.target.closest("[data-category]");
      if (!button) return;
      activePurchaseCategory = button.dataset.category || "small";
      $$("#orderCategoryTabs [data-category]").forEach((item) => item.classList.toggle("active", item === button));
      renderPurchaseOrders();
    });
  }

  const list = $("#orderList");
  if (list && !list.dataset.buyBound) {
    list.dataset.buyBound = "true";
    list.addEventListener("click", async (event) => {
      const button = event.target.closest("[data-buy]");
      if (!button || isMatchingOrder) return;
      const amount = Number(button.dataset.buy);
      await handlePurchaseBuy(amount, button.dataset.orderId);
    });
  }
  wirePaymentModal();
  if (new URLSearchParams(location.search).get("accountAdded") === "1") {
    toast("UPI account added successfully.", "success");
    history.replaceState({}, "", "purchase.html");
  }
}

function renderBuyLimitDebug(selectedOrderAmount = null) {
  const userMinimum = firstPositiveValue(userProfile, ["minBuyAmount", "minimumBuyAmount", "minDepositAmount", "minimumBuy", "minDeposit", "minimumDeposit"]);
  const globalMinimum = Number(settings.minDepositAmount || settings.minPurchase || 0);
  const appliedMinimum = userMinimum || globalMinimum;
  const debugData = {
    userId: currentUser?.uid || userProfile?.uid || "demo",
    userMinBuyAmount: userMinimum,
    globalMinBuyAmount: globalMinimum,
    appliedMinBuyAmount: appliedMinimum,
    selectedOrderAmount
  };
  console.info("[YelePay Buy Limit]", debugData);
  const preview = $("#buyLimitDebug");
  if (!preview) return debugData;
  preview.hidden = new URLSearchParams(location.search).get("debugLimits") !== "1";
  $("#debugLimitUserId").textContent = debugData.userId;
  $("#debugUserMinBuy").textContent = userMinimum ? money(userMinimum) : "Not set";
  $("#debugGlobalMinBuy").textContent = money(globalMinimum);
  $("#debugAppliedMinBuy").textContent = money(appliedMinimum);
  $("#debugSelectedOrder").textContent = selectedOrderAmount === null ? "Not selected" : money(selectedOrderAmount);
  return debugData;
}

function renderPurchaseOrders() {
  const list = $("#orderList");
  if (!list) return;
  const minimum = effectiveMinBuyAmount();
  const orders = generateDepositOrders(activePurchaseCategory);
  if (!orders.length) {
    list.innerHTML = `<div class="empty">No buy orders available right now.</div>`;
    renderBuyLimitDebug();
    return;
  }
  list.innerHTML = orders.map(({ amount, orderId }) => {
    const orderProfitPercentage = getOrderProfitPercentage();
    const profit = amount * orderProfitPercentage / 100;
    const walletReturn = amount + profit;
    return `<article class="card order-card">
      <div class="order-shell">
        <div>
          <div class="amount-line"><span class="currency-badge">INR</span>${money(amount)}</div>
          <p class="eyebrow">Order ID ${orderId}</p>
        </div>
        <button class="btn buy-pill" data-buy="${amount}" data-order-id="${orderId}">Buy</button>
      </div>
      <div class="mini-grid">
        <div class="mini-stat"><span>Income (UPI)</span><strong>${money(profit)} (${orderProfitPercentage}%)</strong></div>
        <div class="mini-stat"><span>Wallet</span><strong>+${money(walletReturn)}</strong></div>
      </div>
    </article>`;
  }).join("");

}

function generateDepositOrders(category = "small") {
  const range = getPurchaseRange(category);
  const minimum = effectiveMinBuyAmount();
  if (range.max < minimum) return [];
  const start = Math.max(range.min, minimum);
  const targetSize = Math.min(7, Math.max(0, range.max - start + 1));
  const amounts = new Set();
  while (amounts.size < targetSize) {
    amounts.add(randomInt(start, range.max));
  }
  return [...amounts]
    .filter((amount) => amount >= minimum)
    .sort((a, b) => a - b)
    .map((amount) => ({ amount, orderId: generateOrderId() }));
}

function getPurchaseRange(category) {
  if (category === "medium") return { min: 1000, max: 2000 };
  if (category === "large") return { min: 2000, max: 5000 };
  const min = Math.max(1, Number(settings.minPurchase || 100));
  const max = Math.min(999, Number(settings.maxPurchase || 999));
  return { min, max: Math.max(min, max) };
}

function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function generateOrderId() {
  let orderId = "";
  do {
    orderId = `ORD${randomInt(100000000, 999999999)}`;
  } while (generatedOrderIds.has(orderId));
  generatedOrderIds.add(orderId);
  return orderId;
}

function roundAway(amount) {
  const value = Number(amount);
  if (value % 100 === 0 || value % 10 === 0) return value + 7;
  return value;
}

const wait = (ms) => new Promise((resolve) => window.setTimeout(resolve, ms));

async function playOrderMatchAnimation(amount) {
  const overlay = $("#matchOverlay");
  if (!overlay) return;
  isMatchingOrder = true;
  const profit = amount * getOrderProfitPercentage() / 100;
  $("#matchOrderValue").textContent = money(amount);
  $("#matchCommission").textContent = `+${money(profit)}`;
  $("#matchStatusText").textContent = "Finding matching merchant...";
  $$("#orderList [data-buy]").forEach((button) => {
    button.disabled = true;
  });
  overlay.classList.remove("hidden", "matched");
  document.body.classList.add("order-matching");
  await wait(2000);
  overlay.classList.add("matched");
  $("#matchStatusText").textContent = "Matched successfully! Redirecting...";
  await wait(700);
  overlay.classList.add("hidden");
  document.body.classList.remove("order-matching");
  $$("#orderList [data-buy]").forEach((button) => {
    button.disabled = false;
  });
  isMatchingOrder = false;
}

function wirePaymentModal() {
  if (window.YelePayPurchaseBound) return;
  window.YelePayPurchaseBound = true;
  $("#closePayment")?.addEventListener("click", () => $("#paymentModal")?.classList.add("hidden"));
  $("#copyPayUpi")?.addEventListener("click", async () => {
    const upi = $("#payUpi")?.textContent || "";
    await navigator.clipboard?.writeText(upi);
    toast("UPI copied.");
  });
  $("#utrInput")?.addEventListener("input", (event) => {
    event.currentTarget.value = event.currentTarget.value.replace(/\D/g, "").slice(0, 12);
  });
  $("#confirmPayment")?.addEventListener("click", async () => {
    const utr = $("#utrInput")?.value.trim().replace(/\D/g, "");
    if (!/^\d{6,12}$/.test(utr)) return toast("UTR must be 6 to 12 digits.");
    $("#utrInput").value = utr;
    pendingPayment = { ...(pendingPayment || {}), utr };
    $("#paymentProcessing")?.classList.remove("hidden");
    $("#confirmPayment").disabled = true;
    $("#confirmPayment").textContent = "UTR Submitted";
    await buyOrder(pendingBuyAmount, pendingPayment);
  });
  $("#sharePayUpi")?.addEventListener("click", async () => {
    const text = `Pay ${$("#payAmount")?.textContent} to ${$("#payUpi")?.textContent}`;
    if (navigator.share) await navigator.share({ text });
    else {
      await navigator.clipboard?.writeText(text);
      toast("Payment details copied.");
    }
  });
}

function showPaymentUpi(amount, orderId = generateOrderId(), payerAccount = selectedPurchaseAccount()) {
  if (!settings.purchaseEnabled) return toast("Purchase is disabled by admin.");
  const upis = Array.isArray(settings.adminUpis) ? settings.adminUpis.filter((item) => item.upiId) : [];
  if (!upis.length) return toast("Admin UPI not available.");
  if (!payerAccount) return toast("Please add UPI account first", "error");
  pendingBuyAmount = amount;
  const selected = upis[Math.floor(Math.random() * upis.length)];
  pendingPayment = {
    upiId: selected.upiId,
    holderName: selected.holderName || "Admin",
    mobile: selected.mobile || "",
    orderId,
    payerAccountId: payerAccount.id,
    payerUpiId: payerAccount.upiId || "",
    payerPlatform: payerAccount.platformName || "UPI"
  };
  $("#payAmount").textContent = money(amount);
  $("#payUpi").textContent = selected.upiId;
  $("#paymentSourceLogo").src = purchaseAccountLogo(payerAccount.platformName);
  $("#paymentSourceLogo").alt = `${payerAccount.platformName || "UPI"} logo`;
  $("#paymentSourcePlatform").textContent = payerAccount.platformName || "UPI Account";
  $("#paymentSourceUpi").textContent = payerAccount.upiId || "";
  $("#payHolder").textContent = `${selected.holderName || "Admin"}${selected.mobile ? `  -  ${selected.mobile}` : ""}`;
  $("#utrInput").value = "";
  $("#paymentProcessing")?.classList.add("hidden");
  $("#confirmPayment").disabled = false;
  $("#confirmPayment").textContent = "Submit UTR";
  const upiLink = createUpiPaymentUri(selected.upiId, amount, selected.holderName, orderId);
  $("#payWithApp").setAttribute("href", upiLink);
  renderBarcode(upiLink);
  $("#paymentModal")?.classList.remove("hidden");
}

function createUpiPaymentUri(upiId, amount, holderName, orderId) {
  const params = new URLSearchParams({
    pa: upiId,
    pn: holderName || "YelePay",
    am: Number(amount).toFixed(2),
    cu: "INR",
    tn: orderId
  });
  return `upi://pay?${params.toString()}`;
}

function renderBarcode(uri) {
  const target = $("#upiBarcode");
  if (!target) return;
  target.innerHTML = "";
  if (window.QRCode) {
    new window.QRCode(target, {
      text: uri,
      width: 208,
      height: 208,
      colorDark: "#141414",
      colorLight: "#ffffff",
      correctLevel: window.QRCode.CorrectLevel.H
    });
    return;
  }
  const fallback = document.createElement("a");
  fallback.href = uri;
  fallback.textContent = "Open UPI payment";
  target.appendChild(fallback);
}

async function buyOrder(amount, paymentMeta = {}) {
  if (!settings.purchaseEnabled) return toast("Purchase is disabled by admin.");
  if (Number(userProfile.todayOrders || 0) >= Number(settings.dailyOrderLimit || 0)) return toast("Daily order limit reached.");
  const orderProfitPercentage = getOrderProfitPercentage();
  const profit = amount * orderProfitPercentage / 100;
  const commissionAmount = profit;
  const orderId = paymentMeta.orderId || generateOrderId();
  const utrNumber = paymentMeta.utr || "";
  const order = {
    userId: currentUser.uid,
    userName: userProfile.name || "",
    userMobile: userProfile.mobile || "",
    orderId,
    amount,
    commissionAmount,
    profitPercent: orderProfitPercentage,
    expectedProfit: profit,
    durationHours: settings.orderDuration,
    paymentUpi: paymentMeta.upiId || "",
    paymentUpiId: paymentMeta.upiId || paymentMeta.paymentUpiId || paymentMeta.selectedUpiId || "",
    payerAccountId: paymentMeta.payerAccountId || "",
    payerUpiId: paymentMeta.payerUpiId || "",
    payerPlatform: paymentMeta.payerPlatform || "",
    utr: utrNumber,
    utrNumber,
    status: "processing",
    credited: false,
    createdAt: serverTimestamp ? serverTimestamp() : new Date().toISOString()
  };

  if (isConfigured) {
    await runTransaction(db, async (tx) => {
      const userRef = doc(db, "users", currentUser.uid);
      tx.update(userRef, { todayOrders: increment(1) });
      const orderRef = doc(collection(db, "orders"));
      const txRef = doc(collection(db, "transactions"));
      const requestRef = doc(collection(db, "payments"));
      const approvalData = {
        userId: currentUser.uid,
        userName: userProfile.name || "",
        userMobile: userProfile.mobile || "",
        orderId,
        amount,
        commissionAmount,
        utrNumber,
        upiId: paymentMeta.upiId || "",
        paymentUpiId: paymentMeta.upiId || paymentMeta.paymentUpiId || paymentMeta.selectedUpiId || "",
        payerAccountId: paymentMeta.payerAccountId || "",
        payerUpiId: paymentMeta.payerUpiId || "",
        payerPlatform: paymentMeta.payerPlatform || "",
        status: "processing",
        credited: false,
        orderDocId: orderRef.id,
        transactionDocId: txRef.id,
        createdAt: serverTimestamp()
      };
      tx.set(orderRef, order);
      tx.set(txRef, {
        userId: currentUser.uid,
        type: "purchase",
        amount,
        commissionAmount,
        status: "processing",
        title: "Purchase order",
        orderId,
        upiId: paymentMeta.upiId || "",
        paymentUpiId: paymentMeta.upiId || paymentMeta.paymentUpiId || paymentMeta.selectedUpiId || "",
        payerAccountId: paymentMeta.payerAccountId || "",
        payerUpiId: paymentMeta.payerUpiId || "",
        payerPlatform: paymentMeta.payerPlatform || "",
        utr: utrNumber,
        utrNumber,
        requestDocId: requestRef.id,
        orderDocId: orderRef.id,
        credited: false,
        createdAt: serverTimestamp()
      });
      tx.set(requestRef, approvalData);
    });
    userProfile = { ...userProfile, todayOrders: Number(userProfile.todayOrders || 0) + 1 };
    cacheUser(userProfile);
  } else {
    userProfile.todayOrders += 1;
  }
  toast("Please wait while your order is getting processed\nIt may take up to 1-2 minutes", "success");
  if ($("#availableBalance")) $("#availableBalance").textContent = money(userProfile.walletBalance);
  renderPurchaseOrders();
}

async function processCompletedOrders() {
  if (!isConfigured || !currentUser) return;
  const q = query(collection(db, "orders"), where("userId", "==", currentUser.uid), where("status", "==", "active"), limit(30));
  const snap = await getDocs(q);
  const now = Date.now();
  for (const item of snap.docs) {
    const order = item.data();
    const created = order.createdAt?.toMillis ? order.createdAt.toMillis() : now;
    const dueAt = created + Number(order.durationHours || settings.orderDuration) * 60 * 60 * 1000;
    if (now >= dueAt) {
      await completeOrder(item.id, Number(order.amount || 0), Number(order.expectedProfit || 0));
    }
  }
  userProfile = await readUser(currentUser.uid);
}

async function completeOrder(orderId, amount, profit) {
  if (!isConfigured) return;
  await updateDoc(doc(db, "orders", orderId), { status: "completed", completedAt: serverTimestamp() });
  await updateDoc(doc(db, "users", currentUser.uid), {
    walletBalance: increment(amount + profit),
    todayProfit: increment(profit),
    totalProfit: increment(profit),
    totalIncome: increment(profit)
  });
  await addDoc(collection(db, "transactions"), {
    userId: currentUser.uid,
    type: "profit",
    amount: profit,
    status: "Success",
    title: "Order profit",
    createdAt: serverTimestamp()
  });
}

async function initUpi() {
  if (!requireProfile()) return;
  $("#upiForm")?.addEventListener("submit", saveUpi);
  renderPaymentList("upi", $("#upiList"));
}

async function saveUpi(event) {
  event.preventDefault();
  const upiForm = event.currentTarget;
  if (!(upiForm instanceof HTMLFormElement)) return toast("Add UPI form is unavailable.", "error");
  const form = new FormData(upiForm);
  const pin = [...$$(".pin-row .input")].map((input) => input.value).join("");
  const data = {
    userId: currentUser.uid,
    holderName: form.get("holderName").trim(),
    mobile: form.get("mobile").trim(),
    upiId: form.get("upiId").trim(),
    pin,
    verified: true,
    createdAt: serverTimestamp ? serverTimestamp() : new Date().toISOString()
  };
  if (isConfigured) await addDoc(collection(db, "upi"), data);
  toast("UPI Added Successfully", "success");
  upiForm.reset();
  renderPaymentList("upi", $("#upiList"));
}

async function initBank() {
  if (!requireProfile()) return;
  $("#bankForm")?.addEventListener("submit", saveBank);
  renderPaymentList("banks", $("#bankList"));
}

async function saveBank(event) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const data = {
    userId: currentUser.uid,
    holderName: form.get("holderName").trim(),
    accountNumber: form.get("accountNumber").trim(),
    ifsc: form.get("ifsc").trim().toUpperCase(),
    bankName: form.get("bankName").trim(),
    branchName: form.get("branchName").trim(),
    verified: true,
    createdAt: serverTimestamp ? serverTimestamp() : new Date().toISOString()
  };
  if (isConfigured) await addDoc(collection(db, "banks"), data);
  toast("Bank verified.");
  event.currentTarget.reset();
  renderPaymentList("banks", $("#bankList"));
}

async function renderPaymentList(collectionName, target) {
  if (!target) return;
  const fallback = collectionName === "upi"
    ? [{ id: "demo-upi", holderName: userProfile.name, upiId: "demo@upi", mobile: userProfile.mobile, verified: true }]
    : [{ id: "demo-bank", holderName: userProfile.name, bankName: "YelePay Bank", accountNumber: "XXXX8091", verified: true }];
  const rows = await listCollection(collectionName, fallback);
  target.innerHTML = rows.length ? rows.map((item) => `<div class="list-row">
    <div>
      <strong>${item.holderName || item.bankName}</strong>
      <p class="eyebrow">${item.upiId || item.accountNumber || item.mobile || item.ifsc}</p>
    </div>
    <div class="icon-row">
      <span class="status-pill success">Verified</span>
      <button class="icon-btn" data-delete="${collectionName}:${item.id}" title="Delete"><span class="icon i-trash"></span></button>
    </div>
  </div>`).join("") : `<div class="empty">No ${collectionName} details added yet.</div>`;

  target.onclick = async (event) => {
    const button = event.target.closest("[data-delete]");
    if (!button) return;
    const [name, id] = button.dataset.delete.split(":");
    if (isConfigured) await deleteDoc(doc(db, name, id));
    toast("Deleted.");
    renderPaymentList(collectionName, target);
  };
}

async function initWithdrawal() {
  if (!requireProfile()) return;
  const balanceTarget = $("#withdrawBalance");
  const minimumTarget = $("#minimumWithdrawText") || $("#withdrawMinText");
  if (balanceTarget) balanceTarget.textContent = money(userProfile?.walletBalance);
  if (minimumTarget) minimumTarget.textContent = money(effectiveMinWithdrawAmount());
  renderWithdrawTools();
  wireWithdrawToolFlow();
  wireWithdrawMethodTabs();
  $("#withdrawForm")?.addEventListener("submit", createWithdraw);
  listenWithdrawalAccounts();
  const withdrawalParams = new URLSearchParams(location.search);
  if (withdrawalParams.get("addAccount") === "1" || withdrawalParams.get("action") === "add-upi") {
    window.setTimeout(() => $("#toolSheet")?.classList.remove("hidden"), 80);
  }
  await Promise.all([
    fillSelect("upi", $("#upiSelect"), "upiId"),
    fillSelect("banks", $("#bankSelect"), "bankName")
  ]);
  renderHistory("withdraw", $("#withdrawHistory"));
}

function withdrawTools() {
  return [
    ["Navi", "navi.com"],
    ["Slice", "sliceit.com"],
    ["Amazon", "amazon.in"],
    ["Paytm", "paytm.com"],
    ["Airtel", "airtel.in"],
    ["Mobikwik", "mobikwik.com"],
    ["PhonePe", "phonepe.com"]
  ];
}

function withdrawalToolLogo(platformName, domain = "upi.org.in") {
  const localLogos = {
    slice: "slice.png",
    mobikwik: "mobikwik.png",
    paytm: "paytm.png"
  };
  return localLogos[String(platformName || "").toLowerCase()]
    || `https://www.google.com/s2/favicons?domain=${encodeURIComponent(domain)}&sz=128`;
}

function renderWithdrawTools() {
  const target = $("#toolList");
  if (!target) return;
  target.innerHTML = withdrawTools().map(([name, domain]) => `<button class="tool-card withdrawal-tool-card" type="button" data-tool-select="${escapeMarkup(name)}">
    <div>
      <h2>${name}</h2>
      <div class="tool-actions"><span class="mini-btn muted-chip">buy</span><span class="mini-btn">sell</span></div>
    </div>
    <img class="tool-logo" alt="${name}" src="${withdrawalToolLogo(name, domain)}" loading="lazy" decoding="async">
  </button>`).join("");
  window.setTimeout(() => window.lucide?.createIcons(), 0);
}

function withdrawalAccountCreatedAt(account) {
  const value = account.createdAt;
  if (value?.toMillis) return value.toMillis();
  const parsed = new Date(value || 0).getTime();
  return Number.isFinite(parsed) ? parsed : 0;
}

function maskedWithdrawalPhone(phone, uid) {
  const digits = String(phone || "").replace(/\D/g, "");
  if (digits.length !== 10) return `${numericProfileId(uid)}-${maskMobile(digits)}`;
  return `${numericProfileId(uid)}-${digits.slice(0, 3)}xxxxx${digits.slice(-2)}`;
}

function maskedWithdrawalUpi(upiId) {
  const [name = "UPI", handle = ""] = String(upiId || "").split("@");
  const maskedName = name.length > 4 ? `${name.slice(0, 2)}***${name.slice(-1)}` : `${name.slice(0, 1)}***`;
  const maskedHandle = handle ? `@${handle.slice(0, 3)}` : "";
  return `${maskedName}${maskedHandle}`;
}

function syncWithdrawalAccountSelection(accountId) {
  const account = withdrawalAccounts.find((item) => item.id === accountId) || withdrawalAccounts[0] || null;
  selectedWithdrawalAccountId = account?.id || "";
  selectedWithdrawUpi = account?.upiId || "";
  selectedWithdrawTool = account?.platformName || "";
  if ($("#upiAppInput")) $("#upiAppInput").value = selectedWithdrawTool;
  $$(".withdrawal-account-card").forEach((card) => card.classList.toggle("selected", card.dataset.accountId === selectedWithdrawalAccountId));
}

function renderWithdrawalAccounts(accounts) {
  const target = $("#withdrawalAccountList");
  if (!target) return;
  withdrawalAccounts = [...accounts].sort((a, b) => withdrawalAccountCreatedAt(b) - withdrawalAccountCreatedAt(a));
  const count = $("#withdrawalAccountCount");
  if (count) count.textContent = `${withdrawalAccounts.length} ${withdrawalAccounts.length === 1 ? "account" : "accounts"}`;
  if (!withdrawalAccounts.length) {
    target.innerHTML = `<div class="empty">No UPI account added yet.</div>`;
    syncWithdrawalAccountSelection("");
    return;
  }

  target.innerHTML = withdrawalAccounts.map((account) => {
    const platform = withdrawTools().find(([name]) => name === account.platformName);
    const domain = platform?.[1] || "upi.org.in";
    return `<article class="withdrawal-account-card" data-account-id="${escapeMarkup(account.id)}" tabindex="0">
      <div class="withdraw-account-top">
        <div><strong>${escapeMarkup(maskedWithdrawalUpi(account.upiId))}</strong><span>${escapeMarkup(maskedWithdrawalPhone(account.phone, account.userId))}</span></div>
        <img class="withdraw-account-logo" src="${withdrawalToolLogo(account.platformName, domain)}" alt="${escapeMarkup(account.platformName)} logo" loading="lazy" decoding="async">
      </div>
      <div class="withdraw-account-warning"><i data-lucide="circle-alert"></i><span>Please do not log into this wallet after the withdrawal has started</span><button type="button" data-account-settings="${escapeMarkup(account.id)}" aria-label="Account settings"><i data-lucide="settings"></i></button></div>
    </article>`;
  }).join("");

  syncWithdrawalAccountSelection(selectedWithdrawalAccountId);
  window.setTimeout(() => window.lucide?.createIcons(), 0);
}

function localWithdrawalAccountsKey() {
  return `YelePayWithdrawalAccounts:${currentUser?.uid || demoUser.uid}`;
}

async function listenWithdrawalAccounts() {
  if (!isConfigured || !currentUser) {
    const saved = JSON.parse(localStorage.getItem(localWithdrawalAccountsKey()) || "[]");
    renderWithdrawalAccounts(saved);
    return;
  }
  try {
    const accountQuery = query(collection(db, "withdrawalAccounts"), where("userId", "==", currentUser.uid), limit(20));
    const snapshot = await getDocs(accountQuery);
    renderWithdrawalAccounts(snapshot.docs.map((account) => ({ id: account.id, ...account.data() })));
  } catch (error) {
    showServerBusy(error, withdrawalAccounts.length > 0);
    if (!withdrawalAccounts.length) renderWithdrawalAccounts([]);
  }
}

function openWithdrawAccountSettings(accountId) {
  if (!withdrawalAccounts.some((account) => account.id === accountId)) return;
  pendingDeleteWithdrawalAccountId = accountId;
  $("#withdrawAccountSettingsSheet")?.classList.remove("hidden");
}

function closeWithdrawAccountSettings(clearSelection = false) {
  $("#withdrawAccountSettingsSheet")?.classList.add("hidden");
  if (clearSelection) pendingDeleteWithdrawalAccountId = "";
}

function openDeleteToolConfirmation() {
  if (!pendingDeleteWithdrawalAccountId) return;
  closeWithdrawAccountSettings(false);
  $("#deleteToolModal")?.classList.remove("hidden");
}

function closeDeleteToolConfirmation(clearSelection = true) {
  $("#deleteToolModal")?.classList.add("hidden");
  if (clearSelection) pendingDeleteWithdrawalAccountId = "";
}

async function deleteWithdrawalAccount() {
  if (isDeletingWithdrawalAccount || !pendingDeleteWithdrawalAccountId) return;
  const accountId = pendingDeleteWithdrawalAccountId;
  const existingAccounts = [...withdrawalAccounts];
  if (!existingAccounts.some((account) => account.id === accountId)) {
    closeDeleteToolConfirmation();
    return toast("UPI account not found.", "error");
  }

  const deleteButton = $("#confirmDeleteTool");
  isDeletingWithdrawalAccount = true;
  if (deleteButton) {
    deleteButton.disabled = true;
    deleteButton.textContent = "Deleting...";
  }
  renderWithdrawalAccounts(existingAccounts.filter((account) => account.id !== accountId));

  try {
    if (isConfigured && currentUser) {
      await deleteDoc(doc(db, "withdrawalAccounts", accountId));
    } else {
      const rows = JSON.parse(localStorage.getItem(localWithdrawalAccountsKey()) || "[]");
      localStorage.setItem(localWithdrawalAccountsKey(), JSON.stringify(rows.filter((account) => account.id !== accountId)));
    }
    closeDeleteToolConfirmation();
    toast("Tool Deleted Successfully", "success");
  } catch (error) {
    console.warn("Unable to delete withdrawal account", error);
    renderWithdrawalAccounts(existingAccounts);
    toast(friendlyError(error, "Unable to delete tool."), "error");
  } finally {
    isDeletingWithdrawalAccount = false;
    if (deleteButton) {
      deleteButton.disabled = false;
      deleteButton.textContent = "Delete";
    }
  }
}

async function withdrawalAccountDocumentId(value) {
  if (window.crypto?.subtle && window.TextEncoder) {
    const digest = await window.crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
    return `wa_${[...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("")}`;
  }
  let hash = 2166136261;
  for (const character of value) hash = Math.imul(hash ^ character.charCodeAt(0), 16777619);
  return `wa_${(hash >>> 0).toString(16)}`;
}

async function saveWithdrawalAccount({ platformName, phone, upiId }) {
  const normalizedUpi = upiId.trim().toLowerCase();
  const userId = currentUser?.uid || demoUser.uid;
  const id = await withdrawalAccountDocumentId(`${userId}|${platformName.toLowerCase()}|${normalizedUpi}`);
  const data = {
    userId,
    platformName,
    phone,
    upiId: normalizedUpi,
    pin: "protected",
    status: "offline",
    sellingStatus: "stopped",
    isSelling: false
  };

  if (!isConfigured) {
    const rows = JSON.parse(localStorage.getItem(localWithdrawalAccountsKey()) || "[]");
    if (rows.some((account) => account.id === id)) throw new Error("This platform and UPI ID is already added.");
    const localAccount = { id, ...data, createdAt: new Date().toISOString() };
    localStorage.setItem(localWithdrawalAccountsKey(), JSON.stringify([localAccount, ...rows]));
    return localAccount;
  }

  const accountRef = doc(db, "withdrawalAccounts", id);
  await runTransaction(db, async (transaction) => {
    const existing = await transaction.get(accountRef);
    if (existing.exists()) throw new Error("This platform and UPI ID is already added.");
    transaction.set(accountRef, { ...data, createdAt: serverTimestamp() });
  });
  return { id, ...data, createdAt: new Date().toISOString() };
}

function closeWithdrawAuthorization(showTools = false) {
  $("#authorizePanel")?.classList.add("hidden");
  document.body.classList.remove("withdraw-auth-open");
  if (showTools) $("#toolSheet")?.classList.remove("hidden");
}

function openWithdrawAuthorization(platformName) {
  selectedWithdrawTool = platformName;
  const authorizeForm = $("#authorizeForm");
  const authorizePanel = $("#authorizePanel");
  if (!authorizeForm || !authorizePanel) {
    toast("Unable to open Add UPI form.", "error");
    return;
  }
  $("#toolSheet")?.classList.add("hidden");
  authorizeForm.reset();
  const title = $("#authorizeTitle");
  const platformLabel = $("#authorizePlatformName");
  const instructionPlatform = $("#authorizeInstructionPlatform");
  if (title) title.textContent = `Authorize ${platformName}`;
  if (platformLabel) platformLabel.textContent = platformName;
  if (instructionPlatform) instructionPlatform.textContent = platformName;
  authorizePanel.classList.remove("hidden");
  document.body.classList.add("withdraw-auth-open");
  window.setTimeout(() => $("#authorizeForm [name='phone']")?.focus(), 180);
}

function wireWithdrawToolFlow() {
  $("#showToolList")?.addEventListener("click", () => $("#toolSheet")?.classList.remove("hidden"));
  $("#closeToolSheet")?.addEventListener("click", () => $("#toolSheet")?.classList.add("hidden"));
  $("#toolSheet")?.addEventListener("click", (event) => {
    if (event.target.id === "toolSheet") $("#toolSheet")?.classList.add("hidden");
  });
  $("#toolList")?.addEventListener("click", (event) => {
    const card = event.target.closest("[data-tool-select]");
    if (card) openWithdrawAuthorization(card.dataset.toolSelect);
  });
  $("#backToTools")?.addEventListener("click", () => closeWithdrawAuthorization(true));

  const phoneInput = $("#authorizeForm [name='phone']");
  phoneInput?.addEventListener("input", () => {
    phoneInput.value = phoneInput.value.replace(/\D/g, "").slice(0, 10);
  });

  const pinInputs = $$(".auth-pin-row .input");
  pinInputs.forEach((input, index) => {
    input.addEventListener("input", () => {
      input.value = input.value.replace(/\D/g, "").slice(0, 1);
      if (input.value && pinInputs[index + 1]) pinInputs[index + 1].focus();
    });
    input.addEventListener("keydown", (event) => {
      if (event.key === "Backspace" && !input.value && pinInputs[index - 1]) pinInputs[index - 1].focus();
    });
    input.addEventListener("paste", (event) => {
      const digits = event.clipboardData?.getData("text").replace(/\D/g, "").slice(0, 6) || "";
      if (digits.length < 2) return;
      event.preventDefault();
      digits.split("").forEach((digit, digitIndex) => {
        if (pinInputs[digitIndex]) pinInputs[digitIndex].value = digit;
      });
      pinInputs[Math.min(digits.length, 6) - 1]?.focus();
    });
  });

  $("#authorizeForm")?.addEventListener("submit", async (event) => {
    event.preventDefault();
    const authorizeForm = event.currentTarget;
    if (!(authorizeForm instanceof HTMLFormElement)) return toast("Add UPI form is unavailable.", "error");
    const form = new FormData(authorizeForm);
    const phone = String(form.get("phone") || "").replace(/\D/g, "");
    const upiId = String(form.get("upiId") || "").trim();
    const pin = pinInputs.map((input) => input.value.trim()).join("");
    if (!/^\d{10}$/.test(phone)) return toast("Please enter exactly 10 digit phone number.", "error");
    if (!/^[^\s@]+@[^\s@]+$/.test(upiId)) return toast("Please enter a valid UPI ID containing @.", "error");
    if (!/^\d{6}$/.test(pin)) return toast("Please enter exactly 6 digit Pin Code.", "error");

    const submitButton = $("#authorizeSubmit");
    const loader = $("#accountAuthLoading");
    if (submitButton) submitButton.disabled = true;
    loader?.classList.remove("hidden");
    try {
      const [account] = await Promise.all([
        saveWithdrawalAccount({ platformName: selectedWithdrawTool, phone, upiId }),
        wait(850)
      ]);
      selectedWithdrawalAccountId = account.id;
      selectedWithdrawUpi = account.upiId;
      if (!withdrawalAccounts.some((item) => item.id === account.id)) renderWithdrawalAccounts([account, ...withdrawalAccounts]);
      syncWithdrawalAccountSelection(account.id);
      closeWithdrawAuthorization(false);
      authorizeForm.reset();
      toast("UPI Added Successfully", "success");
      if (new URLSearchParams(location.search).get("return") === "purchase") {
        window.setTimeout(() => {
          location.href = "purchase.html?accountAdded=1";
        }, 900);
      }
    } catch (error) {
      console.warn(error);
      toast(friendlyError(error, "Unable to add UPI account."), "error");
    } finally {
      loader?.classList.add("hidden");
      if (submitButton) submitButton.disabled = false;
    }
  });

  $("#withdrawalAccountList")?.addEventListener("click", (event) => {
    const settingsButton = event.target.closest("[data-account-settings]");
    if (settingsButton) return openWithdrawAccountSettings(settingsButton.dataset.accountSettings);
    const card = event.target.closest("[data-account-id]");
    if (card) syncWithdrawalAccountSelection(card.dataset.accountId);
  });
  $("#closeWithdrawAccountSettings")?.addEventListener("click", () => closeWithdrawAccountSettings(true));
  $("#withdrawAccountSettingsSheet")?.addEventListener("click", (event) => {
    if (event.target.id === "withdrawAccountSettingsSheet") closeWithdrawAccountSettings(true);
  });
  $("#removeToolAction")?.addEventListener("click", openDeleteToolConfirmation);
  $("#cancelDeleteTool")?.addEventListener("click", () => closeDeleteToolConfirmation(true));
  $("#deleteToolModal")?.addEventListener("click", (event) => {
    if (event.target.id === "deleteToolModal") closeDeleteToolConfirmation(true);
  });
  $("#confirmDeleteTool")?.addEventListener("click", deleteWithdrawalAccount);
  $("#closeLimitPopup")?.addEventListener("click", () => $("#limitPopup")?.classList.add("hidden"));
}

function wireWithdrawMethodTabs() {
  const tabs = $("#withdrawMethodTabs");
  if (!tabs || tabs.dataset.bound) return;
  tabs.dataset.bound = "true";
  tabs.addEventListener("click", (event) => {
    const button = event.target.closest("[data-method]");
    if (!button) return;
    const method = button.dataset.method;
    $$("#withdrawMethodTabs [data-method]").forEach((item) => item.classList.toggle("active", item === button));
    $$(".withdraw-method-field").forEach((panel) => panel.classList.toggle("hidden", panel.dataset.methodPanel !== method));
    const methodInput = $("#withdrawMethodInput");
    if (methodInput) methodInput.value = method;
  });
}

async function fillSelect(collectionName, select, labelKey) {
  if (!select) return;
  const fallback = collectionName === "upi"
    ? [{ id: "demo-upi", upiId: "demo@upi" }]
    : [{ id: "demo-bank", bankName: "YelePay Bank" }];
  const rows = await listCollection(collectionName, fallback);
  select.innerHTML = `<option value="">Select ${collectionName === "upi" ? "UPI" : "Bank"}</option>` + rows.map((item) => `<option value="${item.id}">${item[labelKey]}</option>`).join("");
}

function requiredCompletedOrdersForWithdrawal() {
  const configured = Number(settings.minCompletedOrdersForWithdrawal);
  return Number.isFinite(configured) && configured > 0 ? Math.floor(configured) : 3;
}

async function getCompletedPurchaseOrderCount() {
  if (!isConfigured || !currentUser) {
    return Number(userProfile?.completedOrderCount ?? userProfile?.completedOrders ?? requiredCompletedOrdersForWithdrawal());
  }
  const completedQuery = query(
    collection(db, "payments"),
    where("userId", "==", currentUser.uid),
    where("status", "==", "completed")
  );
  const snapshot = await getCountFromServer(completedQuery);
  return Number(snapshot.data()?.count || 0);
}

async function createWithdraw(event) {
  event.preventDefault();
  if (!settings.withdrawEnabled) return safePopup("Withdraw is disabled by admin.");
  const withdrawForm = event.currentTarget instanceof HTMLFormElement ? event.currentTarget : $("#withdrawForm");
  if (!(withdrawForm instanceof HTMLFormElement)) return safePopup("Withdrawal form is unavailable.");
  const submitButton = $("#withdrawBtn") || $("#withdrawSubmit") || withdrawForm.querySelector('button[type="submit"]');
  const amountInput = $("#withdrawAmount") || withdrawForm.elements.namedItem("amount");
  const form = new FormData(withdrawForm);
  const amount = Number(amountInput?.value || form.get("amount") || 0);
  const method = form.get("method") || "UPI";
  const upiSelection = form.get("upi") || "";
  const bankId = form.get("bank") || "";
  const selectedUpiText = $("#upiSelect")?.selectedOptions?.[0]?.textContent || "";
  const selectedBankText = $("#bankSelect")?.selectedOptions?.[0]?.textContent || "";
  const selectedAccount = withdrawalAccounts.find((item) => item.id === selectedWithdrawalAccountId) || null;
  if (!amount) return safePopup("Please enter withdrawal amount.");
  const minimumWithdraw = effectiveMinWithdrawAmount();
  const userBalance = Number(userProfile?.walletBalance || 0);
  const requiredOrders = requiredCompletedOrdersForWithdrawal();
  console.info("[YelePay Withdrawal Check]", { amount, minWithdrawAmount: minimumWithdraw, userBalance, completedOrders: null, requiredOrders });
  if (amount < minimumWithdraw) return safePopup(`Minimum Withdrawal Amount is ${money(minimumWithdraw)}`);
  if (amount > userBalance) return safePopup("Insufficient balance.");
  if (userBalance >= minimumWithdraw) {
    try {
      const completedOrders = await getCompletedPurchaseOrderCount();
      console.info("[YelePay Withdrawal Check]", { amount, minWithdrawAmount: minimumWithdraw, userBalance, completedOrders, requiredOrders });
      if (completedOrders < requiredOrders) return safePopup(`Complete minimum ${requiredOrders} orders before withdrawal`);
    } catch (error) {
      console.warn("Unable to verify completed purchase orders.", error);
      return safePopup("Unable to verify completed orders. Please try again.");
    }
  }
  if (method === "UPI" && !selectedWithdrawUpi && !upiSelection) return safePopup("Please select UPI ID.");
  if (method === "Bank" && !bankId) return safePopup("Please select bank details.");

  $("#withdrawProcessOverlay")?.classList.remove("hidden");
  const processText = $("#withdrawProcessText");
  if (processText) processText.textContent = "Processing Withdrawal...";
  if (submitButton) submitButton.disabled = true;
  await wait(1200);
  if (processText) processText.textContent = "Submitting Request...";
  await wait(1000);

  const data = {
    userId: currentUser.uid,
    userName: userProfile.name || "",
    userMobile: userProfile.mobile || "",
    amount,
    method,
    upiId: method === "UPI" ? (selectedWithdrawUpi || selectedUpiText || upiSelection) : "",
    upiAccountId: method === "UPI" ? (selectedAccount?.id || "") : "",
    bankDetails: method === "Bank" ? selectedBankText : "",
    bankId: method === "Bank" ? bankId : "",
    upiApp: form.get("upiApp") || selectedAccount?.platformName || "",
    status: "processing",
    createdAt: serverTimestamp ? serverTimestamp() : new Date().toISOString()
  };
  try {
    if (isConfigured) {
      const requestRef = await addDoc(collection(db, "withdrawals"), data);
      const txRef = await addDoc(collection(db, "transactions"), {
        ...data,
        withdrawalDocId: requestRef.id,
        type: "withdraw",
        title: "Withdraw request"
      });
      await updateDoc(requestRef, { transactionDocId: txRef.id });
    }
    toast("Withdrawal request submitted.", "success");
    withdrawForm.reset();
    const methodInput = $("#withdrawMethodInput");
    if (methodInput) methodInput.value = "UPI";
    syncWithdrawalAccountSelection(selectedAccount?.id || selectedWithdrawalAccountId);
    await renderHistory("withdraw", $("#withdrawHistory"));
  } catch (error) {
    console.warn(error);
    toast(friendlyError(error, "Withdrawal request failed."), "error");
  } finally {
    $("#withdrawProcessOverlay")?.classList.add("hidden");
    if (submitButton) submitButton.disabled = false;
  }
}

async function initTeam() {
  if (!requireProfile()) return;
  const code = userProfile.referralCode || referralCode(userProfile.uid);
  const referralUrl = new URL("/signup.html", location.origin);
  referralUrl.searchParams.set("ref", code);
  const link = referralUrl.href;
  let directCount = Number(userProfile.teamCount || 0);
  let secondLevelCount = Number(userProfile.secondLevelCount || 0);

  $("#referralCode").textContent = code;
  $("#referralLink").textContent = link;
  renderTeamSummary(userProfile, directCount, secondLevelCount);

  $("#copyReferralCode")?.addEventListener("click", () => copyTeamValue(code));
  $("#copyReferralLink")?.addEventListener("click", () => copyTeamValue(link));
  const shareText = `Join my YelePay team with invite code ${code}`;
  $("#shareWhatsapp").href = `https://wa.me/?text=${encodeURIComponent(`${shareText} ${link}`)}`;
  $("#shareFacebook").href = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(link)}`;
  $("#shareTelegram").href = `https://t.me/share/url?url=${encodeURIComponent(link)}&text=${encodeURIComponent(shareText)}`;

  $("#showReferralQr")?.addEventListener("click", () => showTeamQr(link));
  $$('[data-team-qr-close]').forEach((button) => button.addEventListener("click", closeTeamQr));
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") closeTeamQr();
  });

  window.setTimeout(() => window.lucide?.createIcons(), 0);
}

function renderTeamSummary(profile, directCount, secondLevelCount) {
  const totalEarnings = Number(profile.teamIncome || 0) + Number(profile.teamProfit || 0);
  const totalSublines = Number(directCount || 0) + Number(secondLevelCount || 0);
  $("#teamTotalEarnings").textContent = totalEarnings.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  $("#directTeam").textContent = Number(directCount || 0);
  $("#indirectTeam").textContent = Number(secondLevelCount || 0);
  $("#teamTodayDeposits").textContent = Number(profile.teamTodayDepositCount || 0);
  $("#teamTodayEarnings").textContent = Number(profile.teamTodayEarnings || 0).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  $("#teamYesterdayDeposits").textContent = Number(profile.teamYesterdayDepositCount || 0);
  $("#teamYesterdayEarnings").textContent = Number(profile.teamYesterdayEarnings || 0).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  $("#teamTotalDeposits").textContent = Number(profile.teamTotalDepositCount || 0);
  $("#teamTotalSublines").textContent = totalSublines;
  $("#teamActivated").textContent = Number(directCount || 0);
  $("#teamInviteEarned").textContent = money(profile.inviteReward || 0);
  $("#teamGoalProgress").style.width = `${Math.min(100, (Number(directCount || 0) / 15) * 100)}%`;
}

async function copyTeamValue(value) {
  const copied = await copyToClipboard(value);
  toast(copied ? "Copied Successfully" : "Unable to copy", copied ? "success" : "error");
}

function showTeamQr(link) {
  const modal = $("#teamQrModal");
  const target = $("#teamQrCode");
  if (!modal || !target) return;
  if (!window.QRCode) return toast("QR code is unavailable", "error");
  target.innerHTML = "";
  new window.QRCode(target, {
    text: link,
    width: 220,
    height: 220,
    colorDark: "#20233a",
    colorLight: "#ffffff",
    correctLevel: window.QRCode.CorrectLevel.H
  });
  modal.classList.remove("hidden");
  document.body.classList.add("team-qr-open");
}

function closeTeamQr() {
  $("#teamQrModal")?.classList.add("hidden");
  document.body.classList.remove("team-qr-open");
}

async function initProfile() {
  if (!requireProfile()) return;
  await Promise.all([ensureUserAvatar(), ensureUserPlayerId()]);
  renderProfileData(userProfile);
  applyLanguage(localStorage.getItem("YelePayLanguage") || userProfile.language || "English", false);
  $("#profileForm")?.addEventListener("submit", updateUserProfile);
  $("#passwordForm")?.addEventListener("submit", changePassword);
  $("#giftRedeemForm")?.addEventListener("submit", redeemGiftCode);
  $("#securityPinForm")?.addEventListener("submit", saveSecurityPin);
  $("#installApp")?.addEventListener("click", installYelePayApp);
  $("#profileAvatar")?.addEventListener("click", openAvatarModal);
  $("#closeAvatarModal")?.addEventListener("click", closeAvatarModal);
  $("#avatarModal")?.addEventListener("click", (event) => { if (event.target.id === "avatarModal") closeAvatarModal(); });
  $("#avatarGrid")?.addEventListener("click", selectAvatar);

  $$('[data-profile-open]').forEach((button) => button.addEventListener("click", () => openProfileModal(button.dataset.profileOpen)));
  $$('[data-profile-close]').forEach((button) => button.addEventListener("click", closeProfileModal));
  $$('[data-profile-message]').forEach((button) => button.addEventListener("click", () => toast(button.dataset.profileMessage)));
  $$('[data-service-link]').forEach((button) => button.addEventListener("click", () => openServiceLink(button.dataset.serviceLink)));
  $$('[data-language]').forEach((button) => button.addEventListener("click", () => saveLanguage(button.dataset.language)));
  $$('[data-profile-copy]').forEach((button) => button.addEventListener("click", async (event) => {
    event.stopPropagation();
    const value = button.dataset.profileCopy === "mobile" ? userProfile.mobile : playerIdFor(userProfile);
    const copied = await copyToClipboard(value);
    toast(copied ? "Copied Successfully" : "Unable to copy", copied ? "success" : "error");
  }));
  $("#claimBonus")?.addEventListener("click", () => toast("No bonus is available to claim right now."));
  $("#securityPinForm input[name='securityPin']")?.addEventListener("input", (event) => {
    event.target.value = event.target.value.replace(/\D/g, "").slice(0, 6);
  });
  $$('[name="giftCode"]').forEach((input) => input.addEventListener("input", () => {
    input.value = normalizeGiftCode(input.value);
  }));
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") { closeProfileModal(); closeAvatarModal(); }
  });

  if (isConfigured && currentUser) await loadProfileActivities();

  window.setTimeout(() => window.lucide?.createIcons(), 0);
}

function renderAvatarGrid() {
  const grid = $("#avatarGrid");
  if (!grid) return;
  const selectedId = userProfile.avatarId || AVATAR_OPTIONS.find((avatar) => avatar.url === userProfile.avatarUrl)?.id;
  grid.innerHTML = AVATAR_OPTIONS.map((avatar) => `<button class="avatar-choice${avatar.id === selectedId ? " selected" : ""}" type="button" data-avatar-id="${avatar.id}" aria-label="Select ${avatar.id}" aria-pressed="${avatar.id === selectedId}"><img src="${avatar.url}" alt="" loading="lazy" decoding="async"><span class="avatar-check"><i data-lucide="check"></i></span></button>`).join("");
  window.setTimeout(() => window.lucide?.createIcons(), 0);
}

function openAvatarModal() {
  renderAvatarGrid();
  $("#avatarModal")?.classList.remove("hidden");
  document.body.classList.add("avatar-modal-open");
}

function closeAvatarModal() {
  $("#avatarModal")?.classList.add("hidden");
  document.body.classList.remove("avatar-modal-open");
}

async function selectAvatar(event) {
  const button = event.target.closest("[data-avatar-id]");
  if (!button) return;
  const avatar = AVATAR_OPTIONS.find((item) => item.id === button.dataset.avatarId);
  if (!avatar || avatar.id === userProfile.avatarId) return;
  button.disabled = true;
  try {
    if (isConfigured && currentUser) await updateDoc(doc(db, "users", currentUser.uid), { avatarId: avatar.id, avatarUrl: avatar.url, updatedAt: serverTimestamp() });
    userProfile = { ...userProfile, avatarId: avatar.id, avatarUrl: avatar.url };
    cacheUser(userProfile);
    renderProfileData(userProfile);
    renderAvatarGrid();
    toast("Avatar Updated Successfully", "success");
    window.setTimeout(closeAvatarModal, 500);
  } catch (error) {
    console.warn("Avatar update failed", error);
    toast("Unable to update avatar", "error");
    button.disabled = false;
  }
}

function renderProfileData(profile) {
  renderAvatar($("#profileAvatar"), profile);
  $("#profileMobile").textContent = maskMobile(profile.mobile);
  $("#profileUid").textContent = `ID: ${playerIdFor(profile)}`;
  $("#profileBalance").textContent = money(profile.walletBalance);
  renderProfileTodayProfit(liveTodayProfit ?? profile.todayProfit);
  $("#profileBonus").textContent = money(profile.bonusBalance || profile.bonus || 0);
  applyLanguage(localStorage.getItem("YelePayLanguage") || profile.language || "English", false);
  const form = $("#profileForm");
  if (form) {
    form.elements.name.value = profile.name || "";
    form.elements.mobile.value = profile.mobile || "";
    form.elements.photoURL.value = profile.photoURL || "";
  }
}

function renderLanguageSelection(language) {
  $$('[data-language]').forEach((button) => button.classList.toggle("selected", button.dataset.language === language));
}

function translate(key, language = localStorage.getItem("YelePayLanguage") || userProfile?.language || "English") {
  const selected = translations[language] ? language : "English";
  return translations[selected][key] || translations.English[key] || key;
}

async function applyLanguage(language, saveUser = true) {
  const selected = translations[language] ? language : "English";
  const languageChanged = selected !== (userProfile?.language || localStorage.getItem("YelePayLanguage") || "English");
  currentLanguage = selected;
  localStorage.setItem("YelePayLanguage", selected);
  document.documentElement.lang = selected === "Hindi" ? "hi" : "en";
  $$('[data-i18n]').forEach((element) => {
    element.textContent = translate(element.dataset.i18n, selected);
  });
  $$('[data-i18n-placeholder]').forEach((element) => {
    element.placeholder = translate(element.dataset.i18nPlaceholder, selected);
  });
  translatePageContent(document.body, selected);
  renderLanguageSelection(selected);
  if (saveUser && languageChanged && isConfigured && currentUser) await updateDoc(doc(db, "users", currentUser.uid), { language: selected });
  if (userProfile) userProfile = { ...userProfile, language: selected };
  cacheUser(userProfile);
  return selected;
}

function translatedPageText(text, language) {
  const value = String(text || "").trim();
  if (!value) return value;
  if (language === "Hindi") {
    if (value.startsWith("Hello,")) return `à¤¨à¤®à¤¸à¥à¤¤à¥‡,${value.slice(6)}`;
    return pageTextTranslations[value] || value;
  }
  if (value.startsWith("à¤¨à¤®à¤¸à¥à¤¤à¥‡,")) return `Hello,${value.slice(7)}`;
  return reversePageTextTranslations[value] || value;
}

function translatePageContent(root, language = currentLanguage) {
  if (!root) return;
  const translateNode = (node) => {
    const parent = node.parentElement;
    if (!parent || parent.closest("[data-i18n]") || ["SCRIPT", "STYLE", "NOSCRIPT"].includes(parent.tagName)) return;
    const original = node.nodeValue;
    const trimmed = original.trim();
    if (!trimmed) return;
    const translated = translatedPageText(trimmed, language);
    if (translated !== trimmed) node.nodeValue = original.replace(trimmed, translated);
  };

  if (root.nodeType === Node.TEXT_NODE) {
    translateNode(root);
    return;
  }
  if (root.nodeType !== Node.ELEMENT_NODE && root.nodeType !== Node.DOCUMENT_NODE) return;
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  let node = walker.nextNode();
  while (node) {
    translateNode(node);
    node = walker.nextNode();
  }
  root.querySelectorAll?.("input[placeholder], textarea[placeholder]").forEach((field) => {
    if (field.dataset.i18nPlaceholder) return;
    field.placeholder = translatedPageText(field.placeholder, language);
  });
}

function startLanguageObserver() {
  if (languageObserver || !document.body) return;
  languageObserver = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => mutation.addedNodes.forEach((node) => translatePageContent(node, currentLanguage)));
  });
  languageObserver.observe(document.body, { childList: true, subtree: true });
}

function normalizeGiftCode(value) {
  return String(value || "").toUpperCase().replace(/[^A-Z0-9_-]/g, "").slice(0, 32);
}

function valueDate(value) {
  if (!value) return null;
  const date = value.toDate ? value.toDate() : new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

async function redeemGiftCode(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const submitButton = form.querySelector("button[type='submit']");
  const code = normalizeGiftCode(new FormData(form).get("giftCode"));
  if (code.length < 4) return toast("Invalid gift code", "error");
  if (!isConfigured || !currentUser) return toast("Gift redemption requires Firebase login", "error");

  try {
    if (submitButton) submitButton.disabled = true;
    let rewardAmount = 0;
    const giftRef = doc(db, "giftCodes", code);
    const redemptionRef = doc(db, "giftRedemptions", `${currentUser.uid}_${code}`);
    const userRef = doc(db, "users", currentUser.uid);
    const activityRef = doc(collection(db, "activities"));
    await runTransaction(db, async (tx) => {
      const giftSnapshot = await tx.get(giftRef);
      const redemptionSnapshot = await tx.get(redemptionRef);
      if (!giftSnapshot.exists()) throw new Error("Invalid gift code");
      if (redemptionSnapshot.exists()) throw new Error("Gift code already used");

      const gift = giftSnapshot.data();
      const expiry = valueDate(gift.expiresAt);
      const usageLimit = Number(gift.usageLimit || 0);
      const usedCount = Number(gift.usedCount || 0);
      rewardAmount = Number(gift.rewardAmount || 0);
      if (gift.active === false || rewardAmount <= 0 || usageLimit <= 0) throw new Error("Invalid gift code");
      if (expiry && expiry.getTime() < Date.now()) throw new Error("Gift code expired");
      if (usedCount >= usageLimit) throw new Error("Gift code usage limit reached");

      tx.update(giftRef, { usedCount: usedCount + 1, updatedAt: serverTimestamp() });
      tx.set(redemptionRef, { userId: currentUser.uid, giftCode: code, rewardAmount, createdAt: serverTimestamp() });
      tx.update(userRef, { walletBalance: increment(rewardAmount) });
      tx.set(activityRef, { userId: currentUser.uid, title: "Gift Code Redeemed", amount: rewardAmount, createdAt: serverTimestamp() });
    });

    userProfile = { ...userProfile, walletBalance: Number(userProfile.walletBalance || 0) + rewardAmount };
    renderProfileData(userProfile);
    form.reset();
    closeProfileModal();
    toast(`${money(rewardAmount)} added to YeleCoin Balance`, "success");
  } catch (error) {
    console.warn(error);
    toast(friendlyError(error, "Invalid gift code"), "error");
  } finally {
    if (submitButton) submitButton.disabled = false;
  }
}

async function loadProfileActivities() {
  const target = $("#profileActivityList");
  if (!target || !isConfigured || !currentUser) return;
  const activityQuery = query(collection(db, "activities"), where("userId", "==", currentUser.uid), orderBy("createdAt", "desc"), limit(20));
  try {
    const snapshot = await getDocs(activityQuery);
    const rows = snapshot.docs
      .map((item) => ({ id: item.id, ...item.data() }))
      .sort((a, b) => (valueDate(b.createdAt)?.getTime() || 0) - (valueDate(a.createdAt)?.getTime() || 0));
    target.innerHTML = rows.length ? rows.map((item) => `<article class="profile-activity-item">
      <span class="profile-activity-icon"><span class="icon i-check"></span></span>
      <span><strong${item.title === "Account Login Successfully" ? ' data-i18n="loginSuccess"' : ""}>${item.title === "Account Login Successfully" ? translate("loginSuccess") : (item.title || "Account Activity")}</strong><small>${formatDateTime(item.createdAt)}</small></span>
    </article>`).join("") : `<div class="empty" data-i18n="noRecentActivity">${translate("noRecentActivity")}</div>`;
  } catch (error) {
    showServerBusy(error, false);
    target.innerHTML = `<div class="empty" data-i18n="noRecentActivity">${translate("noRecentActivity")}</div>`;
  }
}

async function saveSecurityPin(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const pin = String(new FormData(form).get("securityPin") || "");
  if (!/^\d{6}$/.test(pin)) return toast("PIN must be exactly 6 digits", "error");
  try {
    if (pin !== String(userProfile?.securityPin || "") && isConfigured && currentUser) await updateDoc(doc(db, "users", currentUser.uid), { securityPin: pin });
    userProfile = { ...userProfile, securityPin: pin };
    cacheUser(userProfile);
    form.reset();
    closeProfileModal();
    toast("PIN Saved Successfully", "success");
  } catch (error) {
    console.warn(error);
    toast("Unable to save PIN", "error");
  }
}

async function saveLanguage(language) {
  if (!['Hindi', 'English'].includes(language)) return;
  try {
    await applyLanguage(language, true);
    closeProfileModal();
    toast(`${language} selected`, "success");
  } catch (error) {
    console.warn(error);
    toast("Unable to save language", "error");
  }
}

async function installYelePayApp() {
  const standalone = window.matchMedia?.("(display-mode: standalone)")?.matches || window.navigator.standalone === true;
  if (standalone || !deferredInstallPrompt) return;

  const promptEvent = deferredInstallPrompt;
  deferredInstallPrompt = null;
  document.body.classList.remove("pwa-install-ready");
  await promptEvent.prompt();
  await promptEvent.userChoice;
}

function openAppDownloadLink() {
  const link = String(settings.appDownloadLink || "").trim();
  if (!link) return toast("Download link not available", "error");
  try {
    const url = new URL(link);
    if (!["https:", "http:"].includes(url.protocol)) throw new Error("Unsupported download URL");
    location.assign(url.href);
  } catch (error) {
    console.warn("Invalid app download link.", error);
    toast("Download link not available", "error");
  }
}

function openHomeServiceModal() {
  $("#homeServiceModal")?.classList.remove("hidden");
  document.body.classList.add("home-service-open");
}

function closeHomeServiceModal() {
  $("#homeServiceModal")?.classList.add("hidden");
  document.body.classList.remove("home-service-open");
}

function renderProfileTodayProfit(value) {
  const target = $("#profileTodayEarnings");
  if (target) target.textContent = Number(value || 0).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function serviceUrl(type) {
  if (type === "group") return String(settings.telegramGroupLink || settings.telegramGroup || "").trim();
  const current = String(settings.telegramSupportLink || "").trim();
  if (current) return current;
  const legacy = String(settings.telegramId || "").trim().replace(/^@/, "");
  return legacy ? `https://t.me/${legacy}` : "";
}

function openServiceLink(type) {
  const url = serviceUrl(type);
  if (!url) return toast("Service link not available", "error");
  try {
    const parsed = new URL(url);
    if (!["https:", "http:"].includes(parsed.protocol)) throw new Error("Unsupported service URL");
    window.open(parsed.href, "_blank", "noopener,noreferrer");
  } catch (error) {
    console.warn("Invalid service link.", error);
    toast("Service link not available", "error");
  }
}

function openProfileModal(panelName) {
  const modal = $("#profileModal");
  if (!modal) return;
  $$('.profile-modal-panel').forEach((panel) => panel.classList.toggle("hidden", panel.dataset.profilePanel !== panelName));
  const titleKeys = {
    password: "changePassword",
    service: "YelePayService",
    gift: "redeemGift",
    inbox: "recentActivity",
    pin: "securityPinTitle",
    language: "selectLanguage",
    edit: "profileSettings"
  };
  const title = $("#profileModalTitle");
  title.dataset.i18n = titleKeys[panelName] || "profileSettings";
  title.textContent = translate(title.dataset.i18n);
  modal.classList.remove("hidden");
  document.body.classList.add("profile-modal-open");
}

function closeProfileModal() {
  $("#profileModal")?.classList.add("hidden");
  document.body.classList.remove("profile-modal-open");
}

async function updateUserProfile(event) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const data = {
    name: form.get("name").trim(),
    mobile: form.get("mobile").trim(),
    photoURL: form.get("photoURL").trim()
  };
  const changed = Object.keys(data).some((key) => String(data[key] || "") !== String(userProfile?.[key] || ""));
  if (changed && isConfigured) await updateDoc(doc(db, "users", currentUser.uid), data);
  userProfile = { ...userProfile, ...data };
  cacheUser(userProfile);
  renderProfileData(userProfile);
  closeProfileModal();
  toast("Profile updated.", "success");
}

async function changePassword(event) {
  event.preventDefault();
  const password = new FormData(event.currentTarget).get("password");
  if (!isConfigured) return toast("Demo mode: connect Firebase to change password.");
  await updatePassword(auth.currentUser, password);
  closeProfileModal();
  toast("Password changed.", "success");
  event.currentTarget.reset();
}

function historyEmptyMessage(type) {
  return {
    purchase: "No Purchase History Found",
    withdraw: "No Withdrawal History Found",
    profit: "No Profit History Found",
    bonus: "No Bonus History Found"
  }[type] || "No History Found";
}

function newestHistoryRows(rows) {
  return [...rows].sort((a, b) => withdrawalAccountCreatedAt(b) - withdrawalAccountCreatedAt(a));
}

function historyCacheKey(type) {
  return `${currentUser?.uid || "demo"}:${type}`;
}

function historyDateValue(value) {
  if (!value) return value;
  if (typeof value.toMillis === "function") return value.toMillis();
  if (typeof value.toDate === "function") return value.toDate().getTime();
  if (Number.isFinite(value?.seconds)) return value.seconds * 1000;
  return value;
}

function cacheableHistoryRows(rows) {
  return rows.map((row) => ({
    ...row,
    createdAt: historyDateValue(row.createdAt),
    updatedAt: historyDateValue(row.updatedAt),
    approvedAt: historyDateValue(row.approvedAt),
    completedAt: historyDateValue(row.completedAt)
  }));
}

function readHistoryCache(type) {
  const key = historyCacheKey(type);
  const cached = historyRowsCache.get(key);
  if (cached && Date.now() - cached.createdAt < HISTORY_CACHE_TTL) return cached.rows;
  try {
    const saved = JSON.parse(sessionStorage.getItem(`yelepayHistory:${key}`) || "null");
    if (saved && Date.now() - saved.createdAt < HISTORY_CACHE_TTL) {
      historyRowsCache.set(key, saved);
      return saved.rows;
    }
  } catch (error) {
    console.warn("History cache read failed.", error);
  }
  return null;
}

function writeHistoryCache(type, rows) {
  const key = historyCacheKey(type);
  const value = { createdAt: Date.now(), rows: cacheableHistoryRows(rows) };
  historyRowsCache.set(key, value);
  try { sessionStorage.setItem(`yelepayHistory:${key}`, JSON.stringify(value)); } catch {}
}

function clearHistoryListeners() {
  historyUnsubs.forEach((unsubscribe) => {
    try { unsubscribe(); } catch (error) { console.warn("History listener cleanup failed.", error); }
  });
  historyUnsubs = [];
  historyLoadObserver?.disconnect();
  historyLoadObserver = null;
  historyPageState = null;
}

function demoHistoryRows(type) {
  const now = new Date().toISOString();
  const rows = {
    purchase: [{ id: "demo-purchase", orderId: "ORD578587556", amount: 1000, commissionAmount: 80, status: "processing", utrNumber: "123456789012", upiId: "YelePayindia@upi", createdAt: now }],
    withdraw: [{ id: "demo-withdraw", amount: 500, status: "processing", method: "UPI", upiId: "demo@upi", createdAt: now }],
    profit: [{ id: "demo-profit", orderId: "ORD578587556", amount: 80, commissionAmount: 80, status: "completed", createdAt: now }],
    bonus: [{ id: "demo-bonus", amount: 120, title: "Welcome bonus", status: "completed", createdAt: now }]
  };
  return rows[type] || [];
}

async function loadHistoryQuery(queryRef, type, target, onRows) {
  try {
    const snapshot = await getDocs(queryRef);
    const rows = snapshot.docs.map((item) => ({ id: item.id, ...item.data() }));
    writeHistoryCache(type, rows);
    onRows(rows);
  } catch (error) {
    showServerBusy(error, false);
    target.innerHTML = `<div class="empty">${historyEmptyMessage(type)}</div>`;
  }
}

async function initHistory() {
  if (!requireProfile()) return;
  const tabs = $$(".tab");
  const allowedTabs = new Set(["purchase", "withdraw", "profit", "bonus"]);
  const requestedTab = new URLSearchParams(location.search).get("tab");
  const initialTab = allowedTabs.has(requestedTab) ? requestedTab : "purchase";

  const activateTab = (type, updateUrl = true) => {
    const selected = allowedTabs.has(type) ? type : "purchase";
    tabs.forEach((item) => item.classList.toggle("active", item.dataset.type === selected));
    if (updateUrl) {
      const url = new URL(location.href);
      url.searchParams.set("tab", selected);
      history.replaceState({}, "", `${url.pathname}${url.search}`);
    }
    renderHistory(selected, $("#historyList"), true);
  };

  tabs.forEach((tab) => tab.addEventListener("click", () => activateTab(tab.dataset.type)));
  activateTab(initialTab, requestedTab !== initialTab);
}

async function renderHistory(type, target, live = false) {
  if (!target) return;
  clearHistoryListeners();
  const cachedRows = readHistoryCache(type);
  if (cachedRows) {
    renderHistoryRows(type, target, cachedRows);
    return;
  }
  target.innerHTML = `<div class="history-skeleton" aria-label="Loading ${type} history"><span></span><span></span><span></span></div>`;
  if (!isConfigured || !currentUser) {
    renderHistoryRows(type, target, demoHistoryRows(type));
    return;
  }

  if (type === "purchase" || type === "withdraw") {
    const collectionName = type === "purchase" ? "payments" : "withdrawals";
    historyPageState = { type, target, collectionName, rows: [], cursor: null, hasMore: true, loading: false };
    const latestQuery = query(collection(db, collectionName), where("userId", "==", currentUser.uid), orderBy("createdAt", "desc"), limit(HISTORY_PAGE_SIZE));
    try {
      const snapshot = await getDocs(latestQuery);
      const latestRows = snapshot.docs.map((item) => ({ id: item.id, ...item.data() }));
      historyPageState.rows = newestHistoryRows(latestRows);
      writeHistoryCache(type, historyPageState.rows);
      historyPageState.cursor = null;
      historyPageState.hasMore = false;
      renderHistoryRows(type, target, historyPageState.rows);
    } catch (error) {
      showServerBusy(error, false);
      target.innerHTML = `<div class="empty">${historyEmptyMessage(type)}</div>`;
    }
    return;
  }
  if (type === "profit") {
    const orderQuery = query(collection(db, "orders"), where("userId", "==", currentUser.uid), orderBy("createdAt", "desc"), limit(HISTORY_PAGE_SIZE));
    await loadHistoryQuery(orderQuery, type, target, (rows) => renderHistoryRows(type, target, newestHistoryRows(rows
      .filter((item) => String(item.status || "").toLowerCase() === "completed")
      .map((item) => ({ ...item, amount: Number(item.commissionAmount || item.expectedProfit || 0), status: "completed" })))));
    return;
  }

  const transactionQuery = query(collection(db, "transactions"), where("userId", "==", currentUser.uid), orderBy("createdAt", "desc"), limit(HISTORY_PAGE_SIZE));
  await loadHistoryQuery(transactionQuery, type, target, (rows) => {
    const bonusRows = rows.filter((item) => {
      const descriptor = `${item.type || ""} ${item.title || ""}`.toLowerCase();
      return ["bonus", "reward", "gift", "welcome"].some((keyword) => descriptor.includes(keyword));
    });
    renderHistoryRows(type, target, newestHistoryRows(bonusRows));
  });
}

function renderHistoryRows(type, target, rows) {
  const emptyMessage = historyEmptyMessage(type);
  target.innerHTML = rows.length ? rows.map((item) => {
    const normalizedStatus = String(item.status || "processing").toLowerCase();
    const statusText = labelStatus(normalizedStatus);
    if (type === "purchase") {
      return `<article class="history-record">
        <div class="history-record-head"><div><span>ORDER ID</span><strong>${escapeMarkup(item.orderId || "-")}</strong></div><span class="status-pill ${normalizedStatus}">${statusText}</span></div>
        <div class="history-detail-grid"><div><span>Amount</span><strong>${money(item.amount)}</strong></div><div><span>Commission</span><strong class="history-positive">+${money(item.commissionAmount || 0)}</strong></div><div><span>UTR</span><strong>${escapeMarkup(item.utrNumber || item.utr || "-")}</strong></div><div><span>UPI ID</span><strong>${escapeMarkup(item.upiId || "-")}</strong></div></div>
        <time>${formatDateTime(item.createdAt)}</time>
      </article>`;
    }
    if (type === "withdraw") {
      const details = item.method === "Bank" ? (item.bankDetails || "Bank") : (item.upiId || "UPI");
      return `<article class="history-record">
        <div class="history-record-head"><div><span>WITHDRAWAL ID</span><strong>${escapeMarkup(item.withdrawalId || shortId(item.id))}</strong></div><span class="status-pill ${normalizedStatus}">${statusText}</span></div>
        <div class="history-detail-grid"><div><span>Amount</span><strong>${money(item.amount)}</strong></div><div><span>Method</span><strong>${escapeMarkup(item.method || "UPI")}</strong></div><div class="history-detail-wide"><span>Payment details</span><strong>${escapeMarkup(details)}</strong></div></div>
        <time>${formatDateTime(item.createdAt)}</time>
      </article>`;
    }
    if (type === "profit") {
      return `<article class="history-record history-summary-record"><span class="history-record-icon profit"><i data-lucide="trending-up"></i></span><div><span>COMMISSION EARNED</span><strong>${escapeMarkup(item.orderId || "Completed order")}</strong><time>${formatDateTime(item.approvedAt || item.completedAt || item.createdAt)}</time></div><strong class="history-record-amount">+${money(item.amount || item.commissionAmount)}</strong></article>`;
    }
    return `<article class="history-record history-summary-record"><span class="history-record-icon bonus"><i data-lucide="gift"></i></span><div><span>BONUS SOURCE</span><strong>${escapeMarkup(item.source || item.title || item.giftCode || "YelePay Reward")}</strong><time>${formatDateTime(item.createdAt)}</time></div><strong class="history-record-amount">+${money(item.amount || item.rewardAmount)}</strong></article>`;
  }).join("") : `<div class="empty">${emptyMessage}</div>`;
  window.setTimeout(() => window.lucide?.createIcons(), 0);
}

async function sha256(value) {
  const bytes = new TextEncoder().encode(String(value));
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

async function ensureAdminPasswordHash() {
  let passwordHash = String(settings.adminPasswordHash || "").trim().toLowerCase();
  if (!/^[a-f0-9]{64}$/.test(passwordHash) || LEGACY_ADMIN_PASSWORD_HASHES.has(passwordHash)) {
    passwordHash = DEFAULT_ADMIN_PASSWORD_HASH;
    settings = { ...settings, adminPasswordHash: passwordHash };
    if (isConfigured) await setDoc(doc(db, "settings", "main"), { adminPasswordHash: passwordHash }, { merge: true });
  }
  return passwordHash;
}

let adminPanelInitialized = false;

function setAdminLockedState(isUnlocked) {
  const gate = $("#adminGate");
  const content = $("#adminContent");
  gate?.classList.toggle("hidden", isUnlocked);
  content?.classList.toggle("hidden", !isUnlocked);
  content?.setAttribute("aria-hidden", String(!isUnlocked));
  if (!isUnlocked) window.setTimeout(() => $("#adminPassword")?.focus(), 80);
}

function hasAdminAccess() {
  const expectedHash = String(settings.adminPasswordHash || DEFAULT_ADMIN_PASSWORD_HASH).toLowerCase();
  return sessionStorage.getItem(ADMIN_SESSION_KEY) === expectedHash;
}

function requireAdminAccess() {
  if (hasAdminAccess()) return true;
  setAdminLockedState(false);
  toast("Admin panel is locked", "error");
  return false;
}

async function initAdmin() {
  const unlockForm = $("#adminUnlockForm");
  const lockButton = $("#lockAdminButton");
  if (!unlockForm || !$("#adminContent")) return;

  const expectedHash = await ensureAdminPasswordHash();
  const unlockPanel = async () => {
    setAdminLockedState(true);
    if (!adminPanelInitialized) {
      adminPanelInitialized = true;
      await initializeAdminPanel();
    }
  };

  unlockForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const passwordInput = $("#adminPassword");
    const unlockButton = $("#adminUnlockButton");
    if (unlockButton) unlockButton.disabled = true;
    try {
      const enteredHash = await sha256(passwordInput?.value || "");
      if (enteredHash !== expectedHash) {
        if (passwordInput) {
          passwordInput.value = "";
          passwordInput.focus();
        }
        return toast("Wrong Admin Password", "error");
      }
      sessionStorage.setItem(ADMIN_SESSION_KEY, expectedHash);
      await unlockPanel();
      toast("Admin Access Granted", "success");
    } finally {
      if (unlockButton) unlockButton.disabled = false;
    }
  });

  lockButton?.addEventListener("click", () => {
    sessionStorage.removeItem(ADMIN_SESSION_KEY);
    unlockForm.reset();
    setAdminLockedState(false);
  });

  if (sessionStorage.getItem(ADMIN_SESSION_KEY) === expectedHash) await unlockPanel();
  else setAdminLockedState(false);
}

async function initializeAdminPanel() {
  $("#adminUsers").textContent = isConfigured ? "Live" : "128";
  $("#adminActive").textContent = isConfigured ? "Live" : "94";
  $("#adminDeposits").textContent = money(482000);
  $("#adminWithdrawals").textContent = money(226000);
  $("#adminProfit").textContent = money(91300);

  const form = $("#settingsForm");
  if (!form) return;
  Object.entries(settings).forEach(([key, value]) => {
    const field = form.elements[key];
    if (!field) return;
    if (field.type === "checkbox") field.checked = Boolean(value);
    else field.value = value;
  });

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!requireAdminAccess()) return;
    const formData = new FormData(form);
    const next = {
      profitPercent: Number(formData.get("profitPercent")),
      orderProfitPercentage: Number(formData.get("orderProfitPercentage") || 3.5),
      signupBonusAmount: Math.max(0, Number(formData.get("signupBonusAmount") || 0)),
      minDepositAmount: Math.max(0, Number(formData.get("minDepositAmount") || 1000)),
      minPurchase: Number(formData.get("minPurchase")),
      maxPurchase: Number(formData.get("maxPurchase")),
      minWithdraw: Number(formData.get("minWithdraw")),
      maxWithdraw: Number(formData.get("maxWithdraw")),
      minCompletedOrdersForWithdrawal: Math.max(1, Math.floor(Number(formData.get("minCompletedOrdersForWithdrawal") || 3))),
      welcomeBonus: Number(formData.get("welcomeBonus")),
      dailyOrderLimit: Number(formData.get("dailyOrderLimit")),
      orderDuration: Number(formData.get("orderDuration")),
      coinPrice: Number(formData.get("coinPrice")),
      platformPrice: Number(formData.get("platformPrice")),
      telegramGroupLink: formData.get("telegramGroupLink").trim(),
      telegramSupportLink: formData.get("telegramSupportLink").trim(),
      appDownloadLink: formData.get("appDownloadLink").trim(),
      registrationEnabled: form.elements.registrationEnabled.checked,
      purchaseEnabled: form.elements.purchaseEnabled.checked,
      withdrawEnabled: form.elements.withdrawEnabled.checked
    };
    if (!Number.isFinite(next.orderProfitPercentage) || next.orderProfitPercentage < 0 || next.orderProfitPercentage > 100) {
      return toast("Enter a valid Order Profit Percentage between 0 and 100.", "error");
    }
    settings = { ...settings, ...next };
    cacheSettings(settings);
    if (isConfigured) await setDoc(doc(db, "settings", "main"), next, { merge: true });
    toast("Settings Updated Successfully");
  });

  renderAdminUpis();
  await renderAdminUtrRequests();
  await renderAdminWithdrawRequests();
  await renderAdminGiftCodes();
  $("#adminUpiForm")?.addEventListener("submit", saveAdminUpi);
  $("#giftCodeForm")?.addEventListener("submit", saveGiftCode);
  $("#utrRequestList")?.addEventListener("click", handleAdminUtrAction);
  $("#withdrawRequestList")?.addEventListener("click", handleAdminWithdrawAction);
  $("#refreshUtrRequests")?.addEventListener("click", () => renderAdminUtrRequests());
  $("#refreshWithdrawRequests")?.addEventListener("click", () => renderAdminWithdrawRequests());
}

async function saveGiftCode(event) {
  event.preventDefault();
  if (!requireAdminAccess()) return;
  const form = event.currentTarget;
  const submitButton = form.querySelector("button[type='submit']");
  const data = new FormData(form);
  const code = normalizeGiftCode(data.get("giftCode"));
  const rewardAmount = Number(data.get("rewardAmount"));
  const usageLimit = Number(data.get("usageLimit"));
  const expiryDate = String(data.get("expiryDate") || "").trim();
  if (code.length < 4) return toast("Gift code must be at least 4 characters", "error");
  if (!(rewardAmount > 0)) return toast("Enter a valid reward amount", "error");
  if (!Number.isInteger(usageLimit) || usageLimit < 1) return toast("Enter a valid usage limit", "error");

  try {
    if (submitButton) submitButton.disabled = true;
    if (isConfigured) {
      const giftRef = doc(db, "giftCodes", code);
      await runTransaction(db, async (tx) => {
        const existing = await tx.get(giftRef);
        if (existing.exists()) throw new Error("Gift code already exists");
        tx.set(giftRef, {
          code,
          rewardAmount,
          usageLimit,
          usedCount: 0,
          expiresAt: expiryDate ? new Date(`${expiryDate}T23:59:59`).toISOString() : null,
          active: true,
          createdAt: serverTimestamp(),
          createdBy: currentUser?.uid || "admin"
        });
      });
    }
    form.reset();
    toast("Gift Code Generated Successfully", "success");
    await renderAdminGiftCodes();
  } catch (error) {
    console.warn(error);
    toast(friendlyError(error, "Unable to generate gift code"), "error");
  } finally {
    if (submitButton) submitButton.disabled = false;
  }
}

async function renderAdminGiftCodes() {
  const target = $("#giftCodeList");
  if (!target) return;
  if (!isConfigured) {
    target.innerHTML = `<div class="empty">No gift codes generated.</div>`;
    return;
  }
  try {
    const snapshot = await getDocs(query(collection(db, "giftCodes"), orderBy("createdAt", "desc"), limit(20)));
    const rows = snapshot.docs
      .map((item) => ({ id: item.id, ...item.data() }))
      .sort((a, b) => (valueDate(b.createdAt)?.getTime() || 0) - (valueDate(a.createdAt)?.getTime() || 0));
    target.innerHTML = rows.length ? rows.map((item) => `<article class="gift-code-card">
      <div><strong>${item.code || item.id}</strong><span class="status-pill ${item.active === false ? "rejected" : "completed"}">${item.active === false ? "Inactive" : "Active"}</span></div>
      <p>Reward <strong>${money(item.rewardAmount)}</strong></p>
      <p>Used <strong>${Number(item.usedCount || 0)} / ${Number(item.usageLimit || 0)}</strong></p>
      <p>Expiry <strong>${item.expiresAt ? formatDateTime(item.expiresAt) : "No expiry"}</strong></p>
    </article>`).join("") : `<div class="empty">No gift codes generated.</div>`;
  } catch (error) {
    console.warn(error);
    target.innerHTML = `<div class="empty">Unable to load gift codes.</div>`;
  }
}

async function renderAdminUtrRequests() {
  const target = $("#utrRequestList");
  if (!target) return;
  const fallback = [{
    id: "demo-request",
    orderId: "ORD578587556",
    userName: "Demo User",
    userMobile: "9876543210",
    amount: 1500,
    commissionAmount: 120,
    utrNumber: "123456789012",
    upiId: "YelePayindia@upi",
    status: "processing",
    createdAt: new Date().toISOString()
  }];
  let rows = fallback;
  if (isConfigured) {
    const q = query(collection(db, "payments"), orderBy("createdAt", "desc"), limit(20));
    const snap = await getDocs(q);
    rows = snap.docs.map((item) => ({ id: item.id, ...item.data() }));
  }

  target.innerHTML = rows.length ? rows.map((item) => {
    const status = String(item.status || "processing").toLowerCase();
    const isOpen = status === "processing";
    return `<article class="utr-request-card">
      <div class="utr-request-head">
        <div>
          <strong>${item.orderId || "-"}</strong>
          <p class="eyebrow">${item.userName || "User"}${item.userMobile ? `  -  ${item.userMobile}` : ""}</p>
        </div>
        <span class="status-pill ${status}">${labelStatus(status)}</span>
      </div>
      <div class="utr-request-grid">
        <div><span>Amount</span><strong>${money(item.amount)}</strong></div>
        <div><span>Commission</span><strong>${money(item.commissionAmount || (Number(item.amount || 0) * getOrderProfitPercentage() / 100))}</strong></div>
        <div><span>UTR</span><strong>${item.utrNumber || "-"}</strong></div>
        <div><span>UPI ID</span><strong>${item.upiId || "-"}</strong></div>
        <div><span>Date</span><strong>${formatDateTime(item.createdAt)}</strong></div>
      </div>
      <div class="utr-actions">
        <button class="btn success-btn" data-utr-action="completed" data-request-id="${item.id}" ${isOpen ? "" : "disabled"}>Accept</button>
        <button class="btn danger" data-utr-action="rejected" data-request-id="${item.id}" ${isOpen ? "" : "disabled"}>Reject</button>
      </div>
    </article>`;
  }).join("") : `<div class="empty">No UTR requests found.</div>`;
}

async function handleAdminUtrAction(event) {
  const button = event.target.closest("[data-utr-action]");
  if (!button || button.disabled) return;
  if (!requireAdminAccess()) return;
  const requestId = button.dataset.requestId;
  const nextStatus = button.dataset.utrAction;
  button.disabled = true;

  if (!isConfigured) {
    toast(`Request ${labelStatus(nextStatus)}.`);
    await renderAdminUtrRequests();
    return;
  }

  const requestRef = doc(db, "payments", requestId);
  await runTransaction(db, async (tx) => {
    const requestSnap = await tx.get(requestRef);
    if (!requestSnap.exists()) throw new Error("Request not found.");
    const request = requestSnap.data();
    const commissionAmount = Number(request.commissionAmount || (Number(request.amount || 0) * getOrderProfitPercentage() / 100));
    const shouldCredit = nextStatus === "completed" && !request.credited;
    const update = {
      status: nextStatus,
      updatedAt: serverTimestamp()
    };
    if (nextStatus === "completed") {
      update.approvedAt = serverTimestamp();
      update.credited = true;
    }
    if (nextStatus === "rejected") {
      update.rejectedAt = serverTimestamp();
    }
    tx.update(requestRef, update);
    if (request.transactionDocId) {
      tx.update(doc(db, "transactions", request.transactionDocId), {
        status: nextStatus,
        commissionAmount,
        credited: nextStatus === "completed" ? true : Boolean(request.credited),
        updatedAt: serverTimestamp(),
        approvedAt: nextStatus === "completed" ? serverTimestamp() : null
      });
    }
    if (request.orderDocId) {
      tx.update(doc(db, "orders", request.orderDocId), {
        status: nextStatus,
        commissionAmount,
        credited: nextStatus === "completed" ? true : Boolean(request.credited),
        updatedAt: serverTimestamp(),
        approvedAt: nextStatus === "completed" ? serverTimestamp() : null
      });
    }
    if (shouldCredit) {
      const balanceCredit = Number(request.amount || 0) + commissionAmount;
      tx.update(doc(db, "users", request.userId), {
        walletBalance: increment(balanceCredit),
        totalProfit: increment(commissionAmount),
        todayProfit: increment(commissionAmount),
        totalIncome: increment(commissionAmount)
      });
    }
  });
  toast(`Request ${labelStatus(nextStatus)}.`, nextStatus === "completed" ? "success" : "error");
  await renderAdminUtrRequests();
}

async function renderAdminWithdrawRequests() {
  const target = $("#withdrawRequestList");
  if (!target) return;
  const fallback = [{
    id: "demo-withdraw",
    userName: "Demo User",
    userMobile: "9876543210",
    amount: 1200,
    method: "UPI",
    upiId: "demo@upi",
    status: "processing",
    createdAt: new Date().toISOString()
  }];
  let rows = fallback;
  if (isConfigured) {
    const q = query(collection(db, "withdrawals"), orderBy("createdAt", "desc"), limit(20));
    const snap = await getDocs(q);
    rows = snap.docs.map((item) => ({ id: item.id, ...item.data() }));
  }

  target.innerHTML = rows.length ? rows.map((item) => {
    const status = String(item.status || "processing").toLowerCase();
    const isOpen = status === "processing";
    return `<article class="utr-request-card">
      <div class="utr-request-head">
        <div>
          <strong>${item.method || "UPI"} Withdrawal</strong>
          <p class="eyebrow">${item.userName || "User"}${item.userMobile ? `  -  ${item.userMobile}` : ""}</p>
        </div>
        <span class="status-pill ${status}">${labelStatus(status)}</span>
      </div>
      <div class="utr-request-grid">
        <div><span>Amount</span><strong>${money(item.amount)}</strong></div>
        <div><span>Method</span><strong>${item.method || "UPI"}</strong></div>
        <div><span>Details</span><strong>${item.method === "Bank" ? (item.bankDetails || "-") : (item.upiId || "-")}</strong></div>
        <div><span>Date</span><strong>${formatDateTime(item.createdAt)}</strong></div>
      </div>
      <div class="utr-actions">
        <button class="btn success-btn" data-withdraw-action="completed" data-request-id="${item.id}" ${isOpen ? "" : "disabled"}>Accept</button>
        <button class="btn danger" data-withdraw-action="rejected" data-request-id="${item.id}" ${isOpen ? "" : "disabled"}>Reject</button>
      </div>
    </article>`;
  }).join("") : `<div class="empty">No withdrawal requests found.</div>`;
}

async function handleAdminWithdrawAction(event) {
  const button = event.target.closest("[data-withdraw-action]");
  if (!button || button.disabled) return;
  if (!requireAdminAccess()) return;
  const requestId = button.dataset.requestId;
  const nextStatus = button.dataset.withdrawAction;
  button.disabled = true;

  if (!isConfigured) {
    toast(`Withdrawal ${labelStatus(nextStatus)}.`);
    await renderAdminWithdrawRequests();
    return;
  }

  const requestRef = doc(db, "withdrawals", requestId);
  const requestSnap = await getDoc(requestRef);
  if (!requestSnap.exists()) return toast("Withdrawal request not found.", "error");
  const request = requestSnap.data();

  await updateDoc(requestRef, {
    status: nextStatus,
    updatedAt: serverTimestamp()
  });
  if (request.transactionDocId) {
    await updateDoc(doc(db, "transactions", request.transactionDocId), {
      status: nextStatus,
      updatedAt: serverTimestamp()
    });
  }
  toast(`Withdrawal ${labelStatus(nextStatus)}.`, nextStatus === "completed" ? "success" : "error");
  await renderAdminWithdrawRequests();
}

function renderAdminUpis() {
  const target = $("#adminUpiList");
  if (!target) return;
  const upis = Array.isArray(settings.adminUpis) ? settings.adminUpis : [];
  target.innerHTML = upis.length ? upis.map((item, index) => `<div class="list-row">
    <div>
      <strong>${item.upiId}</strong>
      <p class="eyebrow">${item.holderName || "Admin"}${item.mobile ? `  -  ${item.mobile}` : ""}</p>
    </div>
    <button class="icon-btn" data-admin-upi-delete="${index}" title="Delete"><span class="icon i-trash"></span></button>
  </div>`).join("") : `<div class="empty">No admin UPI added.</div>`;

  target.onclick = async (event) => {
    const button = event.target.closest("[data-admin-upi-delete]");
    if (!button) return;
    const index = Number(button.dataset.adminUpiDelete);
    settings.adminUpis = upis.filter((_, itemIndex) => itemIndex !== index);
    if (isConfigured) await setDoc(doc(db, "settings", "main"), { adminUpis: settings.adminUpis }, { merge: true });
    renderAdminUpis();
    toast("Admin UPI deleted.");
  };
}

async function saveAdminUpi(event) {
  event.preventDefault();
  if (!requireAdminAccess()) return;
  const upis = Array.isArray(settings.adminUpis) ? [...settings.adminUpis] : [];
  if (upis.length >= 5) return toast("Only 5 admin UPI IDs allowed.");
  const form = new FormData(event.currentTarget);
  upis.push({
    holderName: form.get("holderName").trim(),
    upiId: form.get("upiId").trim(),
    mobile: form.get("mobile").trim()
  });
  settings.adminUpis = upis;
  if (isConfigured) await setDoc(doc(db, "settings", "main"), { adminUpis: upis }, { merge: true });
  event.currentTarget.reset();
  renderAdminUpis();
  toast("Admin UPI added.");
}

export { app, auth, db, isConfigured };

if (page) {
  boot().catch((error) => {
    console.warn(error);
    hidePageSkeleton();
    toast(friendlyError(error, "Something went wrong."), "error");
  });
}




